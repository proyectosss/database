-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-10-2018 a las 22:08:55
-- Versión del servidor: 10.1.13-MariaDB
-- Versión de PHP: 5.5.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_hexocoins`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizar_datos_personales` (IN `nombre` VARCHAR(900), IN `apellido` VARCHAR(900), IN `direcion` VARCHAR(900), IN `telefono1` INT, IN `telefono2` INT, IN `celular` BIGINT, IN `email` VARCHAR(900), IN `pasaporte` VARCHAR(900), IN `referencia` VARCHAR(900), IN `observaciones` TEXT, IN `cedula` INT)  NO SQL
BEGIN
SET @nombre=nombre;
SET @apellido=apellido;
SET @direcion=direcion;
SET @telefono1=telefono1;
SET @telefono2=telefono2;
SET @celular=celular;
SET @email=email;
SET @pasaporte=pasaporte;
SET @referencia=referencia;
SET @observaciones=observaciones;
UPDATE tbl_datos_personales set var_nombre_dat = @nombre, var_apellido_dat=@apellido, var_direccion_dat=@direcion, int_telefono1_dat=@telefono1, int_telefono2_dat=@telefono2, int_celular_dat= @celular, var_email_dat=@email, var_pasaporte_dat=@pasaporte, var_referente_dat=@referencia, var_observaciones_dat=@observaciones
WHERE int_id_dat=cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizar_holding` (IN `valor` DOUBLE, IN `observacione` TEXT, IN `fecha` DATE, IN `id` INT)  NO SQL
BEGIN
UPDATE tbl_holding set dou_valor_hol = valor, text_observacione_hol=observacione, date_fecha_hol=fecha
WHERE int_id_producto_hol=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizar_holding_detail` (IN `descipcion` VARCHAR(900), IN `btc` DOUBLE, IN `PrecioBTC` DOUBLE, IN `usd` DOUBLE, IN `cop` DOUBLE, IN `Soporte` TEXT, IN `fecha` DATETIME, IN `id` INT)  NO SQL
BEGIN
UPDATE tbl_holding_detail set text_descipcion_hdet = descipcion, dou_btc_hdet=btc, dou_PrecioBTC_Dia_hdet=PrecioBTC, dou_usd_hdet=usd, dou_cop_hdet=cop, text_SoportePago_hdet=Soporte, date_fecha_hdet=fecha
WHERE int_id_hdet=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizar_producto` (IN `nombre` VARCHAR(900), IN `descripcion` VARCHAR(900), IN `observaciones` VARCHAR(900), IN `id` INT)  NO SQL
BEGIN
UPDATE tbl_productos set var_nombre_pro = nombre, text_descripcion_pro=descripcion, text_observaciones_pro=observaciones
WHERE int_id_pro=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizar_usuario` (IN `nombre` VARCHAR(900), IN `apellido` VARCHAR(900), IN `telefono` INT, IN `celular` BIGINT, IN `email` VARCHAR(900), IN `estado` VARCHAR(200), IN `role` VARCHAR(900), IN `cedula` INT)  NO SQL
BEGIN
SET @nombre=nombre;
SET @apellido=apellido;
SET @telefono=telefono;
SET @celular=celular;
SET @email=email;
SET @estado=estado;
SET @role=role;
SET @cedula=cedula;
UPDATE tbl_usuario set var_nombre_use = @nombre, var_apellido_use=@apellido, int_telefono_use=@telefono, int_celular_use= @celular, var_email_use=@email, var_estado_use=@estado, var_role_use=@role
WHERE int_documento_use=@cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_consulta_datos_personales` (IN `cedula` INT)  NO SQL
BEGIN
SELECT int_id_dat as cedula, var_nombre_dat as nombre, var_apellido_dat as apellido, var_direccion_dat as direcion, int_telefono1_dat as telefono1, int_telefono2_dat as telefono2, int_celular_dat as celular, var_email_dat as email, var_pasaporte_dat as pasaporte, var_referente_dat as referencia, var_observaciones_dat as observaciones
FROM tbl_datos_personales
WHERE int_id_dat=cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_consulta_holding` (IN `id` INT)  NO SQL
BEGIN
SELECT int_id_producto_hol as id_producto, date_fecha_hol as fecha, dou_valor_hol as valor, text_observacione_hol as observacione, int_id_holding_pro as producto
FROM tbl_holding
WHERE int_id_producto_hol =id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_consulta_producto` (IN `id` INT)  NO SQL
BEGIN
SELECT var_nombre_pro as nombre_producto, text_descripcion_pro as descripcion_producto, text_observaciones_pro as observaciones, int_id_pro as id 
FROM tbl_productos
WHERE int_id_pro=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_consulta_usuario` (IN `cedula` INT)  NO SQL
BEGIN
SET @cedula=cedula;
SELECT int_documento_use as cedula, var_nombre_use as nombre, var_apellido_use as apellido, int_telefono_use as telefono, int_celular_use as celular, var_email_use as email, var_password_use as passwordu, var_estado_use as estado, date_fecha_inicio_use as fecha, var_role_use as role
FROM tbl_usuario
WHERE int_documento_use=@cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_datos_personales_ingreso` (IN `documento` INT, IN `nombre` VARCHAR(900), IN `apellido` VARCHAR(900), IN `direcion` VARCHAR(900), IN `telefono1` INT, IN `telefono2` INT, IN `celular` BIGINT, IN `email` VARCHAR(900), IN `pasaporte` VARCHAR(900), IN `referente` VARCHAR(900), IN `observaciones` TEXT)  NO SQL
BEGIN
INSERT INTO tbl_datos_personales(int_id_dat, var_nombre_dat, var_apellido_dat,  var_direccion_dat, int_telefono1_dat, int_telefono2_dat, int_celular_dat, var_email_dat, var_pasaporte_dat, var_referente_dat, var_observaciones_dat) VALUES (documento, nombre, apellido, direcion, telefono1, telefono2, celular, email, pasaporte, referente, observaciones);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_eliminar_datos_personales` (IN `cedula` INT)  NO SQL
DELETE FROM tbl_datos_personales WHERE int_id_dat=cedula$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_eliminar_holding` (IN `id` INT)  NO SQL
BEGIN
DELETE FROM tbl_holding WHERE int_id_producto_hol=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_eliminar_holding_detail` (IN `id` INT)  NO SQL
BEGIN
DELETE FROM tbl_holding_detail WHERE int_id_hdet=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_eliminar_producto` (IN `id` INT)  NO SQL
DELETE FROM tbl_productos WHERE int_id_pro=id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_eliminar_usuario` (IN `cedula` INT)  NO SQL
BEGIN
set @cedula=cedula;
DELETE FROM tbl_usuario WHERE int_documento_use=@cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_holding_detail_obtener` (IN `id` INT)  NO SQL
BEGIN
SELECT int_id_producto_hol as id_producto, date_fecha_hdet as fecha, text_descipcion_hdet as descipcion, dou_btc_hdet as btc, dou_PrecioBTC_Dia_hdet as btcdia, dou_usd_hdet as usd, dou_cop_hdet as cop, text_SoportePago_hdet as SoportePago, int_id_hdet as id
FROM tbl_holding_detail
WHERE int_id_producto_hol =id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_igreso_usuario` (IN `documento` INT, IN `nombre` VARCHAR(900), IN `apellido` VARCHAR(900), IN `telefono` INT, IN `celular` BIGINT, IN `email` VARCHAR(900), IN `passwordu` VARCHAR(900), IN `estado` VARCHAR(200), IN `fecha` DATETIME, IN `role` VARCHAR(900))  NO SQL
BEGIN
SET @documento=documento; 
SET @nombre=nombre; 
SET @apellido=apellido; 
SET @telefono=telefono; 
SET @celular=celular; 
SET @email=email; 
SET @passwordu=passwordu; 
SET @estado=estado; 
SET @fecha=fecha; 
SET @role=role;
INSERT INTO tbl_usuario(int_documento_use, 
var_nombre_use, var_apellido_use,  int_telefono_use, int_celular_use, var_email_use, var_password_use, var_estado_use, date_fecha_inicio_use, var_role_use) VALUES (@documento, @nombre, @apellido, @telefono, @celular, @email, @passwordu, @estado, @fecha, @role);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ingresar_holding_detail` (IN `id_producto` INT, IN `fecha` DATETIME, IN `descipcion` INT, IN `btc` DOUBLE, IN `Precio` DOUBLE, IN `usd` DOUBLE, IN `cop` DOUBLE, IN `Soporte` TEXT)  NO SQL
BEGIN
INSERT INTO tbl_holding_detail(int_id_hdet, int_id_producto_hol, date_fecha_hdet, text_descipcion_hdet, dou_btc_hdet, dou_PrecioBTC_Dia_hdet, dou_usd_hdet, dou_cop_hdet, text_SoportePago_hdet) VALUES (null, id_producto, fecha, descipcion, btc, Precio, usd, cop, Soporte);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ingreso_holding` (IN `id_producto` INT, IN `cliente` INT, IN `fecha` DATETIME, IN `valor` DOUBLE, IN `id_holding` INT, IN `observacione` TEXT)  NO SQL
BEGIN
INSERT INTO tbl_holding(int_id_producto_hol, int_id_cliente_dat, date_fecha_hol, dou_valor_hol, int_id_holding_pro, text_observacione_hol) VALUES (id_producto, cliente, fecha, valor, id_holding, observacione);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_leer_producto` ()  NO SQL
BEGIN
SELECT var_nombre_pro as nombre_producto, text_descripcion_pro as descripcion_producto, text_observaciones_pro as observacion_producto, int_id_pro as id_producto
FROM tbl_productos;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_leer_todos_datos_personales` ()  NO SQL
BEGIN
SELECT int_id_dat as cedula, var_nombre_dat as nombre, var_apellido_dat as apellido, var_direccion_dat as direcion, int_telefono1_dat as telefono1, int_telefono2_dat as telefono2, int_celular_dat as celular, var_email_dat as email, var_pasaporte_dat as pasaporte, var_referente_dat as referencia, var_observaciones_dat as observaciones
FROM tbl_datos_personales;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_leer_usuario` ()  NO SQL
BEGIN
SELECT int_documento_use as cedula, var_nombre_use as nombre, var_apellido_use as apellido, int_telefono_use as telefono, int_celular_use as celular, 
var_email_use as email, var_estado_use as estado, date_fecha_inicio_use as fecha, var_role_use as role,
var_password_use as pass
FROM tbl_usuario;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_log` (IN `documento` INT, IN `emai` VARCHAR(900), IN `nombre` VARCHAR(900), IN `acion` TEXT, IN `IPreal` VARCHAR(900), IN `ipscript` VARCHAR(900), IN `ipusuario` VARCHAR(900), IN `fecha` DATETIME)  NO SQL
BEGIN
INSERT INTO tbl_log(int_id_log, int_documento_log, var_email_log, var_nombre_log, var_acion_log, var_IPreal_log, var_ipscript_log, var_ipusuario_log, date_fecha_log ) VALUES (null, documento, emai, nombre, acion, IPreal, ipscript, ipusuario, fecha);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_obtener_holding` (IN `id` INT)  NO SQL
BEGIN
SELECT int_id_producto_hol as id_producto, int_id_cliente_dat as cliente, date_fecha_hol as fecha, dou_valor_hol as valor, int_id_holding_pro as id_holding, text_observacione_hol as observacione, tbl_productos.var_nombre_pro as name_producto
FROM tbl_holding INNER JOIN tbl_productos on tbl_holding.int_id_holding_pro=tbl_productos.int_id_pro
WHERE tbl_holding.int_id_cliente_dat=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_obtener_holding_detail` (IN `id` INT)  NO SQL
BEGIN
SELECT int_id_hdet as id_detail, date_fecha_hdet as fecha, text_descipcion_hdet as descipcion, dou_btc_hdet as btc, dou_PrecioBTC_Dia_hdet as PrecioBTC, dou_usd_hdet as usd, dou_cop_hdet as cop, text_SoportePago_hdet as Soporte
FROM tbl_holding_detail
WHERE int_id_hdet=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_producto_ingreso` (IN `nombre` VARCHAR(900), IN `descripcion` VARCHAR(900), IN `observaciones` VARCHAR(900))  NO SQL
BEGIN
INSERT INTO tbl_productos(int_id_pro, var_nombre_pro, text_descripcion_pro, text_observaciones_pro) VALUES (null, nombre, descripcion, observaciones);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_producto_name_obtener` (IN `id` INT)  NO SQL
BEGIN
SELECT var_nombre_pro as name
FROM tbl_productos
WHERE int_id_pro=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_usuario_login` (IN `vemail` VARCHAR(900))  NO SQL
BEGIN
SELECT var_email_use AS email_usuario, var_password_use AS password_usuario, var_nombre_use AS nombre, var_apellido_use AS apellido, int_documento_use as documento, var_role_use as rol
FROM tbl_usuario
WHERE var_email_use = vemail;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_cuentas_cliente`
--

CREATE TABLE `tbl_cuentas_cliente` (
  `int_id_cue` int(11) NOT NULL,
  `int_id_cliente_dat` int(11) NOT NULL,
  `dou_btc_cue` double NOT NULL,
  `var_CryptoDivisa2_cue` varchar(900) NOT NULL,
  `var_CryptoDivisa3_cue` varchar(900) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_datos_personales`
--

CREATE TABLE `tbl_datos_personales` (
  `int_id_dat` int(11) NOT NULL,
  `var_nombre_dat` varchar(900) NOT NULL,
  `var_apellido_dat` varchar(900) NOT NULL,
  `var_direccion_dat` varchar(900) NOT NULL,
  `int_telefono1_dat` int(11) NOT NULL,
  `int_telefono2_dat` int(11) DEFAULT NULL,
  `int_celular_dat` bigint(11) NOT NULL,
  `var_email_dat` varchar(900) NOT NULL,
  `var_pasaporte_dat` varchar(900) NOT NULL,
  `var_referente_dat` varchar(900) DEFAULT NULL,
  `var_observaciones_dat` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tbl_datos_personales`
--

INSERT INTO `tbl_datos_personales` (`int_id_dat`, `var_nombre_dat`, `var_apellido_dat`, `var_direccion_dat`, `int_telefono1_dat`, `int_telefono2_dat`, `int_celular_dat`, `var_email_dat`, `var_pasaporte_dat`, `var_referente_dat`, `var_observaciones_dat`) VALUES
(1, 'Laura', 'Marin', 'Calle', 300, 310, 320, '1@yopmail.com', '1FrBehwrBoasqJZk4Xr6sWojHXRDd61968', 'X', 'Portafolio 01 de 0.059963986 con Pago mensual de: 0.004995 Inicio: 16/jun/2017\r\nBilletera: 1FrBehwrBoasqJZk4Xr6sWojHXRDd61968\r\n\r\nPortafolio 02 de 0.073312009 con Pago mensual de: 0.00610689 Inicio: 3/sep/2017\r\nBilletera: 1FrBehwrBoasqJZk4Xr6sWojHXRDd61968\r\n\r\n\r\n\r\n\r\n\r\n'),
(2, 'Max', 'Martinez', 'Calle', 300, 310, 320, '2@yopmail.com', '17eF2WfDmTGv9J42CH6hpg74mEUoNnLLnd', 'XX', 'Portafolio de 0.071956783 con Pago mensual de: 0.005994 Inicio: 3/sep/2017\r\nBilletera: 17eF2WfDmTGv9J42CH6hpg74mEUoNnLLnd\r\n'),
(3, 'Gerardo', 'Palacio', 'Calle', 300, 310, 320, '3@yopmail.com', 'Sin billetera', 'Robinson Moncada', 'Portafolio de 1 btc con Pago mensual de: 0.1 Inicio: 4/oct/2017\r\nPortafolio de 13.90908047 eth con Pago mensual de: 1.390908047 Inicio: 4/oct/2017\r\nBilletera: 1FrBehwrBoasqJZk4Xr6sWojHXRDd61968\r\n'),
(4, 'John dario', 'Restrepo', 'calle', 300, 300, 300, '1@yopmail.com', '1BG5XVe8Za1kDGurH936DiWjt8rf1wRYde', 'X', '\r\nPortafolio de 0.184789916 con Pago mensual de: 0.015393 Inicio: 1/nov/2017\r\nBilletera: 1BG5XVe8Za1kDGurH936DiWjt8rf1wRYde\r\n'),
(5, 'Marcos', 'Pimienta', 'Calle', 300, 300, 300, '1@yopmail.com', '1CaV8p87BBN1VNscNTndz5hCidBD3K2v5N', 'X', 'Portafolio de 1.245156889 con Pago mensual de: 0.09127 Inicio: 5/sep/2017\r\nBilletera: 1CaV8p87BBN1VNscNTndz5hCidBD3K2v5N'),
(6, 'Sebastian', 'Sanchez', 'Calle', 300, 300, 300, '1@yopmail.com', '37eVYfkssnaoPDBJ26LL5JZnGj1pX53jyx', 'X', 'Portafolio de 0.210684274 con Pago mensual de: 0.01755 Inicio: 6/jun/2017\r\nBilletera: 37eVYfkssnaoPDBJ26LL5JZnGj1pX53jyx'),
(7, 'Lucho', 'Corrales', 'Calle', 300, 300, 300, '1@yopmail.com', '1Drz2aPaiMcB33D2Z94YJ95qhfKDEYsrKe', 'X', '\r\nPortafolio de 0.203106122 con Pago mensual de: 0.01691874 Inicio: 6/jun/2017\r\nBilletera: 1Drz2aPaiMcB33D2Z94YJ95qhfKDEYsrKe'),
(8, 'James', 'Jimenez', 'Calle', 300, 300, 300, '1@yopmail.com', '1NY9AxMSUs33CR6cANTPhg53pUoR3zsw3x', 'X', '\r\nPortafolio de 0.067959184 con Pago mensual de: 0.005661 Inicio: 6/jun/2017\r\nBilletera: 1NY9AxMSUs33CR6cANTPhg53pUoR3zsw3x'),
(9, 'Marko Felipe ', 'Corredor', 'Calle', 300, 300, 300, '1@yopmail.com', '1JqAGz69im7g5TbyYdGyAmutanyLND6SFn', 'X', 'Portafolio 01 de 0.063528916 con Pago mensual de: 0.005291959 Inicio: 7/jul/2017\r\nBilletera: 1JqAGz69im7g5TbyYdGyAmutanyLND6SFn\r\n\r\nPortafolio 02 de 0.01846467 con Pago mensual de: 0.001538107 Inicio: 25/ago/2017\r\nBilletera: 1JqAGz69im7g5TbyYdGyAmutanyLND6SFn\r\n\r\n\r\nPortafolio 03 de 0.019987995 con Pago mensual de: 0.001665 Inicio: 30/ago/2017\r\nBilletera: 1JqAGz69im7g5TbyYdGyAmutanyLND6SFn\r\n\r\nPortafolio 04 de 0.05 con Pago mensual de: 0.004165 Inicio: 12/oct/2017\r\nBilletera: 1JqAGz69im7g5TbyYdGyAmutanyLND6SFn\r\n'),
(10, 'Felipe', 'Estrada', 'Calle', 300, 300, 300, '1@yopmail.com', '16HznRhWKrivKwR3DRKFP2phCQA5wR3Ea1', 'X', '\r\nPortafolio de 1.416566627 con Pago mensual de: 0.118 Inicio: 7/sep/2017\r\nBilletera: 16HznRhWKrivKwR3DRKFP2phCQA5wR3Ea1'),
(11, 'Guillermo ', 'Vanegas', 'Calle', 300, 300, 300, '1@yopmail.com', '17728x9RDL91pq2gS4tsf2AkXvSMEX3fw2', 'X', '\r\nPortafolio 01 de 1.67 con Pago mensual de: 0.122411 Inicio: /oct/2017\r\nBilletera: 17728x9RDL91pq2gS4tsf2AkXvSMEX3fw2\r\n\r\nPortafolio 02 de 1.67 con Pago mensual de: 0.122411 Inicio: /oct/2017\r\nBilletera: 17728x9RDL91pq2gS4tsf2AkXvSMEX3fw2\r\n\r\nPortafolio 03 de 1.67 con Pago mensual de: 0.122411 Inicio: /oct/2017\r\nBilletera: 17728x9RDL91pq2gS4tsf2AkXvSMEX3fw2'),
(12, 'Juan Camilo', 'Vanegas', 'Calle', 300, 300, 300, '1@yopmail.com', '3575Q1QwypnEcYjMTHogNzNEifaJzmvSud', 'X', '\r\nPortafolio de 0.02198 con Pago mensual de: 0.001611134 Inicio: 9/oct/2017\r\nBilletera: 3575Q1QwypnEcYjMTHogNzNEifaJzmvSud'),
(13, 'Silvia', 'Jaramillo', 'Calle', 300, 300, 300, '1@yopmail.com', '163y2iohPD5TyCyZBz6wcyj5t4HbrHMYME', 'x', '\r\nPortafolio de 0.04550339 con Pago mensual de: 0.003335398 Inicio: 10/nov/2017\r\nBilletera: 163y2iohPD5TyCyZBz6wcyj5t4HbrHMYME'),
(14, 'Hernando', 'x', 'Calle', 300, 300, 300, '1@yopmail.com', '17VBb5GGGfCqnPnRpixjeCT6aukjyv2ZC', 'x', '\r\nPortafolio de 0.080135331 con Pago mensual de: 0.006675273 Inicio: 16/jun/2017\r\nBilletera: 17VBb5GGGfCqnPnRpixjeCT6aukjyv2ZC'),
(15, 'Victoria ', 'Jimenez', 'Calle', 300, 300, 300, '1@yopmail.com', '13T5ZFz8115epfHwvKYbtRarP2r4vBLbMB', 'x', '\r\nPortafolio de 1.76261977 con Pago mensual de: 0.146826227 Inicio: 17/ago/2017\r\nBilletera: 13T5ZFz8115epfHwvKYbtRarP2r4vBLbMB'),
(16, 'Jonathan', 'Gomez', 'Calle', 300, 300, 300, '1@yopmail.com', '1GVyYW7wDgAwVzyyuHLTpaXEwNtDYwddqg', 'x', '\r\nPortafolio de 0.0517 con Pago mensual de: 0.00430661 Inicio: 17/oct/2017\r\nBilletera: 1GVyYW7wDgAwVzyyuHLTpaXEwNtDYwddqg'),
(17, 'Daniel', 'Acosta', 'Calle', 300, 300, 300, '1@yopmail.com', '17gFW2RtASHzPdMCHhps8ufWAgTvc9FZaH', 'x', '\r\nPortafolio de 0.36 con Pago mensual de: 0.036 Inicio: 18/may/2017\r\nBilletera: 17gFW2RtASHzPdMCHhps8ufWAgTvc9FZaH'),
(18, 'Camilo', 'Soto', 'Calle', 300, 300, 300, '1@yopmail.com', '1FvNVsYkgcdQv434qBQ7jVSktA2L3GnpqB', 'X', '\r\nPortafolio de 0.72 con Pago mensual de: 0.072 Inicio: 18/may/2017\r\nBilletera: 1FvNVsYkgcdQv434qBQ7jVSktA2L3GnpqB'),
(19, 'Julián', 'Morales ', 'Caldas', 2147483647, 2147483647, 3007760187, 'julianm67@gmail.com', '1GfbKPN7PMwuBpXnAh5Wxz8MD91F8UJQDs', 'X', '\r\nPortafolio 03 de 0.28 con Pago mensual de: 0.028 Inicio: 18/may/2017\r\nBilletera: 1GfbKPN7PMwuBpXnAh5Wxz8MD91F8UJQDs\r\n'),
(20, 'Julian', 'Hernandez', 'Calle', 300, 300, 300, '1@yopmail.com', 'falta billetera', 'x', '\r\nPortafolio de 1 con Pago mensual de: 0.1 Inicio: 18/sep/2017\r\nBilletera: '),
(21, 'Alvaro', 'Barrera', 'Calle', 300, 300, 300, '1@yopmail.com', '1P5P6iL3uPPhzURAT5rWgj4Kims4RFHnrN', 'x', '\r\nPortafolio de 0.350300564 con Pago mensual de: 0.029180037 Inicio: 20/jun/2017\r\nBilletera: 1P5P6iL3uPPhzURAT5rWgj4Kims4RFHnrN'),
(22, 'Daniela', 'Cataño', 'Calle', 300, 300, 300, '1@yopmail.com', '1KUey2qboTbu79s1WsuVnSCwM9Z5NJpSY8', 'x', '\r\nPortafolio de 0.119927971 con Pago mensual de: 0.00999 Inicio: 20/jun/2017\r\nBilletera: 1KUey2qboTbu79s1WsuVnSCwM9Z5NJpSY8'),
(23, 'Michael', 'Gutierrez', 'Calle', 300, 300, 300, '1@yopmail.com', '3J8ExtyUucKHrwS42Ck4jsJjf5mbwxfAmU', 'x', '\r\nPortafolio de 0.180072029 con Pago mensual de: 0.015 Inicio: 22/ago/2017\r\nBilletera: 3J8ExtyUucKHrwS42Ck4jsJjf5mbwxfAmU'),
(24, 'James y Hernan', 'Henao y Correa', 'Calle', 300, 300, 300, '1@yopmail.com', '1gmmvotZCpnPDe92827pNJYvDMZzbutEt', 'x', '\r\nPortafolio de 0.16 con Pago mensual de: 0.016 Inicio: 28/may/2017\r\nBilletera: 1gmmvotZCpnPDe92827pNJYvDMZzbutEt'),
(25, 'Mateo', 'Corredor', 'Calle', 300, 300, 300, '1@yopmail.com', '19rq6381BAXSZ7BrVMjdk2GBf5FpP78rXa', 'x', '\r\nPortafolio de 0.636143891 con Pago mensual de: 0.052990786 Inicio: 31/ago/2017\r\nBilletera: 19rq6381BAXSZ7BrVMjdk2GBf5FpP78rXa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_holding`
--

CREATE TABLE `tbl_holding` (
  `int_id_producto_hol` int(11) NOT NULL,
  `int_id_cliente_dat` int(11) NOT NULL,
  `date_fecha_hol` date NOT NULL,
  `dou_valor_hol` double NOT NULL,
  `int_id_holding_pro` int(11) NOT NULL,
  `text_observacione_hol` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tbl_holding`
--

INSERT INTO `tbl_holding` (`int_id_producto_hol`, `int_id_cliente_dat`, `date_fecha_hol`, `dou_valor_hol`, `int_id_holding_pro`, `text_observacione_hol`) VALUES
(1, 1, '2017-06-16', 0.05996398559, 5, 'Portafolio 1 de 0.05996398559 BTC\r\nPago mensual: 0.004995'),
(2, 1, '2017-09-03', 0.073312009, 5, 'Portafolio 2 de 0.073312009 BTC Pago mensual: 0.00610689'),
(3, 2, '2017-09-03', 0.07195678271, 5, 'Portafolio 1 de 0.07195678271 BTC\r\nPago mensual: 0.005994'),
(4, 3, '2017-10-04', 1, 5, 'Portafolio 1 de 1 BTC\r\nPago mensual: 0.1'),
(5, 5, '2017-09-05', 1.245156889, 5, 'Portafolio 1 de 1.245156889BTC\r\nPago mensual: 0.09127'),
(6, 4, '2017-11-16', 0.184789916, 5, 'Portafolio 2 de 0.184789916BTC\r\nPago mensual: 0.015393'),
(7, 6, '2017-06-06', 0.2106842737, 5, 'Portafolio 1 de 0.2106842737BTC\r\nPago mensual: 0.01755'),
(8, 7, '2017-06-06', 0.2031061224, 5, 'Portafolio 2 de 0.2031061224 BTC\r\nPago mensual: 0.01691874'),
(9, 8, '2017-06-06', 0.06795918367, 5, 'Portafolio 1 de 0.06795918367 BTC\r\nPago mensual: 0.005661'),
(10, 9, '2017-07-07', 0.06352891649, 5, 'Portafolio 1 de 0.06352891649 BTCPago mensual: 0.005291958744'),
(11, 9, '2017-08-25', 0.01846467011, 5, 'Portafolio 2 de 0.01846467011 BTC\r\nPago mensual: 0.00153810702'),
(12, 9, '2017-08-30', 0.0199879952, 5, 'Portafolio 3 de 0.0199879952 BTC\r\nPago mensual: 0.001665'),
(13, 9, '2017-10-12', 0.05, 5, 'Portafolio 4 de 0.05 BTC\r\nPago mensual: 0.004165'),
(14, 10, '2017-09-07', 1.416566627, 5, 'Portafolio 1 de 1.416566627 BTC\r\nPago mensual: 0.118'),
(15, 11, '2017-10-09', 0.122411, 3, 'Portafolio 1 de 1.67 BTC\r\nPago mensual: 0.122411'),
(16, 11, '2017-11-09', 0.122411, 5, 'Portafolio 1 de 1.67 BTC\r\nPago mensual: 0.122411'),
(17, 11, '2017-11-09', 0.122411, 5, 'Portafolio 1 de 1.67 BTC\r\nPago mensual: 0.122411'),
(18, 9, '2017-11-17', 0.000490927, 5, 'Portafolio 5 de 0.066975 BTC\r\nPago mensual: 0.000490927'),
(19, 12, '2017-10-09', 0.001611134, 5, 'Portafolio 2 de 0.02198 BTC\r\nPago mensual: 0.001611134'),
(20, 13, '2017-11-13', 0.003335398, 5, 'Portafolio  de 0.04550339 BTC\r\nPago mensual: 0.003335398'),
(21, 14, '2017-06-16', 0.006675273, 5, 'Portafolio  de 0.080135331 BTC\r\nPago mensual: 0.006675273'),
(22, 15, '2017-08-17', 0.146826227, 5, 'Portafolio de 1.76261977 BTC\r\nPago mensual: 0.146826227'),
(23, 16, '2017-10-17', 0.00430661, 5, 'Portafolio de 0.0517 BTC\r\nPago mensual: 0.00430661');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_holding_detail`
--

CREATE TABLE `tbl_holding_detail` (
  `int_id_hdet` int(11) NOT NULL,
  `int_id_producto_hol` int(11) NOT NULL,
  `date_fecha_hdet` date NOT NULL,
  `text_descipcion_hdet` text NOT NULL,
  `dou_btc_hdet` double NOT NULL,
  `dou_PrecioBTC_Dia_hdet` double NOT NULL,
  `dou_usd_hdet` double NOT NULL,
  `dou_cop_hdet` double NOT NULL,
  `text_SoportePago_hdet` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tbl_holding_detail`
--

INSERT INTO `tbl_holding_detail` (`int_id_hdet`, `int_id_producto_hol`, `date_fecha_hdet`, `text_descipcion_hdet`, `dou_btc_hdet`, `dou_PrecioBTC_Dia_hdet`, `dou_usd_hdet`, `dou_cop_hdet`, `text_SoportePago_hdet`) VALUES
(1, 2, '2017-09-03', '0', 0.073312009, 2, 0, 0, 'view/imagenes/Soportes/soporte_2017-10-25_(05_20_14)_02 Pago Laura Marin Octubre 2017.jpeg'),
(2, 1, '2017-11-15', '0', 0, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-15_(03_32_39)_Hexocoin_Logo_1 mod.jpg'),
(3, 3, '2017-10-03', '0', 0.005994, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-15_(04_07_37)_Hexocoin_Logo_1 mod.jpg'),
(4, 4, '2017-11-04', '0', 0.1, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-15_(04_43_01)_Hexocoin_Logo_1 mod.jpg'),
(5, 5, '2017-10-05', '0', 0.09127, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-16_(03_50_57)_Hexocoin_Logo_1 mod.jpg'),
(6, 6, '2017-12-01', '0', 0.015393, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-16_(04_01_12)_Hexocoin_Logo_1 mod.jpg'),
(7, 7, '2017-07-06', '0', 0.01755, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-16_(04_07_05)_Hexocoin_Logo_1 mod.jpg'),
(8, 7, '2017-08-06', '0', 0.01755, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-16_(04_10_00)_Hexocoin_Logo_1 mod.jpg'),
(9, 8, '2017-07-06', '0', 0.01691874, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-16_(04_12_51)_Hexocoin_Logo_1 mod.jpg'),
(10, 9, '2017-07-06', '0', 0.005661, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-16_(04_21_43)_Hexocoin_Logo_1 mod.jpg'),
(11, 10, '2017-08-07', '0', 0.005291958744, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-16_(04_24_53)_Hexocoin_Logo_1 mod.jpg'),
(12, 11, '2017-09-25', '0', 0.00153810702, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-16_(04_27_48)_Hexocoin_Logo_1 mod.jpg'),
(13, 12, '2017-09-30', '0', 0.001665, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-16_(04_31_32)_Hexocoin_Logo_1 mod.jpg'),
(14, 13, '2017-11-12', '0', 0.004165, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-16_(04_33_42)_Hexocoin_Logo_1 mod.jpg'),
(15, 14, '2017-10-07', '0', 0.118, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-16_(04_38_01)_Hexocoin_Logo_1 mod.jpg'),
(16, 15, '2017-11-09', '0', 0.122411, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-22_(04_40_01)_Hexocoin_Logo_1 mod.jpg'),
(17, 16, '2017-11-22', '0', 0.122411, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-22_(04_42_03)_Hexocoin_Logo_1 mod.jpg'),
(18, 17, '2017-11-22', '0', 0.122411, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-22_(04_43_36)_Hexocoin_Logo_1 mod.jpg'),
(19, 18, '2017-12-17', '0', 0.000490927, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-22_(04_58_01)_Hexocoin_Logo_1 mod.jpg'),
(20, 19, '2017-11-09', '0', 0.001611134, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-22_(05_02_41)_Hexocoin_Logo_1 mod.jpg'),
(21, 20, '2017-12-13', '0', 0.003335398, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-22_(05_06_45)_Hexocoin_Logo_1 mod.jpg'),
(22, 21, '2017-07-16', '0', 0.006675273, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-22_(05_21_34)_Hexocoin_Logo_1 mod.jpg'),
(23, 22, '2017-11-22', '0', 0.146826227, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-22_(05_23_50)_Hexocoin_Logo_1 mod.jpg'),
(24, 23, '2017-11-17', '0', 0.00430661, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-11-22_(05_29_50)_Hexocoin_Logo_1 mod.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_log`
--

CREATE TABLE `tbl_log` (
  `int_id_log` int(11) NOT NULL,
  `int_documento_log` int(11) NOT NULL,
  `var_email_log` varchar(900) NOT NULL,
  `var_nombre_log` varchar(900) NOT NULL,
  `var_acion_log` text NOT NULL,
  `var_IPreal_log` varchar(900) NOT NULL,
  `var_ipscript_log` varchar(900) NOT NULL,
  `var_ipusuario_log` varchar(900) NOT NULL,
  `date_fecha_log` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tbl_log`
--

INSERT INTO `tbl_log` (`int_id_log`, `int_documento_log`, `var_email_log`, `var_nombre_log`, `var_acion_log`, `var_IPreal_log`, `var_ipscript_log`, `var_ipusuario_log`, `date_fecha_log`) VALUES
(27, 1000898270, 'j.arley111@gmail.com', 'yeisson1 sanchez1', 'agrego usuario 1', '::1', '::1', '::1', '2017-10-04 22:31:01'),
(28, 1, 'basico@usurio.com', 'BASICO S', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 22:31:17'),
(29, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 23:01:42'),
(30, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'actualizo producto Mineria', '::1', '::1', '::1', '2017-10-04 23:02:56'),
(31, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego cliente 72774495', '::1', '::1', '::1', '2017-10-04 23:03:57'),
(32, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'subio soporte del producto 24 con la ruta: view/imagenes/Soportes/soporte_2017-10-04_(23_17_54)_14611157_1148902878554181_478933829470112120_n.png', '::1', '::1', '::1', '2017-10-04 23:17:54'),
(33, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego holding 24', '::1', '::1', '::1', '2017-10-04 23:17:54'),
(34, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego un holding detail del producto24', '::1', '::1', '::1', '2017-10-04 23:17:54'),
(35, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'subio soporte del producto 24 con la ruta: view/imagenes/Soportes/soporte_2017-10-04_(23_19_10)_14910341_1148902848554184_5963603856674729158_n.png', '::1', '::1', '::1', '2017-10-04 23:19:10'),
(36, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego un holding detail del producto', '::1', '::1', '::1', '2017-10-04 23:19:10'),
(37, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'subio soporte del producto 24 con la ruta: view/imagenes/Soportes/soporte_2017-10-04_(23_24_36)_14610878_1148902861887516_7196484191429534935_n.png', '::1', '::1', '::1', '2017-10-04 23:24:36'),
(38, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego un holding detail del producto', '::1', '::1', '::1', '2017-10-04 23:24:36'),
(39, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'subio soporte del producto 324234 con la ruta: view/imagenes/Soportes/soporte_2017-10-04_(23_31_05)_14906970_1148902798554189_8870837068901531359_n.png', '::1', '::1', '::1', '2017-10-04 23:31:05'),
(40, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego holding 324234', '::1', '::1', '::1', '2017-10-04 23:31:05'),
(41, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego un holding detail del producto324234', '::1', '::1', '::1', '2017-10-04 23:31:05'),
(42, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'subio soporte del producto 24 con la ruta: view/imagenes/Soportes/soporte_2017-10-04_(23_45_28)_14563376_1148902808554188_7292427752301160538_n.png', '::1', '::1', '::1', '2017-10-04 23:45:28'),
(43, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego un holding detail del producto', '::1', '::1', '::1', '2017-10-04 23:45:28'),
(44, 1, 'basico@usurio.com', 'BASICO S', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 23:47:08'),
(45, 1000898270, 'j.arley111@gmail.com', 'yeisson1 sanchez1', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 23:48:54'),
(46, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-12 18:24:19'),
(47, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'borro cliente 3123', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-12 18:24:46'),
(48, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'borro usuario 1000898270', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-12 18:24:58'),
(49, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'actualizo producto Mineria', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-12 18:26:00'),
(50, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'borro holding 2323', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-12 18:26:34'),
(51, 1, 'basico@usurio.com', 'BASICO S', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-14 21:52:28'),
(52, 1, 'basico@usurio.com', 'BASICO S', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-14 21:54:18'),
(53, 1, 'basico@usurio.com', 'BASICO S', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-14 22:34:44'),
(54, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-14 22:36:06'),
(55, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'actualizo usuario 1', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-14 22:36:24'),
(56, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-14 22:37:36'),
(57, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego usuario 666', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-14 22:39:05'),
(58, 666, 'julianm67@gmail.com', 'Julian Morales', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-14 22:41:05'),
(59, 1, 'basico@usuario.com', 'BASICO S', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-14 23:00:40'),
(60, 666, 'julianm67@gmail.com', 'Julian Morales', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-17 05:04:48'),
(61, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 1', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-17 05:17:03'),
(62, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-17 14:19:28'),
(63, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-17 17:04:29'),
(64, 1, 'basico@usuario.com', 'BASICO S', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-18 01:11:36'),
(65, 666, 'julianm67@gmail.com', 'Julian Morales', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-18 01:38:33'),
(66, 666, 'julianm67@gmail.com', 'Julian Morales', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-18 01:55:32'),
(67, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-18 05:39:03'),
(68, 666, 'julianm67@gmail.com', 'Julian Morales', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-25 03:47:56'),
(69, 666, 'julianm67@gmail.com', 'Julian Morales', 'actualizo cliente 1', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-25 05:00:21'),
(70, 666, 'julianm67@gmail.com', 'Julian Morales', 'actualizo cliente 1', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-25 05:13:46'),
(71, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 02 con la ruta: view/imagenes/Soportes/soporte_2017-10-25_(05_20_14)_02 Pago Laura Marin Octubre 2017.jpeg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-25 05:20:14'),
(72, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 02', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-25 05:20:14'),
(73, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto02', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-25 05:20:14'),
(74, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 2', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-25 05:37:59'),
(75, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 3', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-10-25 05:51:13'),
(76, 1, 'basico@usuario.com', 'BASICO S', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-10 20:27:31'),
(77, 666, 'julianm67@gmail.com', 'Julian Morales', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 02:28:58'),
(78, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 4', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 03:15:25'),
(79, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 5', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 03:24:02'),
(80, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 6', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 03:31:00'),
(81, 666, 'julianm67@gmail.com', 'Julian Morales', 'actualizo cliente 5', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 03:31:22'),
(82, 666, 'julianm67@gmail.com', 'Julian Morales', 'actualizo cliente 6', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 03:31:56'),
(83, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 7', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 03:37:17'),
(84, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 8', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 03:53:35'),
(85, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 9', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 04:10:14'),
(86, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 10', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 04:17:04'),
(87, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 11', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 04:20:16'),
(88, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 12', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 04:26:26'),
(89, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 13', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 04:31:57'),
(90, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 14', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 04:38:00'),
(91, 666, 'julianm67@gmail.com', 'Julian Morales', 'actualizo cliente 9', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 04:39:47'),
(92, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 15', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 04:44:42'),
(93, 666, 'julianm67@gmail.com', 'Julian Morales', 'actualizo cliente 1', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 04:45:59'),
(94, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 16', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 04:49:20'),
(95, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 17', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 04:53:53'),
(96, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 18', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 04:58:39'),
(97, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 19', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 05:03:49'),
(98, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 20', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 05:06:37'),
(99, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 21', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 05:12:20'),
(100, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 22', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 05:15:33'),
(101, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 23', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 05:17:39'),
(102, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 24', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 05:20:13'),
(103, 666, 'julianm67@gmail.com', 'Julian Morales', 'actualizo cliente 9', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 05:21:49'),
(104, 666, 'julianm67@gmail.com', 'Julian Morales', 'actualizo cliente 9', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 05:25:02'),
(105, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego cliente 25', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-14 05:26:55'),
(106, 666, 'julianm67@gmail.com', 'Julian Morales', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-15 03:14:36'),
(107, 666, 'julianm67@gmail.com', 'Julian Morales', 'actualizo holding 2', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-15 03:23:09'),
(108, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 1 con la ruta: view/imagenes/Soportes/soporte_2017-11-15_(03_32_39)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-15 03:32:39'),
(109, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 1', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-15 03:32:39'),
(110, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto1', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-15 03:32:39'),
(111, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 1 con la ruta: view/imagenes/Soportes/soporte_2017-11-15_(04_03_50)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-15 04:03:50'),
(112, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 01 con la ruta: view/imagenes/Soportes/soporte_2017-11-15_(04_07_06)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-15 04:07:06'),
(113, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 3 con la ruta: view/imagenes/Soportes/soporte_2017-11-15_(04_07_37)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-15 04:07:37'),
(114, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 3', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-15 04:07:37'),
(115, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto3', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-15 04:07:37'),
(116, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 4 con la ruta: view/imagenes/Soportes/soporte_2017-11-15_(04_43_01)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-15 04:43:01'),
(117, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 4', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-15 04:43:01'),
(118, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto4', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-15 04:43:01'),
(119, 666, 'julianm67@gmail.com', 'Julian Morales', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 03:35:26'),
(120, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 5 con la ruta: view/imagenes/Soportes/soporte_2017-11-16_(03_50_57)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 03:50:57'),
(121, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 5', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 03:50:57'),
(122, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto5', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 03:50:57'),
(123, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 6 con la ruta: view/imagenes/Soportes/soporte_2017-11-16_(04_01_12)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:01:12'),
(124, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 6', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:01:12'),
(125, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto6', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:01:12'),
(126, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 7 con la ruta: view/imagenes/Soportes/soporte_2017-11-16_(04_07_05)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:07:05'),
(127, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 7', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:07:05'),
(128, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto7', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:07:05'),
(129, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 7 con la ruta: view/imagenes/Soportes/soporte_2017-11-16_(04_10_00)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:10:00'),
(130, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:10:00'),
(131, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 8 con la ruta: view/imagenes/Soportes/soporte_2017-11-16_(04_12_51)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:12:51'),
(132, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 8', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:12:51'),
(133, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto8', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:12:51'),
(134, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 9 con la ruta: view/imagenes/Soportes/soporte_2017-11-16_(04_21_43)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:21:43'),
(135, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 9', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:21:43'),
(136, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto9', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:21:43'),
(137, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 10 con la ruta: view/imagenes/Soportes/soporte_2017-11-16_(04_24_53)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:24:53'),
(138, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 10', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:24:53'),
(139, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto10', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:24:53'),
(140, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 11 con la ruta: view/imagenes/Soportes/soporte_2017-11-16_(04_27_48)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:27:48'),
(141, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 11', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:27:48'),
(142, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto11', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:27:48'),
(143, 666, 'julianm67@gmail.com', 'Julian Morales', 'actualizo holding 10', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:28:52'),
(144, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 12 con la ruta: view/imagenes/Soportes/soporte_2017-11-16_(04_31_32)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:31:32'),
(145, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 12', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:31:32'),
(146, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto12', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:31:32'),
(147, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 13 con la ruta: view/imagenes/Soportes/soporte_2017-11-16_(04_33_42)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:33:42'),
(148, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 13', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:33:42'),
(149, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto13', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:33:42'),
(150, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 14 con la ruta: view/imagenes/Soportes/soporte_2017-11-16_(04_38_01)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:38:01'),
(151, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 14', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:38:01'),
(152, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto14', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 04:38:01'),
(153, 1, 'basico@usuario.com', 'BASICO S', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 21:50:51'),
(154, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-16 21:51:11'),
(155, 666, 'julianm67@gmail.com', 'Julian Morales', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-17 18:38:04'),
(156, 666, 'julianm67@gmail.com', 'Julian Morales', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 03:38:42'),
(157, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 15 con la ruta: view/imagenes/Soportes/soporte_2017-11-22_(04_40_01)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 04:40:01'),
(158, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 15', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 04:40:02'),
(159, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto15', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 04:40:02'),
(160, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 16 con la ruta: view/imagenes/Soportes/soporte_2017-11-22_(04_42_03)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 04:42:03'),
(161, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 16', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 04:42:03'),
(162, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto16', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 04:42:03'),
(163, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 16 con la ruta: view/imagenes/Soportes/soporte_2017-11-22_(04_43_11)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 04:43:11'),
(164, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 17 con la ruta: view/imagenes/Soportes/soporte_2017-11-22_(04_43_36)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 04:43:36'),
(165, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 17', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 04:43:36'),
(166, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto17', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 04:43:36'),
(167, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 17 con la ruta: view/imagenes/Soportes/soporte_2017-11-22_(04_57_22)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 04:57:22'),
(168, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 17 con la ruta: view/imagenes/Soportes/soporte_2017-11-22_(04_57_35)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 04:57:35'),
(169, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 18 con la ruta: view/imagenes/Soportes/soporte_2017-11-22_(04_58_01)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 04:58:01'),
(170, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 18', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 04:58:01'),
(171, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto18', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 04:58:01'),
(172, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 19 con la ruta: view/imagenes/Soportes/soporte_2017-11-22_(05_02_41)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:02:41'),
(173, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 19', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:02:41'),
(174, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto19', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:02:41'),
(175, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 20 con la ruta: view/imagenes/Soportes/soporte_2017-11-22_(05_06_45)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:06:45'),
(176, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 20', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:06:45'),
(177, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto20', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:06:45'),
(178, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 20 con la ruta: view/imagenes/Soportes/soporte_2017-11-22_(05_21_20)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:21:20'),
(179, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 21 con la ruta: view/imagenes/Soportes/soporte_2017-11-22_(05_21_34)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:21:34'),
(180, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 21', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:21:34'),
(181, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto21', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:21:34'),
(182, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 22 con la ruta: view/imagenes/Soportes/soporte_2017-11-22_(05_23_50)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:23:50'),
(183, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 22', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:23:50'),
(184, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto22', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:23:50'),
(185, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 22 con la ruta: view/imagenes/Soportes/soporte_2017-11-22_(05_29_35)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:29:35'),
(186, 666, 'julianm67@gmail.com', 'Julian Morales', 'subio soporte del producto 23 con la ruta: view/imagenes/Soportes/soporte_2017-11-22_(05_29_50)_Hexocoin_Logo_1 mod.jpg', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:29:50'),
(187, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego holding 23', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:29:50'),
(188, 666, 'julianm67@gmail.com', 'Julian Morales', 'agrego un holding detail del producto23', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 05:29:50'),
(189, 1, 'basico@usuario.com', 'BASICO S', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2017-11-22 16:24:41'),
(190, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'inicio de sesion', '10.0.248.1', '10.0.0.14', '10.0.248.1', '2018-07-06 04:10:41');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_productos`
--

CREATE TABLE `tbl_productos` (
  `int_id_pro` int(11) NOT NULL,
  `var_nombre_pro` varchar(900) NOT NULL,
  `text_descripcion_pro` text NOT NULL,
  `text_observaciones_pro` varchar(900) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tbl_productos`
--

INSERT INTO `tbl_productos` (`int_id_pro`, `var_nombre_pro`, `text_descripcion_pro`, `text_observaciones_pro`) VALUES
(3, 'Mineria', 'Producción por minería', 'Inicia en Octubre'),
(5, 'Portafolio', 'Movimientos en Trading', 'Generación de recursos por trading');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_usuario`
--

CREATE TABLE `tbl_usuario` (
  `int_documento_use` int(11) NOT NULL,
  `var_nombre_use` varchar(900) NOT NULL,
  `var_apellido_use` varchar(900) NOT NULL,
  `int_telefono_use` int(11) NOT NULL,
  `int_celular_use` bigint(11) NOT NULL,
  `var_email_use` varchar(900) NOT NULL,
  `var_password_use` varchar(900) NOT NULL,
  `var_estado_use` varchar(200) NOT NULL,
  `date_fecha_inicio_use` date NOT NULL,
  `var_role_use` varchar(900) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tbl_usuario`
--

INSERT INTO `tbl_usuario` (`int_documento_use`, `var_nombre_use`, `var_apellido_use`, `int_telefono_use`, `int_celular_use`, `var_email_use`, `var_password_use`, `var_estado_use`, `date_fecha_inicio_use`, `var_role_use`) VALUES
(1, 'BASICO', 'S', 2, 234, 'basico@usuario.com', '8phxy+annn5gqhb1ub0NrvERYzrJLSZHclqqUQ0+eGU=', 'Activo', '2017-10-04', 'Básico'),
(666, 'Julian', 'Morales', 222222, 3007760187, 'julianm67@gmail.com', 'LMdzrBTCTqwstUHVxB5hQE0X+N0Qi9Rm+m27vVT0bD8=', 'Activo', '2017-10-14', 'Administrador'),
(71774495, 'Julian', 'Galeano', 5454, 543543543, 'julian.galeano@pascualbravo.edu.co', 'Bf6/4MTVO7Qus4xVOXYPz5n3F0cVku1zawAhaUrZXcE=', 'Activo', '2017-10-04', 'Administrador');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tbl_cuentas_cliente`
--
ALTER TABLE `tbl_cuentas_cliente`
  ADD PRIMARY KEY (`int_id_cue`),
  ADD KEY `FK_TBL_DATOS_PERSONALES` (`int_id_cliente_dat`);

--
-- Indices de la tabla `tbl_datos_personales`
--
ALTER TABLE `tbl_datos_personales`
  ADD PRIMARY KEY (`int_id_dat`);

--
-- Indices de la tabla `tbl_holding`
--
ALTER TABLE `tbl_holding`
  ADD PRIMARY KEY (`int_id_producto_hol`),
  ADD KEY `FK_TBL_HOLDING` (`int_id_cliente_dat`),
  ADD KEY `FK_TBL_HOLDING_2` (`int_id_holding_pro`) USING BTREE;

--
-- Indices de la tabla `tbl_holding_detail`
--
ALTER TABLE `tbl_holding_detail`
  ADD PRIMARY KEY (`int_id_hdet`),
  ADD KEY `FK_TBL_HOLDING_DETAIL` (`int_id_producto_hol`);

--
-- Indices de la tabla `tbl_log`
--
ALTER TABLE `tbl_log`
  ADD PRIMARY KEY (`int_id_log`);

--
-- Indices de la tabla `tbl_productos`
--
ALTER TABLE `tbl_productos`
  ADD PRIMARY KEY (`int_id_pro`);

--
-- Indices de la tabla `tbl_usuario`
--
ALTER TABLE `tbl_usuario`
  ADD PRIMARY KEY (`int_documento_use`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tbl_cuentas_cliente`
--
ALTER TABLE `tbl_cuentas_cliente`
  MODIFY `int_id_cue` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `tbl_holding_detail`
--
ALTER TABLE `tbl_holding_detail`
  MODIFY `int_id_hdet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT de la tabla `tbl_log`
--
ALTER TABLE `tbl_log`
  MODIFY `int_id_log` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=191;
--
-- AUTO_INCREMENT de la tabla `tbl_productos`
--
ALTER TABLE `tbl_productos`
  MODIFY `int_id_pro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `tbl_cuentas_cliente`
--
ALTER TABLE `tbl_cuentas_cliente`
  ADD CONSTRAINT `tbl_cuentas_cliente_ibfk_1` FOREIGN KEY (`int_id_cliente_dat`) REFERENCES `tbl_datos_personales` (`int_id_dat`);

--
-- Filtros para la tabla `tbl_holding`
--
ALTER TABLE `tbl_holding`
  ADD CONSTRAINT `tbl_holding_ibfk_1` FOREIGN KEY (`int_id_cliente_dat`) REFERENCES `tbl_datos_personales` (`int_id_dat`),
  ADD CONSTRAINT `tbl_holding_ibfk_2` FOREIGN KEY (`int_id_holding_pro`) REFERENCES `tbl_productos` (`int_id_pro`);

--
-- Filtros para la tabla `tbl_holding_detail`
--
ALTER TABLE `tbl_holding_detail`
  ADD CONSTRAINT `tbl_holding_detail_ibfk_1` FOREIGN KEY (`int_id_producto_hol`) REFERENCES `tbl_holding` (`int_id_producto_hol`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
