<?php
class login_modelo
{
    private $DB;
    private $user;

    public function __construct()
    {
        $this->DB   = conexion::getConnection();
        $this->user = array();
    }

    public function loginCliente($ema, $pas)
    {
        $query = $this->DB->query("CALL sp_login_cliente('" . $ema . "')");
        $fila  = $query->fetch_object();
        $array = json_decode(json_encode($fila), true);
        if (!empty($array)) {
            if (desencriptar($array["password_cliente"]) == $pas) {
                if ($array["confirmacion"]=='1') {
                   $user[] = 7;
                   $user[] = $array["email_cliente"];
                   $user[] = $array["nombre_cliente"] . " " . $array["apellid_cliente"];
                   $user[] = $array["documento_cliente"];
                }else{
                    $user[] = 10; //Usuario valido, contraseña incorrecta
                    $user[] = "";
                }
                
            } else {
                $user[] = 8; //Usuario valido, contraseña incorrecta
                $user[] = "";
            }
        } else {
            $user[] = 9; //Usuario no existe
            $user[] = "";
        }
        return $user;
    }

    public function loginUser($ema, $pas)
    {
        $query = $this->DB->query("CALL sp_login_usuario ('" . $ema . "')");
        $fila  = $query->fetch_object();
        $array = json_decode(json_encode($fila), true);
        if (!empty($array)) {
            if (desencriptar($array["password_usuario"]) == $pas) {
                   $user[] = 11;
                   $user[] = $array["email_usuario"];
                   $user[] = $array["nombre_usuario"] . " " . $array["apellid_usuario"];
                   $user[] = $array["documento_usuario"];
                   $user[] = $array["rol"];
            } else {
                $user[] = 12; //Usuario valido, contraseña incorrecta
                $user[] = "";
            }
        } else {
            $user[] = 13; //Usuario no existe
            $user[] = "";
        }
        return $user;
    }
}
