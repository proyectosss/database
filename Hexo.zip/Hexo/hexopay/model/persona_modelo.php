<?php
class persona_modelo
{
    private $DB;
    private $persona;

    public function __construct()
    {
        $this->DB      = conexion::getConnection();
        $this->persona = array();
    }

    public function save($DocumentoPerso, $nombrePerso, $ApellidoPerso, $TelefonoPerso, $CelularPerso, $emailPerso, $DirecionPerso, $billetera1, $billetera2, $cuenta, $entidadPerso, $tipo_cuentaPerso, $code, $numero, $pass)
    {

        $query = "CALL sp_ingreso_persona  ('" . $DocumentoPerso . "', '" . $nombrePerso . "', '" . $ApellidoPerso . "', '" . $TelefonoPerso . "', '" . $CelularPerso . "', '" . $emailPerso . "', '" . $DirecionPerso . "', '" . $billetera1 . "', '" . $billetera2 . "', '" . $cuenta . "', '" . $entidadPerso . "', '" . $tipo_cuentaPerso . "', '0', '" . $code . "', '0', '" . $numero . "', '" . $pass . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }


    public function query($id)
    {
        $query = $this->DB->query("CALL sp_validacion_person('" . $id . "')");
        while ($fila = $query->fetch_assoc()) {
            $this->persona = $fila;
        }
        return $this->persona;
    }

    public function update($id)
    {
        $query = "CALL sp_actualizar_verificacion ('" . $id . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }
}
?>