<?php
class banco_modelo
{
    private $DB;
    private $banco;

    public function __construct()
    {
        $this->DB     = conexion::getConnection();
        $this->banco = array();
    }

    public function banco()
    {
        $query = $this->DB->query("CALL sp_leer_banco()");
        while ($fila = $query->fetch_assoc()) {
            $this->banco[] = $fila;
        }
        return $this->banco;
    }
}
?>
