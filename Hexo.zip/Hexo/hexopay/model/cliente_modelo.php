<?php
class cliente_modelo
{
    private $DB;
    private $cliente;

    public function __construct()
    {
        $this->DB      = conexion::getConnection();
        $this->cliente = array();
    }

    public function save($DocumentoPerso, $nombrePerso, $ApellidoPerso, $DirecionPerso, $emailPerso, $Telefono1Perso, $Telefono2Perso, $CelularPerso, $pasaportePerso, $referentePerso, $ObservacionesPerso, $billetera1, $billetera2)
    {

        $query = "CALL sp_datos_personales_ingreso('" . $DocumentoPerso . "', '" . $nombrePerso . "', '" . $ApellidoPerso . "', '" . $Telefono1Perso . "', '" . $DirecionPerso . "', '" . $Telefono2Perso . "', '" . $CelularPerso . "', '" . $emailPerso . "', '" . $pasaportePerso . "', '" . $referentePerso . "', '" . $ObservacionesPerso . "', '" . $billetera1 . "', '" . $billetera2 . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }

    public function get()
    {
        $query = $this->DB->query("CALL sp_leer_todos_datos_personales()");
        while ($fila = $query->fetch_assoc()) {
            $this->cliente[] = $fila;
        }
        return $this->cliente;
    }

    public function query($id)
    {
        $query = $this->DB->query("CALL sp_consulta_datos_personales('" . $id . "')");
        while ($fila = $query->fetch_assoc()) {
            $this->cliente = $fila;
        }
        return $this->cliente;
    }

    public function update($DocumentoPerso, $nombrePerso, $ApellidoPerso, $DirecionPerso, $emailPerso, $Telefono1Perso, $Telefono2Perso, $CelularPerso, $pasaportePerso, $referentePerso, $ObservacionesPerso, $billetera1, $billetera2)
    {
        $query = "CALL sp_actualizar_datos_personales('" . $nombrePerso . "', '" . $ApellidoPerso . "', '" . $DirecionPerso . "', '" . $Telefono1Perso . "', '" . $Telefono2Perso . "', '" . $CelularPerso . "', '" . $emailPerso . "', '" . $pasaportePerso . "', '" . $referentePerso . "', '" . $ObservacionesPerso . "', '" . $DocumentoPerso . "', '" . $billetera1 . "', '" . $billetera2 . "')";

        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }

    public function delete($int_id)
    {
        $query = "CALL sp_eliminar_datos_personales('" . $int_id . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }
}
