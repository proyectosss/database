<?php
class orden_modelo
{
    private $DB;
    private $orden;

    public function __construct()
    {
        $this->DB   = conexion::getConnection();
        $this->orden = array();
    }

    public function ordenSinValidar()
    {
        $query = $this->DB->query("CALL sp_leer_orden()");
        while ($fila = $query->fetch_assoc()) {
            $this->orden[] = $fila;
        }
        return $this->orden;
    }

    public function consultar_orden($id)
    {
        $query = $this->DB->query("CALL sp_consultar_orden('".$id."')");
        while ($fila = $query->fetch_assoc()) {
            $this->orden = $fila;
        }
        return $this->orden;
    }

    public function save($fecha, $valororden, $cantidadorden, $estado, $cedula_use, $documento_per, $totalorden, $comisionorden)
    {

        $query = "CALL sp_ingresar_orden   ('" . $fecha . "', '" . $valororden . "', '" . $cantidadorden . "', '" . $estado . "', '" . $cedula_use . "', '" . $documento_per . "', '" . $totalorden . "', '" . $comisionorden . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }

    public function save_transacion($id, $fechaorden, $entidadorden, $valororden, $cantidadorden, $fecha)
    {

        $query = "CALL sp_ingresar_transacion ('" . $id . "', '" . $fechaorden . "', '" . $entidadorden . "', '" . $valororden . "', '" . $cantidadorden . "', '" . $fecha . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }


}