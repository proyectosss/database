<?php
require_once 'model/persona_modelo.php';
class verificacion_controller
{
    private $persona;
    private $personaVerificacion;
    public function __construct()
    {
        $this->persona  = new persona_modelo();
        $this->personaVerificacion  = new persona_modelo();
    }


    public function index()
    {
        $tittle = "hexopay-verificacion";
        if (isset($_GET['update'])) {
            if (isset($_POST['codeCofirmacion'])) {
                $data = $this->persona->query($_GET['documento']);
                if (isset($data['cedula']) && $data['code_confirmacion']==$_GET['code']) {
                    if ($_POST['codeCofirmacion']==$data['numero']) {
                        $this->personaVerificacion->update($data['cedula']);
                        header('Location: index.php?c=login');
                    }else{
                        echo "numero equivocado";
                    }
                    
                }
            }
        }else if(isset($_GET['code']) && isset($_GET['documento'])){
            $data = $this->persona->query($_GET['documento']);
            if (isset($data['cedula'])) {
                if($data['code_confirmacion']==$_GET['code']){
                    require_once HTML_DIR_PUBLIC . 'overall/header.php';
                    require_once HTML_DIR_PUBLIC . 'overall/topnav.html';
                    require_once HTML_DIR_PUBLIC . 'persona/verificacion.php';
                    require_once HTML_DIR_PUBLIC . 'overall/footer.php';
                }else{
                    echo "reenviar correo";
                }
            }else{
                echo "No ha sido registrado \nRegistrese aqui: http://localhost/hexopay/index.php?c=persona o verifique su correo";
            } 
        }else{
            echo "No ha sido registrado \nRegistrese aqui: http://localhost/hexopay/index.php?c=persona";
        } 
    }
}
