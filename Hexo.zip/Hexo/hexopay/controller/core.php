<?php
//******nucleo*****////
define('HTML_DIR', 'view/html/'); //DIRECION DE LA VISTA
define('HTML_DIR_PUBLIC', 'view/html/html_public/'); //DIRECION DE LA VISTA NO SESION
define('HTML_DIR_CLIENTE', 'view/html/html_cliente/'); //DIRECION DE LA VISTA CLIENTE
define('HTML_DIR_ADMINISTRADOR', 'view/html/html_administrador/'); //DIRECION DE LA VISTA ADMINISTRADOR
define('HTML_DIR_VALIDADOR', 'view/html/html_validador/'); //DIRECION DE LA VISTA VALIDADOR
define('APP_TITTLE', 'hexocoin'); //TITULO
define('APP_HOST', 'localhost');
define('APP_USER', 'root');
define('APP_PASS', '');
define('APP_DB', '');
/**
 *
 */
