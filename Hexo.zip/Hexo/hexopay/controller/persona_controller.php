<?php
require_once 'model/persona_modelo.php';
require_once 'model/banco_modelo.php';
require_once 'model/log_modelo.php';
class persona_controller
{
    private $persona;
    public function __construct()
    {
        $this->persona  = new persona_modelo();
        $this->model_banco  = new banco_modelo();
        $this->model_log  = new log_modelo();
    }

    public function crear_cuenta()
    {
        $tittle = "hexopay-crear cuenta";
        $data=$this->model_banco->banco();
        require_once HTML_DIR_PUBLIC . 'overall/header.php';
        require_once HTML_DIR_PUBLIC . 'overall/topnav_crear.html';
        require_once HTML_DIR_PUBLIC . 'persona/crear_cuenta.php';
        require_once HTML_DIR_PUBLIC . 'overall/footer.php';
    }

    public function verificacion()
    {
        $tittle = "hexopay-verificacion";
        if($_GET['code'] && $_GET['documento']){
            echo $_GET['code'];
            require_once HTML_DIR_PUBLIC . 'overall/header.php';
            require_once HTML_DIR_PUBLIC . 'overall/topnav.html';
            require_once HTML_DIR_PUBLIC . 'persona/verificacion.php';
            require_once HTML_DIR_PUBLIC . 'overall/footer.php';
        }else{
            echo "No ha sido registrado \nRegistrese aqui: http://localhost/hexopay/index.php?c=persona";
        }
        
    }

    function generateRandomString($length) 
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    function email($correo, $nombre, $apellido, $code, $numero, $documento)
    {
        
        
        // the message
        $msg = "Hola ".$nombre." ".$apellido.". \nGracias por utilizar hexopay \nhttp://localhost/hexopay/index.php?c=verificacion&code=".$code."&documento=".$documento." \n debes ingresar este codigo=".$numero."";

        // use wordwrap() if lines are longer than 70 characters
        $msg = wordwrap($msg,70);

        // send email
        if (mail($correo,"My subject",$msg)) { echo 'Sent';
        } else { echo 'Error while sending email';
        }
    }

    public function nuevo()
    {
            $numero='';
            $code=$this->generateRandomString(25);
            for ($i=0; $i < 6 ; $i++) { 

                $numero=$numero.rand(0,9);
            }
            $pass = encriptar($_POST['passwordPerso']);
            $this->persona->save($_POST['DocumentoPerso'], $_POST['nombrePerso'], $_POST['ApellidoPerso'], $_POST['TelefonoPerso'], $_POST['CelularPerso'], $_POST['emailPerso'], $_POST['DirecionPerso'], $_POST['billetera1'], $_POST['billetera2'], $_POST['cuenta'], $_POST['entidadPerso'], $_POST['tipo_cuentaPerso'], $code, $numero, $pass);
            $this->model_log->logCliente($_POST["DocumentoPerso"], $_POST["nombrePerso"], $_POST["emailPerso"], "el cliente " . $_POST["nombrePerso"]. ' con la cedula '.$_POST["DocumentoPerso"].' creo una cuenta', getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));

            $this->email($_POST['emailPerso'], $_POST['nombrePerso'], $_POST['ApellidoPerso'], $code, $numero, $_POST['DocumentoPerso']);

            $this->model_log->logCliente($_POST["DocumentoPerso"], $_POST["nombrePerso"], $_POST["emailPerso"], "el cliente " . $_POST["nombrePerso"]. ' con la cedula '.$_POST["DocumentoPerso"].' fue enviado un numero de verificacion al correo '. $_POST['emailPerso'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));

            

             
                header('Location: index.php?c=usuario');
            
    }
}
