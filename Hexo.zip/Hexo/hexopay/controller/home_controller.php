<?php
class home_controller
{
    public function __construct()
    {

    }

    public function index()
    {
       $tittle = "Hexopay";
		require_once HTML_DIR_PUBLIC . 'overall/header.php';
		require_once HTML_DIR_PUBLIC . 'overall/topnav.html';
		require_once HTML_DIR_PUBLIC . 'home/home.php';
		require_once HTML_DIR_PUBLIC . 'overall/footer.php';

    }
}

?>
