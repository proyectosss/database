<?php
class summary_controller
{
    private $sesion;
    public function __construct()
    {

    }

    public function index()
    {
        $tittle = "hexopay-" . $_SESSION["name"];
        $ip     = getRealIP();
        if ($_SESSION["rol"] == '3') {
            require_once HTML_DIR_CLIENTE . 'overall/header.php';
            require_once HTML_DIR_CLIENTE . 'overall/topnav.html';
            require_once HTML_DIR_CLIENTE . 'overall/home.php';
            require_once HTML_DIR_CLIENTE . 'overall/modal.php';
            require_once HTML_DIR_CLIENTE . 'overall/footer.php';
        } else if($_SESSION["rol"] == '1'){
            require_once HTML_DIR_ADMINISTRADOR . 'overall/header.php';
            require_once HTML_DIR_ADMINISTRADOR . 'overall/topnav.html';
            require_once HTML_DIR_ADMINISTRADOR . 'overall/home.php';
            require_once HTML_DIR_ADMINISTRADOR . 'overall/modal.php';
            require_once HTML_DIR_ADMINISTRADOR . 'overall/footer.php';
        }else if($_SESSION["rol"] == '2'){
            require_once HTML_DIR_VALIDADOR . 'overall/header.php';
            require_once HTML_DIR_VALIDADOR . 'overall/topnav.html';
            require_once HTML_DIR_VALIDADOR . 'overall/home.php';
            require_once HTML_DIR_VALIDADOR . 'overall/modal.php';
            require_once HTML_DIR_VALIDADOR . 'overall/footer.php';
        }

    }
    public function cerrar()
    {
        session_destroy();
        header('location:index.php');
    }

}
