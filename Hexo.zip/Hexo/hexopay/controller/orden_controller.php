<?php
require_once 'model/orden_modelo.php';
require_once 'model/log_modelo.php';
require_once 'model/banco_modelo.php';
class orden_controller
{
    private $orden;
    private $logmodel;
    private $model_banco;
    public function __construct()
    {
        $this->orden = new orden_modelo();
        $this->logmodel = new log_modelo();
        $this->model_banco = new banco_modelo();
    }

    public function index()
    {
        $tittle = "hexopay-ordenes-" . $_SESSION["name"];
        $data = $this->orden->ordenSinValidar();
        
        require_once HTML_DIR_VALIDADOR . 'overall/header.php';
        require_once HTML_DIR_VALIDADOR . 'overall/topnav.html';
        require_once HTML_DIR_VALIDADOR . 'validador/validador.php';
        require_once HTML_DIR_VALIDADOR . 'overall/modal.php';
        require_once HTML_DIR_VALIDADOR . 'overall/footer.php';

    }

    public function validar_datos()
    {
        $tittle = "hexopay-ordenes-" . $_SESSION["name"];
        $data = $this->orden->consultar_orden($_GET['id']);
        $ban=$this->model_banco->banco();
        require_once HTML_DIR_VALIDADOR . 'overall/header.php';
        require_once HTML_DIR_VALIDADOR . 'overall/topnav.html';
        require_once HTML_DIR_VALIDADOR . 'validador/validar_datos.php';
        require_once HTML_DIR_VALIDADOR . 'overall/modal.php';
        require_once HTML_DIR_VALIDADOR . 'overall/footer.php';

    }

    public function crear_orden()
    {
        $tittle = "hexopay-ordenes-" . $_SESSION["name"];
        require_once HTML_DIR_CLIENTE . 'overall/header.php';
        require_once HTML_DIR_CLIENTE . 'overall/topnav.html';
        require_once HTML_DIR_CLIENTE . 'orden/crear.php';
        require_once HTML_DIR_CLIENTE . 'overall/modal.php';
        require_once HTML_DIR_CLIENTE . 'overall/footer.php';

    }

    public function nuevo_transacion()
    {
            $fecha=date('Y-m-d H:i:s');
            $this->orden->save_transacion($_POST['id'], $_POST['fechaorden'], $_POST['entidadorden'], $_POST['valororden'], $_POST["cantidadorden"], $fecha);

            header('Location: index.php?c=orden'); 
    }

    public function nuevo()
    {
            $fecha=date('Y-m-d H:i:s');
            $estado=0;
            $this->orden->save($fecha, $_POST['valororden'], $_POST['cantidadorden'], $estado, '222222222', $_SESSION["documento"],  $_POST['totalorden'], $_POST['comisionorden']);

            header('Location: index.php?c=orden&a=crear_orden'); 
    }


}
