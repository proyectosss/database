<div class="container-fluid contenido">
  <div class="row">
    <div class="col-md-12">
      <div class=" header modal-header">
        <h4 class="title text-color font">Ordenes por validar</h4>
      </div>
      <div class="table-responsive padding">
        <table id="dataTables" class="table table-bordred table-striped table-hover">
          <thead class="heade-table">
            <th class="font th">Fecha</th>
            <th class="font th">Valor</th>
            <th class="font th">Cantidad</th>
            <th class="font th">Total</th>
            <th class="font th">Comision</th>
            <th class="font th">Opciones</th>
          </thead>
          <tbody>
            <?php foreach ($data as $orden): ?>
            <tr>
              <td title="Fecha">
                <?php echo $orden['fecha']; ?>
              </td>
              <td title="Valor">
                <?php echo $orden['valor']; ?>
              </td>
              <td title="Cantidad">
                <?php echo $orden['cantidad']; ?>
              </td>
              <td title="Total">
                <?php echo $orden['total']; ?>
              </td>
              <td title="Comision">
                <?php echo $orden['comision']; ?>
              </td>
              
              <td>
                <button class="btn btn-raised btn-primary btn-xs btne" data-title="Edit" data-placement="top" data-toggle="tooltip" title="Edit" onclick="location='index.php?c=orden&a=validar_datos&id=<?php echo $orden['id']; ?>'"><span class="glyphicon glyphicon-pencil"></span>
                </button>
              </td>
            </tr>
            <?php endforeach;?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>