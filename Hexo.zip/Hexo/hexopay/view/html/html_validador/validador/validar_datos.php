<div class="container-fluid contenido">
  <div class="header modal-header">
    <h4 class="text-color"> Orden</h4>
    <form  action="index.php?c=orden&a=nuevo_transacion" method="post">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label" id="label-p" for="fechaorden">Fecha de creacion</label>
            <input name="fechaorden" class="form-control" id="fechaorden" value="<?php echo $data['fecha']?>" readonly="readonly">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label" id="label-p" for="valororden">Valor</label>
            <input name="valororden" class="form-control"  min="0" id="valororden" type="Number" step="any" value="<?php echo $data['orden']?>"  required="required">
          </div>
        </div>
      </div>
      <input type="hidden" name="id" value="<?php echo $data['id']?>">

      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label" id="label-p" for="cantidadorden">Cantidad</label>
            <input name="cantidadorden" class="form-control"  min="0" id="cantidadorden" type="Number" step="1" value="<?php echo $data['cantidad']?>"  required="required">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label" id="label-p" for="comisionorden">Comision</label>
            <input name="comisionorden" class="form-control"  min="0" id="comisionorden" type="Number" step="any" value="<?php echo $data['comision']?>"  required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label" id="label-p" for="totalorden">Total</label>
            <input name="totalorden" class="form-control"  min="0" id="totalorden" type="Number" step="any" value="<?php echo $data['total']?>"  required="required">
          </div>
        </div>
        
        </div>
        <div class="row">
          <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="entidadPerso">Entidad bancaria</label>
            <select class="form-control" id="entidadPerso" name="entidadorden" required="required">
              <option></option>
              <?php foreach ($ban as $banco): ?>
                <option value="<?php echo $banco['codigo']; ?>"><?php echo $banco['entidad']; ?></option>
              <?php endforeach?>;
            </select>
          </div>
        </div>
        </div>
      </div>

      <button type="submit" class="btn background-color lineal-button font" id="button">
        <span class="glyphicon glyphicon-floppy-saved"></span>
          Guardar
      </button>

      <button type="button" class="btn background-color lineal-button font" id="button" onclick="location='index.php?c=orden'">
        <span class="glyphicon glyphicon-arrow-left"></span>
          Regresar
      </button>

    </form>
  </div>
</div>