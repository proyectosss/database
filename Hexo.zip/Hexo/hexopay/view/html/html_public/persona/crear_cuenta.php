<div class="container-fluid contenido">
  <div class="header modal-header">
    <h4 class="text-color"> Bienvenido a hexopay!! </h4>
    <h5 class="text-color"> ingrese sus datos y espera la validacion </h5>
    <form  action="index.php?c=persona&a=nuevo"  method="post">
      <div class="row">
        <div class="col-md-12">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="DocumentoPerso">Documento</label>
            <input name="DocumentoPerso" class="form-control" id="DocumentoPerso" type="Number" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="nombrePerso">Nombre</label>
            <input name="nombrePerso" class="form-control" pattern="^[a-z\d\.]{5,}$" id="nombrePerso" type="text" required="required">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="ApellidoPerso">Apellido</label>
            <input name="ApellidoPerso" class="form-control" pattern="^[a-z\d\.]{5,}$" id="ApellidoPerso" type="text" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="Telefono1Perso">Telefono fijo</label>
            <input name="TelefonoPerso" class="form-control" id="TelefonoPerso" type="Number" required="required">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="CelularPerso">Celular</label>
            <input name="CelularPerso" class="form-control" id="CelularPerso" type="Number" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="emailPerso">E-mail</label>
            <input name="emailPerso" class="form-control" id="emailPerso" type="email" required="required">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="DirecionPerso">Direcion</label>
            <input name="DirecionPerso" class="form-control" id="DirecionPerso" type="text" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="passwordPerso">Contraseña</label>
            <input name="passwordPerso" class="form-control" id="passwordPerso" pattern="(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$" type="password" title="La contrasena debe tener mayuscula, numero y minimo 8 caracteres" required="required">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="co">Cofirme contraseña</label>
            <input name="co" class="form-control" id="co" pattern="(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$" type="password" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="billetera1">Billetera 1</label>
            <input name="billetera1" class="form-control" id="billetera1" type="Text" required="required">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="billetera2">Billetera 2</label>
            <input name="billetera2" class="form-control" id="billetera2" type="text" required="required">
          </div>
        </div>
      </div>
  
      <div class="row">
        <div class="col-md-2">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="cuenta">Numero de cuenta bancaria</label>
            <input name="cuenta" class="form-control" id="cuenta" type="Text" required="required" pattern="[0-9]{13,16}" >
          </div>
        </div>
        <div class="col-md-8">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="entidadPerso">Entidad bancaria</label>
            <select class="form-control" id="entidadPerso" name="entidadPerso" required="required">
              <option></option>
              <?php foreach ($data as $banco): ?>
                <option value="<?php echo $banco['codigo']; ?>"><?php echo $banco['entidad']; ?></option>
              <?php endforeach?>;
            </select>
          </div>
        </div>
        <div class="col-md-2">
          <div class="form-group label-floating">
            <label class="control-label text-color" for="tipo_cuentaPerso"> Tipo cuenta </label>
            <select class="form-control" id="tipo_cuentaPerso" name="tipo_cuentaPerso" required="required">
              <option></option>
              <option>Ahorros</option>
              <option>Corriente</option>
            </select>
          </div>
        </div>
      </div>
      <button type="submit" class="btn background-color lineal-button font" id="button">
        <span class="glyphicon glyphicon-floppy-saved"></span>
          Guardar
      </button>

      <button type="button" class="btn background-color lineal-button font" id="button" onclick="location='index.php'">
        <span class="glyphicon glyphicon-arrow-left"></span>
          Regresar
      </button>

    </form>
  </div>
</div>
