<div class="container-fluid contenido">
    <div class="row">
        <h1>Welcome!!</h1><br/>
        <?php 
        echo "Hola ".$data['nombre'].' '.$data['apellido'].' te enviamos un numero de verificacion al correo '.$data['correo']. ' ingresoro en le campo para queda registrado con nosotros'?>
       <form  action="index.php?c=verificacion&update=&documento=<?php echo $data['cedula'] ?>&code=<?php echo $data['code_confirmacion'] ?>"  method="post">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="codeCofirmacion">Ingrese codigo</label>
            <input name="codeCofirmacion" class="form-control" id="codeCofirmacion" pattern="[0-9]{6,6}" type="text" required="required">
          </div>
        </div>
        <button type="submit" class="btn background-color lineal-button font" id="button">
        <span class="glyphicon"></span>
          enviar codigo
      </button>
      </form>
    </div>
</div>