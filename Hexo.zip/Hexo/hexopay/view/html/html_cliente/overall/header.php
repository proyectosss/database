<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1" >
    <meta name="keywords" content="">
    <!--Stylesheets-->

    <!-- Archivos necesarios bootstrap CSS -->
    <link rel="stylesheet" href="view/assets/bootstrap/dist/css/bootstrap.min.css">
    <!-- Archivos necesarios material design bootstrap CSS -->
    <link rel="stylesheet" href="view/assets/bootstrap-material-design/dist/css/bootstrap-material-design.css">
    <link rel="stylesheet" href="view/assets/bootstrap-material-design/dist/css/ripples.min.css">
    <link rel="stylesheet" href="view/assets/datatable/css/dataTables.bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i,700,700i" rel="stylesheet">

    <!-- Archivos necesarios de style -->
    <link rel="stylesheet" href="view/css/style.css">
    <title><?php echo $tittle ?></title>
</head>

<body>