<div class="container-fluid contenido">
  <div class="header modal-header">
    <h2>CREAR ORDEN</h2>
  </div>
  <ul class="nav nav-tabs">
    <li role="presentation" class="active">
      <a data-toggle="tab" href="#Tab1" role="tab" aria-controls="proc">Comprar</a>
    </li>
    <li role="presentation">
      <a aria-controls="elemento" role="tab" data-toggle="tab" href="#Tab2">Vender</a>
    </li>
  </ul>
  <div class="tab-content" id="tab-content">
    <div id="Tab1" class="tab-pane fade in active">
      <div class="container-fluid">
        <form action="index.php?c=orden&a=nuevo" method="post">
          <h4 class="text-color">Comprar btc</h4>
          <!-- area de compañia-->
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label" id="label-p" for="cantidadorden">Cantidad</label>
                <input name="cantidadorden" class="form-control"  min="0" id="cantidadorden" type="Number" step="1" value="0"  required="required">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label" id="label-p" for="valororden">Valor</label>
                <input name="valororden" class="form-control"  min="0" id="valororden" type="Number" step="any" value="0.0"  required="required">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label" id="label-p" for="totalorden">Total</label>
                <input name="totalorden" class="form-control"  min="0" id="totalorden" type="Number" step="any" value="<?php echo $data['total']?>"  required="required">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label" id="label-p" for="comisionorden">Comision</label>
                <input name="comisionorden" class="form-control"  min="0" id="comisionorden" type="Number" step="any" value="<?php echo $data['comision']?>"  required="required">
              </div>
            </div>
          </div>
          <center>
          <button type="submit" class="btn background-color lineal-button font" id="button">
          <span class="glyphicon glyphicon-floppy-saved"></span>
          Comprar btc
          </button>
          </center>
        </form>
      </div>
    </div>
    <div id="Tab2" class="tab-pane fade">
      <div class="container-fluid">
        <form action="index.php?c=orden&a=nuevo" method="post">
          <h4 class="text-color">Vender btc</h4>
          <!-- area de compañia-->
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label" id="label-p" for="cantidadorden">Cantidad</label>
                <input name="cantidadorden" class="form-control"  min="0" id="cantidadorden" type="Number" step="1" value="0"  required="required">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label" id="label-p" for="valororden">Valor</label>
                <input name="valororden" class="form-control"  min="0" id="valororden" type="Number" step="any" value="0.0"  required="required">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label" id="label-p" for="totalorden">Total</label>
                <input name="totalorden" class="form-control"  min="0" id="totalorden" type="Number" step="any" value="<?php echo $data['total']?>"  required="required">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label" id="label-p" for="comisionorden">Comision</label>
                <input name="comisionorden" class="form-control"  min="0" id="comisionorden" type="Number" step="any" value="<?php echo $data['comision']?>"  required="required">
              </div>
            </div>
          </div>
          <center>
          <button type="submit" class="btn background-color lineal-button font" id="button">
          <span class="glyphicon glyphicon-floppy-saved"></span>
          Vender btc
          </button>
          </center>
        </form> 
      </div>
    </div>
  </div>
</div>