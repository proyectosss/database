-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-10-2018 a las 22:09:08
-- Versión del servidor: 10.1.13-MariaDB
-- Versión de PHP: 5.5.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_hexopay`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizar_persona` (IN `cedula` BIGINT, IN `nombre` VARCHAR(900), IN `apellido` VARCHAR(900), IN `telefono` INT, IN `celular` BIGINT, IN `correo` VARCHAR(900), IN `direcion` VARCHAR(900), IN `billetera1` VARCHAR(900), IN `billetera2` VARCHAR(900), IN `no_cte_bancaria` INT, IN `entidad_bancaria` INT, IN `tipo_cuenta` VARCHAR(900), IN `estado` BOOLEAN)  NO SQL
BEGIN

set @cedula=cedula;
set @nombre=nombre;
set @apellido=apellido;
set @telefono=telefono;
set @celular=celular;
set @correo=correo;
set @direcion=direcion;
set @billetera1=billetera1;
set @billetera2=billetera2;
set @no_cte_bancaria=no_cte_bancaria;
set @entidad_bancaria=entidad_bancaria;
set @tipo_cuenta=tipo_cuenta;
set @estado=estado;

UPDATE tbl_usuariopersona set var_nombre_per = @nombre, var_apellido_per=@apellido, int_telefono_per=@telefono, int_celular_per=@celular, var_correo_per=@correo, var_direcion_per= @direcion, var_billetera1_per=@illetera1, var_billetera2_per=@illetera2, int_no_cte_bancaria_per=@no_cte_bancaria, int_entidad_bancaria_per=@entidad_bancaria, var_tipo_cuenta_per=@tipo_cuenta, bool_estado_per=@estado
WHERE int_cedula_per=cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizar_usuario` (IN `cedula` INT, IN `nombre` VARCHAR(900), IN `apellido` TEXT, IN `telefono` INT, IN `celular` BIGINT, IN `direcion` VARCHAR(900), IN `correo` VARCHAR(900), IN `pass` VARCHAR(900), IN `estado` VARCHAR(200), IN `fecha_inicio` DATE, IN `role` INT)  NO SQL
BEGIN

set @cedula=cedula;
set @nombre=nombre;
set @apellido=apellido;
set @telefono=telefono;
set @celular=celular;
set @direcion=direcion;
set @correo=correo;
set @password=pass;
set @estado=estado;
set @fecha_inicio=fecha_inicio;
set @role=role;
UPDATE tbl_usuario set var_nombre_use = @nombre, var_apellido_use = @apellido, int_telefono_use = @telefono, int_celular_use = @celular, var_direcion_use = @direcion, var_correo_use = @correo, var_password_use = @password, var_estado_use = @estado, date_fecha_inicio_use = @fecha_inicio, int_role_rol = @role
WHERE int_documento_use=@cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizar_verificacion` (IN `cedula` BIGINT)  NO SQL
BEGIN

set @cedula=cedula;
UPDATE tbl_usuariopersona set var_code_confirmacion_per  = 'ya confirmo el correo', bool_confirmacion_per=1
WHERE int_cedula_per=cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_consultar_orden` (IN `id` INT)  NO SQL
BEGIN
set @id=id;
SELECT date_fecha_creada_ord  as fecha, dou_valor_ord  as orden, int_cantidad_ord as cantidad, var_estado_ord  as estado, int_cedula_use as cedula, dou_total_ord  as total, 
dou_comision_ord  as comision, int_id_ord as id
FROM tbl_orden
WHERE int_id_ord=@id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_consultar_persona` (IN `cedula` INT)  NO SQL
BEGIN
set @cedula=cedula;
SELECT int_cedula_per as cedula, var_nombre_per as nombre, var_apellido_per as apellido, int_telefono_per as telefono, int_celular_per as celular, var_correo_per as correo, var_direcion_per as direcion, var_billetera1_per as billetera1, var_billetera2_per as billetera2, int_no_cte_bancaria_per as no_cte_bancaria,  int_entidad_bancaria_per as entidad_bancaria,  var_tipo_cuenta_per as tipo_cuenta, bool_estado_per as estado
FROM tbl_persona
WHERE int_cedula_per=@cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_consulta_usuario` (IN `cedula` INT)  NO SQL
BEGIN
set @cedula=cedula;
SELECT int_documento_use as cedula, var_nombre_use as nombre, var_apellido_use as apellido, int_telefono_use as telefono, int_celular_use as celular, var_direcion_use as direcion, var_correo_use as correo, var_password_use as pass, var_estado_use as estado, date_fecha_inicio_use as fecha_inicio,  int_role_rol as role
FROM tbl_usuario
WHERE int_documento_use=@cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_eliminar_persona` (IN `cedula` INT)  NO SQL
BEGIN
SET @cedula=cedula;
DELETE FROM tbl_persona WHERE int_cedula_per=@cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_eliminar_usuario` (IN `cedula` INT)  NO SQL
BEGIN
SET @cedula=cedula;
DELETE FROM tbl_usuario WHERE int_documento_use=@cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ingresar_orden` (IN `fecha_creada` DATETIME, IN `valor` DOUBLE, IN `cantidad` INT, IN `estado` VARCHAR(200), IN `cedula_use` BIGINT, IN `cedula_per` BIGINT, IN `total` DOUBLE, IN `comision` DOUBLE)  NO SQL
BEGIN
set @fecha_creada=fecha_creada;
set @valor=valor;
set @cantidad=cantidad;
set @estado=estado;
set @cedula_use=cedula_use;
set @cedula_per=cedula_per;
set @total=total;
set @comision=comision;

INSERT INTO tbl_orden(int_id_ord, 
date_fecha_creada_ord, dou_valor_ord, int_cantidad_ord, var_estado_ord, int_cedula_use, int_cedula_per, dou_total_ord, dou_comision_ord) VALUES (null, @fecha_creada, @valor, @cantidad, @estado, @cedula_use, @cedula_per, @total, @comision);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ingresar_transacion` (IN `orden` INT, IN `fecha` DATETIME, IN `banco` INT, IN `valor` DOUBLE, IN `cantidad` INT, IN `fecha_validacion` DATETIME)  NO SQL
BEGIN
set @orden=orden;
set @fecha=fecha;
set @banco=banco;
set @valor=valor;
set @cantidad=cantidad;
set @fecha_validacion=fecha_validacion;


INSERT INTO tbl_transacion(int_id_trans, int_orden_ord, 
date_fecha_trans, int_banco_ban, dou_valor_trans, int_cantidad_trans, date_fecha_validacion_trans) VALUES (null, @orden, @fecha, @banco, @valor, @cantidad, @fecha_validacion);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ingreso_logCliente` (IN `documento` INT, IN `emai` VARCHAR(900), IN `nombre` VARCHAR(900), IN `acion` TEXT, IN `IPreal` VARCHAR(900), IN `ipscript` VARCHAR(900), IN `ipusuario` VARCHAR(900), IN `fecha` DATE)  NO SQL
BEGIN
set @documento=documento;
set @emai=emai;
set @nombre=nombre;
set @acion=acion;
set @IPreal=IPreal;
set @ipscript=ipscript;
set @ipusuario=ipusuario;
set @fecha=fecha;

INSERT INTO tbl_log_cliente(int_id_logc, int_documento_per, var_email_logc, var_nombre_logc, var_acion_logc, var_IPreal_logc, var_ipscript_logc, var_ipusuario_logc, date_fecha_logc ) VALUES (null, @documento, @emai, @nombre, @acion, @IPreal, @ipscript, @ipusuario, @fecha);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ingreso_logUsuario` (IN `documento` BIGINT, IN `emai` VARCHAR(900), IN `nombre` VARCHAR(900), IN `acion` TEXT, IN `IPreal` VARCHAR(900), IN `ipscript` VARCHAR(900), IN `ipusuario` VARCHAR(900), IN `fecha` DATE)  NO SQL
BEGIN
set @documento=documento;
set @emai=emai;
set @nombre=nombre;
set @acion=acion;
set @IPreal=IPreal;
set @ipscript=ipscript;
set @ipusuario=ipusuario;
set @fecha=fecha;

INSERT INTO tbl_log(int_id_log, int_documento_log, var_email_log, var_nombre_log, var_acion_log, var_IPreal_log, var_ipscript_log, var_ipusuario_log, date_fecha_log ) VALUES (null, @documento, @emai, @nombre, @acion, @IPreal, @ipscript, @ipusuario, @fecha);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ingreso_persona` (IN `cedula` BIGINT, IN `nombre` VARCHAR(900), IN `apellido` VARCHAR(900), IN `telefono` INT, IN `celular` BIGINT, IN `correo` VARCHAR(900), IN `direcion` VARCHAR(900), IN `billetera1` VARCHAR(190), IN `billetera2` VARCHAR(190), IN `no_cte_bancaria` BIGINT, IN `entidad_bancaria` INT, IN `tipo_cuenta` VARCHAR(900), IN `estado` BOOLEAN, IN `code_confirmacion` VARCHAR(200), IN `confirmacion` BOOLEAN, IN `numero_confirmacion` INT, IN `pass` VARCHAR(900))  NO SQL
BEGIN
set @cedula=cedula;
set @nombre=nombre;
set @apellido=apellido;
set @telefono=telefono;
set @celular=celular;
set @correo=correo;
set @direcion=direcion;
set @billetera1=billetera1;
set @billetera2=billetera2;
set @no_cte_bancaria=no_cte_bancaria;
set @entidad_bancaria=entidad_bancaria;
set @tipo_cuenta=tipo_cuenta;
set @estado=estado;
set @code_confirmacion=code_confirmacion;
set @confirmacion=confirmacion;
set @numero_confirmacion=numero_confirmacion;
set @pass=pass;

INSERT INTO tbl_usuariopersona(
int_cedula_per, var_nombre_per, 
var_apellido_per, int_telefono_per, int_celular_per, var_correo_per, var_direcion_per, var_billetera1_per, var_billetera2_per, int_no_cte_bancaria_per, 
int_entidad_bancaria_per, var_tipo_cuenta_per, bool_estado_per,var_code_confirmacion_per, bool_confirmacion_per, int_numero_confirmacion_per, var_password_per ) VALUES (@cedula, @nombre, @apellido, @telefono, @celular, @correo, @direcion, @billetera1, @billetera2, @no_cte_bancaria, @entidad_bancaria, @tipo_cuenta, @estado, @code_confirmacion, @confirmacion, @numero_confirmacion, @pass);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ingreso_rol` (IN `rol` VARCHAR(100))  NO SQL
BEGIN
set @rol=rol;
INSERT INTO tbl_rol(int_id_rol, var_rol_rol ) VALUES (null, @rol);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ingreso_usuario` (IN `cedula` INT, IN `nombre` VARCHAR(900), IN `apellido` VARCHAR(900), IN `telefono` INT, IN `celular` BIGINT, IN `direcion` VARCHAR(900), IN `correo` VARCHAR(900), IN `pass` VARCHAR(900), IN `estado` VARCHAR(200), IN `fecha_inicio` DATE, IN `role` INT)  NO SQL
BEGIN

set @cedula=cedula;
set @nombre=nombre;
set @apellido=apellido;
set @telefono=telefono;
set @celular=celular;
set @direcion=direcion;
set @correo=correo;
set @pass=pass;
set @estado=estado;
set @fecha_inicio=fecha_inicio;
set @role=role;

INSERT INTO tbl_usuario(int_documento_use, var_nombre_use, var_apellido_use, int_telefono_use, int_celular_use, var_direcion_use, var_correo_use, var_password_use, var_estado_use, date_fecha_inicio_use, 
int_role_rol) VALUES (@cedula, @nombre, @apellido, @telefono, @celular, @direcion, @correo, @pass, @estado, @fecha_inicio, @role);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_leer_banco` ()  NO SQL
BEGIN
SELECT int_codigo_ban as codigo, var_entidad_ban as entidad
FROM tbl_banco;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_leer_log` ()  NO SQL
BEGIN
SELECT int_id_log as consecutivo, int_documento_log as documento, var_email_log as email, var_nombre_log as nombre, var_acion_log as acion, var_IPreal_log as IPreal, var_ipscript_log as ipscript, var_ipusuario_log as ipusuario, date_fecha_log as fecha
FROM tbl_log;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_leer_orden` ()  NO SQL
BEGIN
SELECT date_fecha_creada_ord  as fecha, dou_valor_ord  as valor, int_cantidad_ord as cantidad, int_cedula_use as cedula, dou_total_ord  as total, dou_comision_ord  as comision, int_id_ord as id
FROM tbl_orden
WHERE var_estado_ord = 0;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_leer_persona` ()  NO SQL
BEGIN
SELECT int_cedula_per as cedula, var_nombre_per as nombre, var_apellido_per as apellido, int_telefono_per as telefono, int_celular_per as celular, var_correo_per as correo, var_direcion_per as direcion, var_billetera1_per as billetera1, var_billetera2_per as billetera2, int_no_cte_bancaria_per as no_cte_bancaria,  int_entidad_bancaria_per as entidad_bancaria,  var_tipo_cuenta_per as tipo_cuenta, bool_estado_per as estado
FROM tbl_persona;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_leer_usuario` ()  NO SQL
BEGIN
SELECT int_documento_use as cedula, var_nombre_use as nombre, var_apellido_use as apellido, int_telefono_use as telefono, int_celular_use as celular, var_direcion_use as direcion, var_correo_use as correo, var_password_use as pass, var_estado_use as estado, date_fecha_inicio_use as fecha_inicio,  int_role_rol as role
FROM tbl_usuario;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_login_cliente` (IN `vemail` VARCHAR(900))  NO SQL
BEGIN
SELECT var_correo_per AS email_cliente, var_password_per  AS password_cliente, var_nombre_per AS nombre_cliente, var_apellido_per AS apellid_cliente, int_cedula_per as documento_cliente, bool_confirmacion_per as confirmacion
FROM tbl_usuariopersona
WHERE var_correo_per = vemail;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_login_usuario` (IN `vemail` VARCHAR(900))  NO SQL
BEGIN
SELECT var_correo_use AS email_usuario, var_password_use  AS password_usuario, var_nombre_use AS nombre_usuario, var_apellido_use AS apellid_usuario, int_documento_use as documento_usuario, int_role_rol as rol
FROM tbl_usuario
WHERE var_correo_use = vemail;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_validacion_person` (IN `cedula` BIGINT)  NO SQL
BEGIN
set @cedula=cedula;
SELECT int_cedula_per as cedula, var_nombre_per as nombre, var_apellido_per as apellido, var_correo_per as correo, int_numero_confirmacion_per as numero, var_code_confirmacion_per as code_confirmacion, bool_confirmacion_per as confirmacion
FROM tbl_usuariopersona
WHERE int_cedula_per=@cedula;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_banco`
--

CREATE TABLE `tbl_banco` (
  `int_codigo_ban` int(11) NOT NULL,
  `var_entidad_ban` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `var_nit_ban` varchar(200) COLLATE utf8_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Volcado de datos para la tabla `tbl_banco`
--

INSERT INTO `tbl_banco` (`int_codigo_ban`, `var_entidad_ban`, `var_nit_ban`) VALUES
(1, 'Banco de Bogotá', '860002964-4'),
(2, 'Banco Popular S.A.', '860007738-9'),
(6, 'El Banco CorpBanca Colombia S.A. Sigla: Banco CorpBanca  "Helm Bank" o "Helm"', '890903937-0'),
(7, 'Bancolombia S.A. o Banco de Colombia S.A. o Bancolombia', '890903938-8'),
(9, 'Citibank-Colombia - Expresión Citibank', '860051135-4'),
(12, 'BANCO GNB SUDAMERIS S.A.  Quien podrá utilizar el nombre BANCO GNB SUDAMERIS o SUDAMERIS, seguidos o no de las expresiones sociedad anónima o la sigla S.A.', '860050750-1'),
(13, 'Banco Bilbao Vizcaya Argentaria Colombia S.A. podrá utilizar el nombre BBVA Colombia ( Antes Banco Ganadero S.A. o BBVA Banco Ganadero', '860003020-1'),
(23, 'Banco  de  Occidente S.A.', '890300279-4'),
(30, 'BANCO CAJA SOCIAL S.A.  podrá usar los siguientes nombres y siglas: BANCO CAJA SOCIAL BCSC Y BCSC S.A.', '860007335-4'),
(39, 'Banco Davivienda S.A. "Banco Davivienda" o "Davivienda"', '860034313-7'),
(42, 'Banco Colpatria Multibanca Colpatria S.A. , nombres abreviados o siglas: "Banco Colpatria", "Colpatria Multibanca", "Multibanca Colpatria" o "Colpatria Red Multibanca"', '860034594-1'),
(43, 'Banco Agrario de Colombia S.A. -Banagrario-', '800037800-8'),
(49, 'Banco Comercial AV Villas S.A. o Banco de Ahorro y Vivienda AV Villas, Banco AV Villas o AV Villas', '860035827-5'),
(51, 'Banco ProCredit Colombia S.A. siglas "BPCC", "PROCREDIT" o "BANCO PROCREDIT"', '900200960-9'),
(52, 'Banco de las Microfinanzas -Bancamía S.A.', '900215071-1'),
(53, 'Banco WWB S.A.', '900378212-2'),
(54, 'Banco Coomeva S.A.  - Sigla "BANCOOMEVA"', '900406150-5'),
(55, 'Banco Finandina S.A. o Finandina Establecimiento Bancario. Sigla FINANDINA.', '860051894-6'),
(56, 'Banco Falabella S.A.', '900047981-8'),
(57, 'Banco Pichincha S.A.', '890200756-7'),
(58, 'El Banco Cooperativo Coopcentral  Sigla: COOPCENTRAL', '890203088-9'),
(59, 'BANCO SANTANDER DE NEGOCIOS COLOMBIA S. A', '900628110-3'),
(60, '"BANCO MUNDO MUJER S.A."  Denominación de "MUNDO MUJER EL BANCO DE LA COMUNIDAD " o "MUNDO MUJER" ', '900768933-8'),
(61, '"BANCO MULTIBANK S.A."  Sigla: "MULTIBANK S.A." o "MULTIBANK"', '860024414-1'),
(62, 'BANCO COMPARTIR S.A. Sigla: "BANCOMPARTIR S.A."', '860025971-5');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_log`
--

CREATE TABLE `tbl_log` (
  `int_id_log` int(11) NOT NULL,
  `int_documento_log` bigint(20) NOT NULL,
  `var_email_log` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `var_nombre_log` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `var_acion_log` text COLLATE utf8_swedish_ci NOT NULL,
  `var_IPreal_log` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `var_ipscript_log` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `var_ipusuario_log` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `date_fecha_log` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Volcado de datos para la tabla `tbl_log`
--

INSERT INTO `tbl_log` (`int_id_log`, `int_documento_log`, `var_email_log`, `var_nombre_log`, `var_acion_log`, `var_IPreal_log`, `var_ipscript_log`, `var_ipusuario_log`, `date_fecha_log`) VALUES
(1, 10008323, 'admin@gmail.com', 'yeisson arley', 'el usuario inicio de sesion', '::1', '::1', '::1', '2017-12-07'),
(2, 222222222, 'validador@gmail.com', 'validador va', 'el usuario inicio de sesion', '::1', '::1', '::1', '2017-12-12'),
(3, 222222222, 'validador@gmail.com', 'validador va', 'el usuario inicio de sesion', '::1', '::1', '::1', '2017-12-12'),
(4, 222222222, 'validador@gmail.com', 'validador va', 'el usuario inicio de sesion', '::1', '::1', '::1', '2017-12-12'),
(5, 222222222, 'validador@gmail.com', 'validador va', 'el usuario inicio de sesion', '::1', '::1', '::1', '2017-12-12'),
(6, 222222222, 'validador@gmail.com', 'validador va', 'el usuario inicio de sesion', '::1', '::1', '::1', '2017-12-12'),
(7, 10008323, 'admin@gmail.com', 'yeisson arley', 'el usuario inicio de sesion', '::1', '::1', '::1', '2017-12-13'),
(8, 222222222, 'validador@gmail.com', 'validador va', 'el usuario inicio de sesion', '::1', '::1', '::1', '2017-12-13');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_log_cliente`
--

CREATE TABLE `tbl_log_cliente` (
  `int_id_logc` int(11) NOT NULL,
  `int_documento_per` bigint(20) NOT NULL,
  `var_email_logc` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `var_nombre_logc` varchar(200) COLLATE utf8_swedish_ci NOT NULL,
  `var_acion_logc` text COLLATE utf8_swedish_ci NOT NULL,
  `var_IPreal_logc` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `var_ipscript_logc` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `var_ipusuario_logc` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `date_fecha_logc` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Volcado de datos para la tabla `tbl_log_cliente`
--

INSERT INTO `tbl_log_cliente` (`int_id_logc`, `int_documento_per`, `var_email_logc`, `var_nombre_logc`, `var_acion_logc`, `var_IPreal_logc`, `var_ipscript_logc`, `var_ipusuario_logc`, `date_fecha_logc`) VALUES
(1, 1000898270, 'j.arley111@gmail.com', 'yeisson', 'el cliente yeisson con la cedula 1000898270 creo una cuenta', '::1', '::1', '::1', '2017-12-07'),
(2, 1000898270, 'j.arley111@gmail.com', 'yeisson', 'el cliente yeisson con la cedula 1000898270 fue enviado un numero de verificacion al correo j.arley111@gmail.com', '::1', '::1', '::1', '2017-12-07'),
(3, 1000898270, 'j.arley111@gmail.com', 'yeisson sanchez', 'el cliente inicio de sesion', '::1', '::1', '::1', '2017-12-07'),
(4, 1000898270, 'j.arley111@gmail.com', 'yeisson sanchez', 'el cliente inicio de sesion', '::1', '::1', '::1', '2017-12-12'),
(5, 1000898270, 'j.arley111@gmail.com', 'yeisson sanchez', 'el cliente inicio de sesion', '::1', '::1', '::1', '2017-12-12'),
(6, 1000898270, 'j.arley111@gmail.com', 'yeisson sanchez', 'el cliente inicio de sesion', '::1', '::1', '::1', '2017-12-12');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_orden`
--

CREATE TABLE `tbl_orden` (
  `int_id_ord` int(11) NOT NULL,
  `date_fecha_creada_ord` datetime NOT NULL,
  `dou_valor_ord` double NOT NULL,
  `int_cantidad_ord` int(11) NOT NULL,
  `var_estado_ord` tinyint(1) NOT NULL,
  `int_cedula_use` bigint(20) NOT NULL,
  `int_cedula_per` bigint(20) NOT NULL,
  `dou_total_ord` double NOT NULL,
  `dou_comision_ord` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Volcado de datos para la tabla `tbl_orden`
--

INSERT INTO `tbl_orden` (`int_id_ord`, `date_fecha_creada_ord`, `dou_valor_ord`, `int_cantidad_ord`, `var_estado_ord`, `int_cedula_use`, `int_cedula_per`, `dou_total_ord`, `dou_comision_ord`) VALUES
(1, '0000-00-00 00:00:00', 123.232, 23, 1, 10008323, 71774495, 0, 0),
(2, '2017-12-12 19:13:28', 23, 2, 1, 222222222, 1000898270, 1, 23),
(3, '2017-12-12 19:15:48', 123, 123, 1, 222222222, 1000898270, 1232, 333),
(4, '2017-12-12 21:23:16', 3.44, 324, 1, 222222222, 1000898270, 4234324, 3244),
(5, '2017-12-12 21:27:49', 2.22, 1, 0, 222222222, 1000898270, 2312334, 234);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_rol`
--

CREATE TABLE `tbl_rol` (
  `int_id_rol` int(11) NOT NULL,
  `var_rol_rol` varchar(100) COLLATE utf8_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Volcado de datos para la tabla `tbl_rol`
--

INSERT INTO `tbl_rol` (`int_id_rol`, `var_rol_rol`) VALUES
(1, 'Administrador'),
(2, 'Validador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_transacion`
--

CREATE TABLE `tbl_transacion` (
  `int_id_trans` int(11) NOT NULL,
  `int_orden_ord` int(11) NOT NULL,
  `date_fecha_trans` datetime NOT NULL,
  `int_banco_ban` int(11) NOT NULL,
  `dou_valor_trans` date NOT NULL,
  `int_cantidad_trans` int(11) NOT NULL,
  `date_fecha_validacion_trans` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Volcado de datos para la tabla `tbl_transacion`
--

INSERT INTO `tbl_transacion` (`int_id_trans`, `int_orden_ord`, `date_fecha_trans`, `int_banco_ban`, `dou_valor_trans`, `int_cantidad_trans`, `date_fecha_validacion_trans`) VALUES
(1, 1, '0000-00-00 00:00:00', 7, '0000-00-00', 23, '0000-00-00 00:00:00'),
(2, 2, '2017-12-12 19:13:28', 56, '0000-00-00', 2, '2017-12-12 19:56:08'),
(3, 4, '2017-12-12 21:23:16', 30, '0000-00-00', 324, '2017-12-12 21:25:52');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_usuario`
--

CREATE TABLE `tbl_usuario` (
  `int_documento_use` bigint(20) NOT NULL,
  `var_nombre_use` varchar(200) COLLATE utf8_swedish_ci NOT NULL,
  `var_apellido_use` varchar(200) COLLATE utf8_swedish_ci NOT NULL,
  `int_telefono_use` int(11) NOT NULL,
  `int_celular_use` bigint(20) NOT NULL,
  `var_direcion_use` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `var_correo_use` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `var_password_use` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `var_estado_use` varchar(200) COLLATE utf8_swedish_ci NOT NULL,
  `date_fecha_inicio_use` date NOT NULL,
  `int_role_rol` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Volcado de datos para la tabla `tbl_usuario`
--

INSERT INTO `tbl_usuario` (`int_documento_use`, `var_nombre_use`, `var_apellido_use`, `int_telefono_use`, `int_celular_use`, `var_direcion_use`, `var_correo_use`, `var_password_use`, `var_estado_use`, `date_fecha_inicio_use`, `int_role_rol`) VALUES
(10008323, 'yeisson', 'arley', 321312, 3213213123, 'sdfdsfjkj', 'admin@gmail.com', 'vWE4pL3/n1jYwHUM6nP7EbaBYUx8vfNwDo/HH6t50qU=', 'activo', '2012-12-12', 1),
(222222222, 'validador', 'va', 213214, 3014343322, 'fgdffds', 'validador@gmail.com', 'vWE4pL3/n1jYwHUM6nP7EbaBYUx8vfNwDo/HH6t50qU=', 'activado', '2017-12-05', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_usuariopersona`
--

CREATE TABLE `tbl_usuariopersona` (
  `int_cedula_per` bigint(20) NOT NULL,
  `var_nombre_per` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `var_apellido_per` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `int_telefono_per` int(11) NOT NULL,
  `int_celular_per` bigint(20) NOT NULL,
  `var_correo_per` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `var_direcion_per` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `var_password_per` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `var_billetera1_per` varchar(190) COLLATE utf8_swedish_ci NOT NULL,
  `var_billetera2_per` varchar(190) COLLATE utf8_swedish_ci NOT NULL,
  `int_no_cte_bancaria_per` bigint(20) NOT NULL,
  `int_entidad_bancaria_per` int(11) NOT NULL,
  `var_tipo_cuenta_per` varchar(900) COLLATE utf8_swedish_ci NOT NULL,
  `bool_estado_per` tinyint(1) NOT NULL,
  `var_code_confirmacion_per` varchar(200) COLLATE utf8_swedish_ci NOT NULL,
  `bool_confirmacion_per` tinyint(1) NOT NULL,
  `int_numero_confirmacion_per` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Volcado de datos para la tabla `tbl_usuariopersona`
--

INSERT INTO `tbl_usuariopersona` (`int_cedula_per`, `var_nombre_per`, `var_apellido_per`, `int_telefono_per`, `int_celular_per`, `var_correo_per`, `var_direcion_per`, `var_password_per`, `var_billetera1_per`, `var_billetera2_per`, `int_no_cte_bancaria_per`, `int_entidad_bancaria_per`, `var_tipo_cuenta_per`, `bool_estado_per`, `var_code_confirmacion_per`, `bool_confirmacion_per`, `int_numero_confirmacion_per`) VALUES
(71774495, 'julian', 'galeano', 5535850, 3015966466, 'julian.galeano32@gmail.com', 'cl 75a # 73 39', 'CIgNHaRKVG3o0OtHub8r/O9h/GCz2/MRIoBYaUySa6g=', 'fñalsdjpoawier0', 'ñalskdjfañslkdjf', 2391238223122321, 7, 'Ahorros', 0, 'ujxYI6s41A8cn4dcEVxUMYsBJ', 0, 71830),
(1000898270, 'yeisson', 'sanchez', 5535850, 3015966466, 'j.arley111@gmail.com', 'sadasd', 'vWE4pL3/n1jYwHUM6nP7EbaBYUx8vfNwDo/HH6t50qU=', 'asdasd', 'asdsad', 12324324324223, 53, 'Ahorros', 0, 'ya confirmo el correo', 1, 762340);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tbl_banco`
--
ALTER TABLE `tbl_banco`
  ADD PRIMARY KEY (`int_codigo_ban`),
  ADD UNIQUE KEY `UNIQUE_NIT` (`var_nit_ban`) USING BTREE;

--
-- Indices de la tabla `tbl_log`
--
ALTER TABLE `tbl_log`
  ADD PRIMARY KEY (`int_id_log`),
  ADD KEY `FK_LOG_1` (`int_documento_log`) USING BTREE;

--
-- Indices de la tabla `tbl_log_cliente`
--
ALTER TABLE `tbl_log_cliente`
  ADD PRIMARY KEY (`int_id_logc`),
  ADD KEY `FK_LOG_CLIENTE` (`int_documento_per`);

--
-- Indices de la tabla `tbl_orden`
--
ALTER TABLE `tbl_orden`
  ADD PRIMARY KEY (`int_id_ord`),
  ADD KEY `FK_ORDEN_2` (`int_cedula_per`),
  ADD KEY `FK_ORDEN_1` (`int_cedula_use`) USING BTREE;

--
-- Indices de la tabla `tbl_rol`
--
ALTER TABLE `tbl_rol`
  ADD PRIMARY KEY (`int_id_rol`);

--
-- Indices de la tabla `tbl_transacion`
--
ALTER TABLE `tbl_transacion`
  ADD PRIMARY KEY (`int_id_trans`),
  ADD KEY `FK_TRANSACION_1` (`int_orden_ord`),
  ADD KEY `FK_TRANSACION_2` (`int_banco_ban`);

--
-- Indices de la tabla `tbl_usuario`
--
ALTER TABLE `tbl_usuario`
  ADD PRIMARY KEY (`int_documento_use`),
  ADD KEY `FK_USUARIO_1` (`int_role_rol`);

--
-- Indices de la tabla `tbl_usuariopersona`
--
ALTER TABLE `tbl_usuariopersona`
  ADD PRIMARY KEY (`int_cedula_per`),
  ADD UNIQUE KEY `UNIQUE_PERSONA_1` (`var_billetera1_per`),
  ADD UNIQUE KEY `UNIQUE_PERSONA_2` (`var_billetera2_per`),
  ADD UNIQUE KEY `UNIQUE_PERSONA_3` (`int_no_cte_bancaria_per`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tbl_banco`
--
ALTER TABLE `tbl_banco`
  MODIFY `int_codigo_ban` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT de la tabla `tbl_log`
--
ALTER TABLE `tbl_log`
  MODIFY `int_id_log` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `tbl_log_cliente`
--
ALTER TABLE `tbl_log_cliente`
  MODIFY `int_id_logc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `tbl_orden`
--
ALTER TABLE `tbl_orden`
  MODIFY `int_id_ord` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `tbl_rol`
--
ALTER TABLE `tbl_rol`
  MODIFY `int_id_rol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `tbl_transacion`
--
ALTER TABLE `tbl_transacion`
  MODIFY `int_id_trans` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `tbl_log`
--
ALTER TABLE `tbl_log`
  ADD CONSTRAINT `tbl_log_ibfk_1` FOREIGN KEY (`int_documento_log`) REFERENCES `tbl_usuario` (`int_documento_use`);

--
-- Filtros para la tabla `tbl_log_cliente`
--
ALTER TABLE `tbl_log_cliente`
  ADD CONSTRAINT `tbl_log_cliente_ibfk_1` FOREIGN KEY (`int_documento_per`) REFERENCES `tbl_usuariopersona` (`int_cedula_per`);

--
-- Filtros para la tabla `tbl_orden`
--
ALTER TABLE `tbl_orden`
  ADD CONSTRAINT `tbl_orden_ibfk_1` FOREIGN KEY (`int_cedula_use`) REFERENCES `tbl_usuario` (`int_documento_use`),
  ADD CONSTRAINT `tbl_orden_ibfk_2` FOREIGN KEY (`int_cedula_per`) REFERENCES `tbl_usuariopersona` (`int_cedula_per`);

--
-- Filtros para la tabla `tbl_transacion`
--
ALTER TABLE `tbl_transacion`
  ADD CONSTRAINT `tbl_transacion_ibfk_1` FOREIGN KEY (`int_banco_ban`) REFERENCES `tbl_banco` (`int_codigo_ban`),
  ADD CONSTRAINT `tbl_transacion_ibfk_2` FOREIGN KEY (`int_orden_ord`) REFERENCES `tbl_orden` (`int_id_ord`);

--
-- Filtros para la tabla `tbl_usuario`
--
ALTER TABLE `tbl_usuario`
  ADD CONSTRAINT `tbl_usuario_ibfk_1` FOREIGN KEY (`int_role_rol`) REFERENCES `tbl_rol` (`int_id_rol`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
