<div class="container-fluid contenido">
  <div class="header modal-header">
    <h4 class="text-color"> Datos</h4>
      <div class="row">
        <div class="col-md-2">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="cedulaperso">cedula</label>
            <input name="cedulaperso" class="form-control" id="cedulaperso" type="text" value="<?php echo $data['cedula']; ?>" readonly="readonly">
          </div>
        </div>
        <div class="col-md-5">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="nombrePerso">Nombre</label>
            <input name="nombrePerso" class="form-control" id="nombrePerso" type="text" value="<?php echo $data['nombre']; ?>" readonly="readonly">
          </div>
        </div>
        <div class="col-md-5">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="ApellidoPerso">Apellido</label>
            <input name="ApellidoPerso" class="form-control" id="ApellidoPerso" type="text" value="<?php echo $data['apellido']; ?>" readonly="readonly">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="DirecionPerso">Direcion</label>
            <input name="DirecionPerso" class="form-control" id="DirecionPerso" type="text" value="<?php echo $data['direcion']; ?>" readonly="readonly">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="emailPerso">E-mail</label>
            <input name="emailPerso" class="form-control" id="emailPerso" type="email" value="<?php echo $data['email']; ?>" readonly="readonly">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="Telefono1Perso">Telefono 1</label>
            <input name="Telefono1Perso" class="form-control" id="Telefono1Perso" type="Number" value="<?php echo $data['telefono1']; ?>" readonly="readonly">
          </div>
        </div>
        <div class="col-md-4">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="Telefono2Perso">Telofono 2</label>
            <input name="Telefono2Perso" class="form-control" id="Telefono2Perso" type="Number" value="<?php echo $data['telefono2']; ?>" readonly="readonly">
          </div>
        </div>
        <div class="col-md-4">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="CelularPerso">Celular</label>
            <input name="CelularPerso" class="form-control" id="CelularPerso" type="Number" value="<?php echo $data['celular']; ?>" readonly="readonly">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="referentePerso">Referente</label>
            <input name="referentePerso" class="form-control" id="referentePerso" type="text" value="<?php echo $data['referencia']; ?>" readonly="readonly">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="pasaportePerso">Pasaporte</label>
            <input name="pasaportePerso" class="form-control" id="pasaportePerso" type="text" value="<?php echo $data['pasaporte']; ?>" readonly="readonly">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-12">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="ObservacionesPerso">Observaciones</label>
            <textarea name="ObservacionesPerso" class="form-control" id="ObservacionesPerso" type="text" readonly="readonly"><?php echo $data['observaciones']; ?></textarea>
          </div>
        </div>
      </div>

      <h4 class="text-color"> holding</h4>

      <div class="table-responsive padding" >
        <table id="dataTables" class="table tablesorter table-bordred table-striped table-striped table-hover ">
          <thead class="heade-table">
            <th class="font th">Id producto</th>
            <th class="font th">Fecha</th>
            <th class="font th">Valor</th>
            <th class="font th">Producto</th>
            <th class="font th">Opciones</th>
          </thead>
          <tbody>
            <?php foreach ($holding as $dataholding): ?>
            <tr>
              <td title="Id producto" class="text-color"><?php echo $dataholding['id_producto']; ?></td>
              <td title="Fecha" class="text-color"><?php echo $dataholding['fecha']; ?></td>
              <td title="Valor" class="text-color"><?php echo $dataholding['valor']; ?></td>
              <td title="Observacion" class="text-color"><?php echo $dataholding['name_producto']; ?></td>
              <td>

                <button class="btn btn-raised btn-warning btn-xs btne" data-title="ver detalle"
                data-placement="top" data-toggle="tooltip" title="ver detalle"
                onclick="location='index.php?c=holding&a=holding&id=<?php echo $dataholding['id_producto']; ?>'">
                <span class="glyphicon glyphicon-eye-open"></span>
                </button>

              </td>
            </tr>
            <?php endforeach;?>
          </tbody>
        </table>
      </div>

      <button type="button" class="btn background-color lineal-button font" id="button" onclick="location='index.php?c=clientes'">
        <span class="glyphicon glyphicon-arrow-left"></span>
          Regresar
      </button>
  </div>
</div>