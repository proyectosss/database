<div class="container-fluid contenido">
  <div class="row">
    <div class="col-md-12">
      <div class=" header modal-header">
        <h4 class="title text-color font">Productos</h4>
      </div>
      <div class="table-responsive padding" >
        <table id="dataTables" class="table tablesorter table-bordred table-striped table-striped table-hover ">
          <thead class="heade-table">
            <th class="font th">Nombre</th>
            <th class="font th">Descripcion</th>
            <th class="font th">Observaciones</th>
          </thead>
          <tbody>
            <?php foreach ($data as $dataproduct): ?>
            <tr>

              <td title="Nombre" class="text-color"><?php echo $dataproduct['nombre_producto']; ?></td>
              <td title="Descripcion" class="text-color"><?php echo $dataproduct['descripcion_producto']; ?></td>
              <td title="Observaciones" class="text-color"><?php echo $dataproduct['observacion_producto']; ?></td>
            </tr>
            <?php endforeach;?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>