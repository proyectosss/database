<div class="container-fluid contenido">
    <div class="row">
        <h1>bienvinido usuario basico!!</h1><br/>
        <?php
echo nl2br("nombre: " . $_SESSION["name"] . "\n");

?>
    </div>
</div>
