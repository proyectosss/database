<div class="container-fluid contenido">
  <div class="row">
    <div class="col-md-12">
      <div class=" header modal-header">
        <h4 class="title text-color font">Productos</h4>
      </div>
      <div class="padding">
        <button type="button" class="btn font background-color glyphicon glyphicon-plus " id="button" onclick="location='index.php?c=productos&a=crear'">
        Agregar
        </button>
      </div>

      <div class="table-responsive padding" >
        <table id="dataTables" class="table tablesorter table-bordred table-striped table-striped table-hover ">
          <thead class="heade-table">
            <th class="font th">Nombre</th>
            <th class="font th">Descripcion</th>
            <th class="font th">Observaciones</th>
            <th class="font th">Opciones</th>
          </thead>
          <tbody>
            <?php foreach ($data as $dataproduct): ?>
            <tr>

              <td title="Nombre" class="text-color"><?php echo $dataproduct['nombre_producto']; ?></td>
              <td title="Descripcion" class="text-color"><?php echo $dataproduct['descripcion_producto']; ?></td>
              <td title="Observaciones" class="text-color"><?php echo $dataproduct['observacion_producto']; ?></td>
              <td>
                <button class="btn btn-raised btn-primary btn-xs btne" data-title="Edit"
                data-placement="top" data-toggle="tooltip" title="Edit"
                onclick="location='index.php?c=productos&a=update&id=<?php echo $dataproduct['id_producto']; ?>'">
                <span class="glyphicon glyphicon-pencil"></span>
                </button>

                <button class="btn btn-raised btn-danger btn-xs btnd" data-title="Delete" title="Delete" data-placement="top" data-toggle="tooltip"
                onclick="Eliminar('<?php echo $dataproduct['id_producto']; ?>','<?php echo $dataproduct['nombre_producto']; ?>','index.php?c=productos&a=delete');">
                <span class="glyphicon glyphicon-trash" ></span>
                </button>
              </td>
            </tr>
            <?php endforeach;?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>