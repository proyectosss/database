<div class="container-fluid contenido">
  <div class="header modal-header">
    <h4 class="text-color"> Nuevo producto</h4>
    <form  action="index.php?c=productos&a=nuevo"  method="post" enctype="multipart/form-data" name="createIRP">
      <input type="hidden" name="id" value="<?php echo $_GET['company']; ?>">

      <div class="row">
        <div class="col-md-12">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="nombreProduct">Nombre</label>
            <input name="nombreProduct" class="form-control" id="nombreProduct" type="text" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="DescripcionProduc">Descripcion</label>
            <textarea name="DescripcionProduc" class="form-control" id="DescripcionProduc" type="text" required="required"></textarea>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="ObservacionesProduc">Observaciones</label>
            <textarea name="ObservacionesProduc" class="form-control" id="ObservacionesProduc" type="text" required="required"></textarea>
          </div>
        </div>
      </div>

      <button type="submit" class="btn background-color lineal-button font" id="button">
        <span class="glyphicon glyphicon-floppy-saved"></span>
          Guardar
      </button>

      <button type="button" class="btn background-color lineal-button font" id="button" onclick="location='index.php?c=productos'">
        <span class="glyphicon glyphicon-arrow-left"></span>
          Regresar
      </button>

    </form>
  </div>
</div>