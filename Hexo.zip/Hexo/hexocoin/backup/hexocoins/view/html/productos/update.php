<div class="container-fluid contenido">
  <div class="header modal-header">
    <h4 class="text-color"> Actualizar producto</h4>
    <form  action="index.php?c=productos&a=actualizar"  method="post" enctype="multipart/form-data" name="createproducto">
    <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
      <div class="row">
        <div class="col-md-12">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="nombreProduct">Nombre</label>
            <input name="nombreProduct" class="form-control" id="nombreProduct" type="text" value="<?php echo $data['nombre_producto']; ?>" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="DescripcionProduc">Descripcion</label>
            <textarea name="DescripcionProduc" class="form-control" id="DescripcionProduc" type="text" required="required"><?php echo $data['descripcion_producto']; ?></textarea>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="ObservacionesProduc">Observaciones</label>
            <textarea name="ObservacionesProduc" class="form-control" id="ObservacionesProduc" type="text" required="required"><?php echo $data['observaciones']; ?></textarea>
          </div>
        </div>
      </div>

      <button type="submit" class="btn background-color lineal-button font" id="button">
        <span class="glyphicon glyphicon-floppy-saved"></span>
          Guardar
      </button>

      <button type="button" class="btn background-color lineal-button font" id="button" onclick="location='index.php?c=productos'">
        <span class="glyphicon glyphicon-arrow-left"></span>
          Regresar
      </button>

    </form>
  </div>
</div>
