<div class="container-fluid contenido">
  <div class="header modal-header">
    <h4 class="text-color"> Actualizar datos de cliente</h4>
    <form  action="index.php?c=clientes&a=actualizar"  method="post" enctype="multipart/form-data" name="createIRP">


      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="nombrePerso">Nombre</label>
            <input name="nombrePerso" class="form-control" id="nombrePerso" type="text" value="<?php echo $data['nombre']; ?>" required="required">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="ApellidoPerso">Apellido</label>
            <input name="ApellidoPerso" class="form-control" id="ApellidoPerso" type="text" value="<?php echo $data['apellido']; ?>" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="DirecionPerso">Direcion</label>
            <input name="DirecionPerso" class="form-control" id="DirecionPerso" type="text" value="<?php echo $data['direcion']; ?>"  required="required">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="emailPerso">E-mail</label>
            <input name="emailPerso" class="form-control" id="emailPerso" type="email" value="<?php echo $data['email']; ?>" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="Telefono1Perso">Telefono 1</label>
            <input name="Telefono1Perso" class="form-control" id="Telefono1Perso" type="Number" value="<?php echo $data['telefono1']; ?>" required="required">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="Telefono2Perso">Telofono 2</label>
            <input name="Telefono2Perso" class="form-control" id="Telefono2Perso" type="Number" value="<?php echo $data['telefono2']; ?>" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="CelularPerso">Celular</label>
            <input name="CelularPerso" class="form-control" id="CelularPerso" type="Number" value="<?php echo $data['celular']; ?>" required="required">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="pasaportePerso">Pasaporte</label>
            <input name="pasaportePerso" class="form-control" id="pasaportePerso" type="text" value="<?php echo $data['pasaporte']; ?>" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="referentePerso">Referente</label>
            <input name="referentePerso" class="form-control" id="referentePerso" type="text" value="<?php echo $data['referencia']; ?>" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="ObservacionesPerso">Observaciones</label>
            <textarea name="ObservacionesPerso" class="form-control" id="ObservacionesPerso" type="text" required="required"><?php echo $data['observaciones']; ?></textarea>
          </div>
        </div>
      </div>
      <input type="hidden" name="DocumentoPerso" value="<?php echo $data['cedula']; ?>">
      <button type="submit" class="btn background-color lineal-button font" id="button">
        <span class="glyphicon glyphicon-floppy-saved"></span>
          Guardar
      </button>

      <button type="button" class="btn background-color lineal-button font" id="button" onclick="location='index.php?c=clientes'">
        <span class="glyphicon glyphicon-arrow-left"></span>
          Regresar
      </button>

    </form>
  </div>
</div>
