<div class="container-fluid contenido">
  <div class="row">
    <div class="col-md-12">
      <div class=" header modal-header">
        <h4 class="title text-color font">Clientes</h4>
      </div>
      <div class="padding">
        <button type="button" class="btn font background-color glyphicon glyphicon-plus " id="button" onclick="location='index.php?c=clientes&a=crear'">
        Agregar
        </button>
      </div>

      <div class="table-responsive padding" >
        <table id="dataTables" class="table tablesorter table-bordred table-striped table-striped table-hover ">
          <thead class="heade-table">
            <th class="font th">Cédula</th>
            <th class="font th">Nombre</th>
            <th class="font th">Apellido</th>
            <th class="font th">Direcion</th>
            <th class="font th">Teléfono 1</th>
            <th class="font th">Celular</th>
            <th class="font th">Email</th>
            <th class="font th">Pasaporte</th>
            <th class="font th">Opciones</th>
          </thead>
          <tbody>
            <?php foreach ($data as $dataclient): ?>
            <tr>
              <td title="Cédula" class="text-color"><?php echo $dataclient['cedula']; ?></td>
              <td title="Nombre" class="text-color"><?php echo $dataclient['nombre']; ?></td>
              <td title="Apellido" class="text-color"><?php echo $dataclient['apellido']; ?></td>
              <td title="Direcion" class="text-color"><?php echo $dataclient['direcion']; ?></td>
              <td title="Teléfono 1" class="text-color"><?php echo $dataclient['telefono1']; ?></td>
              <td title="Celular" class="text-color"><?php echo $dataclient['celular']; ?></td>
              <td title="email" class="text-color"><?php echo $dataclient['email']; ?></td>
              <td title="Pasaporte" class="text-color"><?php echo $dataclient['pasaporte']; ?></td>
              <td>
                <button class="btn btn-raised btn-primary btn-xs btne" data-title="Edit"
                data-placement="top" data-toggle="tooltip" title="Edit"
                onclick="location='index.php?c=clientes&a=update&cedula=<?php echo $dataclient['cedula']; ?>'">
                <span class="glyphicon glyphicon-pencil"></span>
                </button>

                <button class="btn btn-raised btn-warning btn-xs btne" data-title="ver detalle"
                data-placement="top" data-toggle="tooltip" title="Edit"
                onclick="location='index.php?c=holding&a=vista_datos&cedula=<?php echo $dataclient['cedula']; ?>'">
                <span class="glyphicon glyphicon-eye-open"></span>
                </button>

                <button class="btn btn-raised btn-danger btn-xs btne" data-title="Delete" title="Delete" data-placement="top" data-toggle="tooltip"
                onclick="Eliminar('<?php echo $dataclient['cedula']; ?>','<?php echo $dataclient['cedula']; ?>','index.php?c=clientes&a=delete');">
                <span class="glyphicon glyphicon-trash" ></span>
                </button>
              </td>
            </tr>
            <?php endforeach;?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>