<div class="container-fluid contenido">
  <div class="header modal-header">
    <h4 class="text-color"> Actualizar datos del usuario con la cedula: <?php echo $data['cedula']; ?></h4>
    <form  action="index.php?c=usuario&a=actualizar&cedula=<?php echo $data['cedula']; ?>"  method="post" enctype="multipart/form-data" name="createUsuario">
    <input type="hidden" name="cedula" value="<?php echo $_GET['cedula']; ?>">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="nombreUser">Nombre</label>
            <input name="nombreUser" class="form-control" id="nombreUser" type="text" value="<?php echo $data['nombre']; ?>" required="required">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="ApellidoUser">Apellido</label>
            <input name="ApellidoUser" class="form-control" id="ApellidoUser" type="text" value="<?php echo $data['apellido']; ?>" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="CelularUser">Celular</label>
            <input name="CelularUser" class="form-control" id="CelularUser" type="number" value="<?php echo $data['celular']; ?>" required="required">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="TelefonoUser">Telefono</label>
            <input name="TelefonoUser" class="form-control" id="TelefonoUser" type="number" value="<?php echo $data['telefono']; ?>" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-12">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="emailUser">E-mail</label>
            <input name="emailUser" class="form-control" id="emailUser" type="email" value="<?php echo $data['email']; ?>" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label text-color" for="select111"> Rol: </label>
            <select class="form-control" id="select111" name="Rol" required="required">
              <option></option>
              <?php if ($data["role"] == "Administrador") {?>
              <option selected="selected">Administrador</option>
              <option>Básico</option>
              <?php } elseif ($data["role"] == "Básico") {?>
              <option>Administrador</option>
              <option selected="selected">Básico</option>
              <?php }?>
            </select>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label text-color" for="estado"> Estado: </label>
            <select class="form-control" id="estado" name="estado" required="required">
              <option></option>
              <?php if ($data["estado"] == "Activo") {?>
              <option selected="selected">Activo</option>
              <option>inactivo</option>
              <?php } elseif ($data["estado"] == "inactivo") {?>
              <option>Activo</option>
              <option selected="selected">inactivo</option>
              <?php }?>
            </select>
          </div>
        </div>
      </div>



      <button type="submit" class="btn background-color lineal-button font" id="button">
        <span class="glyphicon glyphicon-floppy-saved"></span>
          Guardar
      </button>

      <button type="button" class="btn background-color lineal-button font" id="button" onclick="location='index.php?c=usuario'">
        <span class="glyphicon glyphicon-arrow-left"></span>
          Regresar
      </button>

    </form>
  </div>
</div>
