<div class="container-fluid contenido">
  <div class="header modal-header">
    <h4 class="text-color"> Nuevo usuario</h4>
    <form  action="index.php?c=usuario&a=nuevo"  method="post" enctype="multipart/form-data" onsubmit="return validacionUsuario();" name="createUsuario">
      <div class="row">
        <div class="col-md-12">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="DocumentoUser">Documento</label>
            <input name="DocumentoUser" class="form-control" id="DocumentoUser" type="Number" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="nombreUser">Nombre</label>
            <input name="nombreUser" class="form-control" id="nombreUser" type="text" required="required">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="ApellidoUser">Apellido</label>
            <input name="ApellidoUser" class="form-control" id="ApellidoUser" type="text" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="CelularUser">Celular</label>
            <input name="CelularUser" class="form-control" id="CelularUser" type="number" required="required">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="TelefonoUser">Telefono</label>
            <input name="TelefonoUser" class="form-control" id="TelefonoUser" type="number" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="fechaIngreso">Fecha de inicio</label>
            <input name="fechaIngreso" class="form-control" id="fechaIngreso" type="date" value="<?php echo date('Y-m-d'); ?>" readonly="readonly">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="emailUser">E-mail</label>
            <input name="emailUser" class="form-control" id="emailUser" type="email" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="Password">Password</label>
            <input name="Password" class="form-control" id="Password" type="password" required="required">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="Confirmapass">Confirma password</label>
            <input name="Confirmapass" class="form-control" id="Confirmapass" type="password" required="required">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label text-color" for="select111"> Rol: </label>
            <select class="form-control" id="select111" name="Rol" required="required">
              <option></option>
              <option>Administrador</option>
              <option>Básico</option>
            </select>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label text-color" for="estado"> Estado: </label>
            <select class="form-control" id="estado" name="estado" required="required">
              <option></option>
              <option>Activo</option>
              <option>inactivo</option>
            </select>
          </div>
        </div>
      </div>



      <button type="submit" class="btn background-color lineal-button font" id="button">
        <span class="glyphicon glyphicon-floppy-saved"></span>
          Guardar
      </button>

      <button type="button" class="btn background-color lineal-button font" id="button" onclick="location='index.php?c=usuario'">
        <span class="glyphicon glyphicon-arrow-left"></span>
          Regresar
      </button>

    </form>
  </div>
</div>
