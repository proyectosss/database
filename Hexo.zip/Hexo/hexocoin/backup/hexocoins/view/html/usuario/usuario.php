<div class="container-fluid contenido">
  <div class="row">
    <div class="col-md-12">
      <div class=" header modal-header">
        <h4 class="title text-color font">Usuario</h4>
      </div>
      <div class="padding">
        <button type="button" class="btn font background-color glyphicon glyphicon-plus " id="button" onclick="location='index.php?c=usuario&a=crear'">
        Agregar
        </button>
      </div>

      <div class="table-responsive padding" >
        <table id="dataTables" class="table tablesorter table-bordred table-striped table-striped table-hover ">
          <thead class="heade-table">
            <th class="font th">Cédula</th>
            <th class="font th">Nombre</th>
            <th class="font th">Apellido</th>
            <th class="font th">Teléfono</th>
            <th class="font th">Celular</th>
            <th class="font th">E-mail</th>
            <th class="font th">Estado</th>
            <th class="font th">Fecha</th>
            <th class="font th">Role</th>
            <th class="font th">Opciones</th>
          </thead>
          <tbody>
            <?php foreach ($data as $dataUsuario): ?>
            <tr>
              <td title="Cédula" class="text-color"><?php echo $dataUsuario['cedula']; ?></td>
              <td title="Nombre" class="text-color"><?php echo $dataUsuario['nombre']; ?></td>
              <td title="Apellido" class="text-color"><?php echo $dataUsuario['apellido']; ?></td>
              <td title="Teléfono" class="text-color"><?php echo $dataUsuario['telefono']; ?></td>
              <td title="Celular" class="text-color"><?php echo $dataUsuario['celular']; ?></td>
              <td title="E-mail" class="text-color"><?php echo $dataUsuario['email']; ?></td>
              <td title="Estado" class="text-color"><?php echo $dataUsuario['estado']; ?></td>
              <td title="Fecha" class="text-color"><?php echo $dataUsuario['fecha']; ?></td>
              <td title="Role" class="text-color"><?php echo $dataUsuario['role']; ?></td>
              <td>
                <button class="btn btn-raised btn-primary btn-xs btne" data-title="Edit"
                data-placement="top" data-toggle="tooltip" title="Edit"
                onclick="location='index.php?c=usuario&a=update&cedula=<?php echo $dataUsuario['cedula']; ?>'">
                <span class="glyphicon glyphicon-pencil"></span>
                </button>

                <button class="btn btn-raised btn-danger btn-xs btne" data-title="Delete" title="Delete" data-placement="top" data-toggle="tooltip"
                onclick="Eliminar_persona('<?php echo $dataUsuario['cedula']; ?>','<?php echo $dataUsuario['nombre'] . " " . $dataUsuario['apellido']; ?>','index.php?c=usuario&a=delete');">
                <span class="glyphicon glyphicon-trash" ></span>
                </button>
              </td>
            </tr>
            <?php endforeach;?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>