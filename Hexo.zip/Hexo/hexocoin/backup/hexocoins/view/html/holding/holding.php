<div class="container-fluid contenido">
  <div class="header modal-header">
    <h4 class="text-color"> holding</h4>
      <div class="row">
        <div class="col-md-2">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="cedulaperso">Id producto</label>
            <input name="cedulaperso" class="form-control" id="cedulaperso" type="text" value="<?php echo $holding['id_producto']; ?>" readonly="readonly">
          </div>
        </div>
        <div class="col-md-3">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="nombrePerso">Fecha</label>
            <input name="nombrePerso" class="form-control" id="nombrePerso" type="date" value="<?php echo $holding['fecha']; ?>" readonly="readonly">
          </div>
        </div>
        <div class="col-md-5">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="ApellidoPerso">Valor</label>
            <input name="ApellidoPerso" class="form-control" id="ApellidoPerso" type="text" value="<?php echo $holding['valor']; ?>" readonly="readonly">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="DirecionPerso">Producto</label>
            <input name="DirecionPerso" class="form-control" id="DirecionPerso" type="text" value="<?php echo $holding['observacione']; ?>" readonly="readonly">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="emailPerso">E-Observacion</label>
            <input name="emailPerso" class="form-control" id="emailPerso" type="text" value="<?php echo $holding['observacione']; ?>" readonly="readonly">
          </div>
        </div>
      </div>


      <h4 class="text-color"> holding detail</h4>
      <div class="padding">
        <button type="button" class="btn font background-color glyphicon glyphicon-plus " id="button" onclick="location='index.php?c=holding&a=crear_holding_detail&id_producto=<?php echo $holding['id_producto']; ?>'">
        Agregar
        </button>
      </div>
      </div>
      <div class="table-responsive padding" >
        <table id="dataTables" class="table tablesorter table-bordred table-striped table-striped table-hover ">
          <thead class="heade-table">
            <th class="font th">Id producto</th>
            <th class="font th">Fecha</th>
            <th class="font th">Descipcion</th>
            <th class="font th">btc</th>
            <th class="font th">btc al dia</th>
            <th class="font th">usd</th>
            <th class="font th">cop</th>
            <th class="font th">SoportePago</th>
          </thead>
          <tbody>
            <?php foreach ($data as $dataholding): ?>
            <tr>
              <td title="Id producto" class="text-color"><?php echo $dataholding['id_producto']; ?></td>
              <td title="Fecha" class="text-color"><?php echo $dataholding['fecha']; ?></td>
              <td title="Descipcion" class="text-color"><?php echo $dataholding['descipcion']; ?></td>
              <td title="btc" class="text-color"><?php echo $dataholding['btc']; ?></td>
              <td title="btc al dia" class="text-color"><?php echo $dataholding['btcdia']; ?></td>
              <td title="usd" class="text-color"><?php echo $dataholding['usd']; ?></td>
              <td title="cop" class="text-color"><?php echo $dataholding['cop']; ?></td>
              <td title="Soporte de Pago" class="text-color">
                <div class="celda-foto">
                      <img alt="" id="imageBankTable" src="<?php echo $dataholding['SoportePago']; ?>" />
                    </div>
              </td>
            </tr>
            <?php endforeach;?>
          </tbody>
        </table>
      </div>

      <button type="button" class="btn background-color lineal-button font" id="button" onclick="location='index.php?c=clientes'">
        <span class="glyphicon glyphicon-arrow-left"></span>
          Regresar
      </button>

  </div>
</div>