<div class="container-fluid contenido">
  <div class="header modal-header">
    <h4 class="text-color"> Nuevo holding detail</h4>
    <form  action="index.php?c=holding&a=nuevo_holding_detail" enctype="multipart/form-data" method="post">
      <input type="hidden" name="id_producto" value="<?php echo $_GET['id_producto']; ?>">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="fechadetail">Fecha</label>
            <input name="fechadetail" class="form-control" id="fechadetail" type="date" value="<?php echo date('Y-m-d'); ?>" required="required">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="BTCdetail">BTC</label>
            <input name="BTCdetail" class="form-control"  min="0" value="0" id="BTCdetail" type="Number" step="any" required="required">
          </div>
        </div>
      </div>


      <div class="row">
        <div class="col-md-4">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="Preciodetail">Precio BTC</label>
            <input name="Preciodetail" class="form-control"  min="0" value="0" id="Preciodetail" type="Number" step="any" required="required">
          </div>
        </div>
        <div class="col-md-4">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="USDdetail">USD</label>
            <input name="USDdetail" class="form-control"  min="0" value="0" id="USDdetail" type="Number" step="any" required="required">
          </div>
        </div>
        <div class="col-md-4">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="COPdetail">COP</label>
            <input name="COPdetail" class="form-control"  min="0" value="0" id="COPdetail" type="Number" step="any" required="required">
          </div>
        </div>
      </div>



      <div class="row">
        <div class="col-md-6">
          <label for="soporte" id="label-p">Soporte</label>
          <div class="drag-drop">
            <input type="file" multiple="multiple" name="soporte" id="soporte" required="required" />
            <span class="fa-stack fa-2x">
            <img id="imageSoporte" class="img-responsive"  for="file" src="view/imagenes/no-image.jpg"/>
            </span>
            <span class="desc">Pulse aquí para añadir archivos</span>
          </div>
        </div>

        <div class="col-md-6">
          <div class="form-group label-floating">
            <label class="control-label" id="label-p" for="detailDescripcion">Descripcion</label>
            <textarea name="detailDescripcion" class="form-control" id="detailDescripcion" type="text" required="required"></textarea>
          </div>
        </div>
      </div>



      <button type="submit" class="btn background-color lineal-button font" id="button">
        <span class="glyphicon glyphicon-floppy-saved"></span>
          Guardar
      </button>

      <button type="button" class="btn background-color lineal-button font" id="button" onclick="location='index.php?c=clientes'">
        <span class="glyphicon glyphicon-arrow-left"></span>
          Regresar
      </button>

    </form>
  </div>
</div>
