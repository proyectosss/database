<?php
class holding_modelo
{
    private $DB;
    private $holding;

    public function __construct()
    {
        $this->DB       = conexion::getConnection();
        $this->holding  = array();
        $this->personal = array();
    }

    public function queryholding($cedula)
    {
        $query = $this->DB->query("CALL sp_obtener_holding('" . $cedula . "')");
        while ($fila = $query->fetch_assoc()) {
            $this->holding[] = $fila;
        }
        return $this->holding;
    }

    public function query($id)
    {
        $query = $this->DB->query("CALL sp_consulta_datos_personales('" . $id . "')");
        while ($fila = $query->fetch_assoc()) {
            $this->personal = $fila;
        }
        return $this->personal;
    }

    public function holdingconsulta($id)
    {
        $query = $this->DB->query("CALL sp_consulta_holding('" . $id . "')");
        while ($fila = $query->fetch_assoc()) {
            $this->holding = $fila;
        }
        return $this->holding;
    }

    public function save($productoHolding, $documentoHolding, $fechaHolding, $valorHolding, $ProductosHolding, $HoldingObservaciones)
    {

        $query = "CALL sp_ingreso_holding   ('" . $productoHolding . "', '" . $documentoHolding . "', '" . $fechaHolding . "', '" . $valorHolding . "', '" . $ProductosHolding . "', '" . $HoldingObservaciones . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }

    public function update($ObservacionHolding, $ValorHolding, $productoHolding, $fechaHolding)
    {
        $query = "CALL sp_actualizar_holding('" . $ValorHolding . "', '" . $ObservacionHolding . "', '" . $fechaHolding . "','" . $productoHolding . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }

    public function delete($int_id)
    {
        $query = "CALL sp_eliminar_holding('" . $int_id . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }

}
