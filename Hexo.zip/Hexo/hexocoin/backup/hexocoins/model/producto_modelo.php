<?php
class producto_modelo
{
    private $DB;
    private $producto;

    public function __construct()
    {
        $this->DB       = conexion::getConnection();
        $this->producto = array();
    }

    public function save($nombreProduct, $DescripcionProduc, $ObservacionesProduc)
    {

        $query = "CALL  sp_producto_ingreso('" . $nombreProduct . "', '" . $DescripcionProduc . "', '" . $ObservacionesProduc . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }
    public function get()
    {
        $query = $this->DB->query("CALL sp_leer_producto()");
        while ($fila = $query->fetch_assoc()) {
            $this->producto[] = $fila;
        }
        return $this->producto;
    }

    public function query($id)
    {
        $query = $this->DB->query("CALL sp_consulta_producto('" . $id . "')");
        while ($fila = $query->fetch_assoc()) {
            $this->producto = $fila;
        }
        return $this->producto;
    }

    public function obtener($id)
    {
        $query = $this->DB->query("CALL sp_producto_name_obtener('" . $id . "')");
        while ($fila = $query->fetch_assoc()) {
            $this->producto = $fila;
        }
        return $this->producto;
    }

    public function update($nombreProduct, $DescripcionProduc, $ObservacionesProduc, $id)
    {
        $query = "CALL sp_actualizar_producto('" . $nombreProduct . "', '" . $DescripcionProduc . "', '" . $ObservacionesProduc . "', '" . $id . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }

    public function delete($int_id)
    {
        $query = "CALL sp_eliminar_producto('" . $int_id . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }
}
