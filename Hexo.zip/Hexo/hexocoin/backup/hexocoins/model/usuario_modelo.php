<?php
class usuario_modelo
{
    private $DB;
    private $usuario;

    public function __construct()
    {
        $this->DB      = conexion::getConnection();
        $this->usuario = array();
    }

    public function save($DocumentoUser, $nombreUser, $ApellidoUser, $CelularUser, $emailUser, $Password, $Rol, $estado, $fechaIngreso, $TelefonoUser)
    {

        $query = "CALL sp_igreso_usuario ('" . $DocumentoUser . "', '" . $nombreUser . "', '" . $ApellidoUser . "', '" . $TelefonoUser . "', '" . $CelularUser . "', '" . $emailUser . "', '" . $Password . "', '" . $estado . "', '" . $fechaIngreso . "', '" . $Rol . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }

    public function get()
    {
        $query = $this->DB->query("CALL sp_leer_usuario()");
        while ($fila = $query->fetch_assoc()) {
            $this->usuario[] = $fila;
        }
        return $this->usuario;
    }

    public function query($id)
    {
        $query = $this->DB->query("CALL sp_consulta_usuario('" . $id . "')");
        while ($fila = $query->fetch_assoc()) {
            $this->usuario = $fila;
        }
        return $this->usuario;
    }

    public function update($DocumentoUser, $nombreUser, $ApellidoUser, $CelularUser, $emailUser, $Rol, $estado, $TelefonoUser)
    {
        $query = "CALL sp_actualizar_usuario('" . $nombreUser . "', '" . $ApellidoUser . "', '" . $TelefonoUser . "', '" . $CelularUser . "', '" . $emailUser . "', '" . $estado . "', '" . $Rol . "','" . $DocumentoUser . "')";

        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }

    public function delete($int_id)
    {
        $query = "CALL sp_eliminar_usuario('" . $int_id . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }
}
