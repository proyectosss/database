<?php
class holding_detail_modelo
{
    private $DB;
    private $detail;

    public function __construct()
    {
        $this->DB     = conexion::getConnection();
        $this->detail = array();
    }

    public function holdingdetail($id)
    {
        $query = $this->DB->query("CALL sp_holding_detail_obtener('" . $id . "')");
        while ($fila = $query->fetch_assoc()) {
            $this->detail[] = $fila;
        }
        return $this->detail;
    }

    public function save($productoHolding, $fechadetail, $detailDescripcion, $BTCdetail, $Preciodetail, $USDdetail, $COPdetail, $soporte)
    {

        $query = "CALL sp_ingresar_holding_detail   ('" . $productoHolding . "', '" . $fechadetail . "', '" . $detailDescripcion . "', '" . $BTCdetail . "', '" . $Preciodetail . "', '" . $USDdetail . "', '" . $COPdetail . "', '" . $soporte . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }

    public function query($id)
    {
        $query = $this->DB->query("CALL sp_obtener_holding_detail('" . $id . "')");
        while ($fila = $query->fetch_assoc()) {
            $this->detail = $fila;
        }
        return $this->detail;
    }

    public function update($id_detail, $fechadetail, $detailDescripcion, $BTCdetail, $Preciodetail, $USDdetail, $COPdetail, $soporte)
    {
        $query = "CALL sp_actualizar_holding_detail('" . $detailDescripcion . "', '" . $BTCdetail . "', '" . $Preciodetail . "','" . $USDdetail . "','" . $COPdetail . "','" . $soporte . "','" . $fechadetail . "','" . $id_detail . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }

    public function delete($int_id)
    {
        $query = "CALL  sp_eliminar_holding_detail('" . $int_id . "')";
        mysqli_query($this->DB, $query) or die('error \n' . mysqli_error($this->DB));
    }
}
