<?php
class summary_controller
{
    private $sesion;
    public function __construct()
    {

    }

    public function index()
    {
        $tittle = "hexocoin-" . $_SESSION["name"];
        $ip     = getRealIP();
        if ($_SESSION["rol"] == 'Administrador') {
            require_once HTML_DIR . 'overall/header.php';
            require_once HTML_DIR . 'overall/topnav.html';
            require_once HTML_DIR . 'overall/home.php';
            require_once HTML_DIR . 'overall/modal.php';
            require_once HTML_DIR . 'overall/footer.php';
        } else {
            require_once HTML_DIR_BASIC . 'overall/header.php';
            require_once HTML_DIR_BASIC . 'overall/topnav.html';
            require_once HTML_DIR_BASIC . 'overall/home.php';
            require_once HTML_DIR_BASIC . 'overall/modal.php';
            require_once HTML_DIR_BASIC . 'overall/footer.php';
        }

    }
    public function cerrar()
    {
        session_destroy();
        header('location:index.php');
    }

}
