<?php

require_once 'model/cliente_modelo.php';
require_once 'model/holding_modelo.php';
require_once 'model/holding_detail_modelo.php';
require_once 'model/producto_modelo.php';
require_once 'model/log_modelo.php';

class holding_controller
{
    private $clientes;
    private $holding;
    private $detail;
    private $productos;
    private $logmodel;

    public function __construct()
    {
        $this->clientes  = new cliente_modelo();
        $this->holding   = new holding_modelo();
        $this->detail    = new holding_detail_modelo();
        $this->productos = new producto_modelo();
        $this->logmodel  = new log_modelo();
    }

    public function vista_datos()
    {
        $tittle  = "hexocoin-datos";
        $holding = $this->holding->queryholding($_GET['cedula']);
        $data    = $this->clientes->query($_GET['cedula']);
        if ($_SESSION["rol"] == 'Administrador') {
            require_once HTML_DIR . 'overall/header.php';
            require_once HTML_DIR . 'overall/topnav.html';
            require_once HTML_DIR . 'clientes/vista_datos.php';
            require_once HTML_DIR . 'overall/modal.php';
            require_once HTML_DIR . 'overall/footer.php';
        } else {
            require_once HTML_DIR_BASIC . 'overall/header.php';
            require_once HTML_DIR_BASIC . 'overall/topnav.html';
            require_once HTML_DIR_BASIC . 'clientes/vista_datos.php';
            require_once HTML_DIR_BASIC . 'overall/modal.php';
            require_once HTML_DIR_BASIC . 'overall/footer.php';
        }
    }

    public function holding()
    {
        $tittle  = "hexocoin-holding";
        $holding = $this->holding->holdingconsulta($_GET['id']);
        $data    = $this->detail->holdingdetail($_GET['id']);
        if ($_SESSION["rol"] == 'Administrador') {
            require_once HTML_DIR . 'overall/header.php';
            require_once HTML_DIR . 'overall/topnav.html';
            require_once HTML_DIR . 'holding/holding.php';
            require_once HTML_DIR . 'overall/modal.php';
            require_once HTML_DIR . 'overall/footer.php';
        } else {
            require_once HTML_DIR_BASIC . 'overall/header.php';
            require_once HTML_DIR_BASIC . 'overall/topnav.html';
            require_once HTML_DIR_BASIC . 'holding/holding.php';
            require_once HTML_DIR_BASIC . 'overall/modal.php';
            require_once HTML_DIR_BASIC . 'overall/footer.php';
        }
    }

    public function crear()
    {
        $tittle = "hexocoin-nuevo holding";

        if ($_SESSION["rol"] == 'Administrador') {
            $data = $this->productos->get();
            require_once HTML_DIR . 'overall/header.php';
            require_once HTML_DIR . 'overall/topnav.html';
            require_once HTML_DIR . 'holding/create.php';
            require_once HTML_DIR . 'overall/modal.php';
            require_once HTML_DIR . 'overall/footer.php';
        } else {
            echo "No tiene permiso";
        }
    }

    public function update()
    {
        $tittle = "hexocoin-Actualizar holding";
        if ($_SESSION["rol"] == 'Administrador') {
            $holding  = $this->holding->holdingconsulta($_GET['id']);
            $producto = $this->productos->obtener($holding['producto']);
            $data     = $this->detail->holdingdetail($_GET['id']);
            require_once HTML_DIR . 'overall/header.php';
            require_once HTML_DIR . 'overall/topnav.html';
            require_once HTML_DIR . 'holding/update.php';
            require_once HTML_DIR . 'overall/modal.php';
            require_once HTML_DIR . 'overall/footer.php';
        } else {
            echo "No tiene permiso";
        }
    }

    public function update_holding_detail()
    {
        $tittle = "hexocoin-Actualizar holding_detail";
        if ($_SESSION["rol"] == 'Administrador') {
            $data = $this->detail->query($_GET['id']);

            require_once HTML_DIR . 'overall/header.php';
            require_once HTML_DIR . 'overall/topnav.html';
            require_once HTML_DIR . 'holding/update_holding_detail.php';
            require_once HTML_DIR . 'overall/modal.php';
            require_once HTML_DIR . 'overall/footer.php';
        } else {
            echo "No tiene permiso";
        }
    }

    public function crear_holding_detail()
    {
        $tittle = "hexocoin-Nuevo holding-detail";
        if ($_SESSION["rol"] == 'Administrador') {
            require_once HTML_DIR . 'overall/header.php';
            require_once HTML_DIR . 'overall/topnav.html';
            require_once HTML_DIR . 'holding/holding_detail.php';
            require_once HTML_DIR . 'overall/modal.php';
            require_once HTML_DIR . 'overall/footer.php';
        } else {
            echo "No tiene permiso";
        }
    }

    public function nuevo()
    {
        if ($_SESSION["rol"] == 'Administrador') {
            $soporte = $this->imagen($_POST['productoHolding']);
            $this->holding->save($_POST['productoHolding'], $_POST['documentoHolding'], $_POST['fechaHolding'], $_POST['valorHolding'], $_POST['ProductosHolding'], $_POST['HoldingObservaciones']);

            $this->detail->save($_POST['productoHolding'], $_POST['fechadetail'], $_POST['detailDescripcion'], $_POST['BTCdetail'], $_POST['Preciodetail'], $_POST['USDdetail'], $_POST['COPdetail'], $soporte);

            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "agrego holding " . $_POST['productoHolding'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));

            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "agrego un holding detail del producto" . $_POST['productoHolding'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));
            header('Location: index.php?c=clientes');
        } else {
            echo "No tiene permiso";
        }

    }

    public function nuevo_holding_detail()
    {
        if ($_SESSION["rol"] == 'Administrador') {
            $soporte = $this->imagen($_POST['id_producto']);

            $this->detail->save($_POST['id_producto'], $_POST['fechadetail'], $_POST['detailDescripcion'], $_POST['BTCdetail'], $_POST['Preciodetail'], $_POST['USDdetail'], $_POST['COPdetail'], $soporte);

            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "agrego un holding detail del producto" . $_POST['productoHolding'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));

            header('Location: index.php?c=clientes');
        } else {
            echo "No tiene permiso";
        }

    }

    public function imagen($id_producto)
    {
        if ($_SESSION["rol"] == 'Administrador') {
            $fecha       = date('Y-m-d_(H_i_s)_');
            $soporte     = $_FILES["soporte"]["name"];
            $rutaSoporte = "view/imagenes/Soportes/" . "soporte_" . $fecha . $soporte;
            move_uploaded_file($_FILES['soporte']['tmp_name'], $rutaSoporte);

            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "subio soporte del producto " . $id_producto . " con la ruta: " . $rutaSoporte, getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));

            return $rutaSoporte;
        } else {
            echo "No tiene permiso";
        }
    }

    public function actualizar()
    {
        if ($_SESSION["rol"] == 'Administrador') {
            $this->holding->update($_POST['ObservacionHolding'], $_POST['ValorHolding'], $_POST['productoHolding'], $_POST['fechaHolding']);

            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "actualizo holding " . $_POST['productoHolding'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));

            header('Location: index.php?c=clientes');
        } else {
            echo "No tiene permiso";
        }
    }

    public function actualizar_holding_detail()
    {
        if ($_SESSION["rol"] == 'Administrador') {
            $soporte = $this->imagen();

            $this->detail->update($_POST['id_detail'], $_POST['fechadetail'], $_POST['detailDescripcion'], $_POST['BTCdetail'], $_POST['Preciodetail'], $_POST['USDdetail'], $_POST['COPdetail'], $soporte);

            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "actualizo holding detail" . $_POST['id_detail'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));

            header('Location: index.php?c=clientes');
        } else {
            echo "No tiene permiso";
        }
    }

    public function delete()
    {
        if ($_SESSION["rol"] == 'Administrador') {
            $this->holding->delete($_POST['id']);

            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "borro holding " . $_POST['id'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));

            header('Location: index.php?c=clientes');
        } else {
            echo "No tiene permiso";
        }
    }

    public function delete_holding_detail()
    {
        if ($_SESSION["rol"] == 'Administrador') {
            $this->detail->delete($_POST['id']);

            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "borro usuario detail" . $_POST['id'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));

            header('Location: index.php?c=clientes');
        } else {
            echo "No tiene permiso";
        }
    }

}
