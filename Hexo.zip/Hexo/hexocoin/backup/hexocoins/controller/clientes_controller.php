<?php

require_once 'model/cliente_modelo.php';
require_once 'model/log_modelo.php';
class clientes_controller
{
    private $clientes;
    private $logmodel;

    public function __construct()
    {
        $this->clientes = new cliente_modelo();
        $this->logmodel = new log_modelo();
    }

    public function index()
    {
        $tittle = "hexocoin-clientes";
        $data   = $this->clientes->get();
        if ($_SESSION["rol"] == 'Administrador') {
            require_once HTML_DIR . 'overall/header.php';
            require_once HTML_DIR . 'overall/topnav.html';
            require_once HTML_DIR . 'clientes/clientes.php';
            require_once HTML_DIR . 'overall/modal.php';
            require_once HTML_DIR . 'overall/footer.php';
        } else {
            require_once HTML_DIR_BASIC . 'overall/header.php';
            require_once HTML_DIR_BASIC . 'overall/topnav.html';
            require_once HTML_DIR_BASIC . 'clientes/clientes.php';
            require_once HTML_DIR_BASIC . 'overall/modal.php';
            require_once HTML_DIR_BASIC . 'overall/footer.php';
        }
    }

    public function crear()
    {
        $tittle = "hexocoin-nuevo clientes";
        if ($_SESSION["rol"] == 'Administrador') {
            require_once HTML_DIR . 'overall/header.php';
            require_once HTML_DIR . 'overall/topnav.html';
            require_once HTML_DIR . 'clientes/create.php';
            require_once HTML_DIR . 'overall/modal.php';
            require_once HTML_DIR . 'overall/footer.php';
        } else {
            echo "No tiene permiso";
        }
    }

    public function update()
    {
        $tittle = "hexocoin-actualizar datos";
        if ($_SESSION["rol"] == 'Administrador') {
            $data = $this->clientes->query($_GET['cedula']);
            require_once HTML_DIR . 'overall/header.php';
            require_once HTML_DIR . 'overall/topnav.html';
            require_once HTML_DIR . 'clientes/update.php';
            require_once HTML_DIR . 'overall/modal.php';
            require_once HTML_DIR . 'overall/footer.php';
        } else {
            echo "No tiene permiso";
        }
    }

    public function nuevo()
    {
        if ($_SESSION["rol"] == 'Administrador') {

            $this->clientes->save($_POST['DocumentoPerso'], $_POST['nombrePerso'], $_POST['ApellidoPerso'], $_POST['DirecionPerso'], $_POST['emailPerso'], $_POST['Telefono1Perso'], $_POST['Telefono2Perso'], $_POST['CelularPerso'], $_POST['pasaportePerso'], $_POST['referentePerso'], $_POST['ObservacionesPerso']);
            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "agrego cliente " . $_POST['DocumentoPerso'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));
            header('Location: index.php?c=clientes');
        } else {
            echo "No tiene permiso";
        }
    }

    public function actualizar()
    {
        if ($_SESSION["rol"] == 'Administrador') {
            $this->clientes->update($_POST['DocumentoPerso'], $_POST['nombrePerso'], $_POST['ApellidoPerso'], $_POST['DirecionPerso'], $_POST['emailPerso'], $_POST['Telefono1Perso'], $_POST['Telefono2Perso'], $_POST['CelularPerso'], $_POST['pasaportePerso'], $_POST['referentePerso'], $_POST['ObservacionesPerso']);
            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "actualizo cliente " . $_POST['DocumentoPerso'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));
            header('Location: index.php?c=clientes');
        } else {
            echo "No tiene permiso";
        }
    }

    public function delete()
    {
        if ($_SESSION["rol"] == 'Administrador') {
            $this->clientes->delete($_POST['id']);
            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "borro cliente " . $_POST['id'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));
        } else {
            echo "No tiene permiso";
        }
        header('Location: index.php?c=clientes');
    }

}
