<?php
//******nucleo*****////
define('HTML_DIR', 'view/html/'); //DIRECION DE LA VISTA
define('HTML_DIR_BASIC', 'view/html_basico/'); //DIRECION DE LA VISTA BASICO
define('APP_TITTLE', 'hexocoin'); //TITULO
define('APP_HOST', 'localhost');
define('APP_USER', 'root');
define('APP_PASS', '');
define('APP_DB', '');
/**
 *
 */
