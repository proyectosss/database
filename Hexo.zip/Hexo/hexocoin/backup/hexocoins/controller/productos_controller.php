<?php

require_once 'model/producto_modelo.php';
require_once 'model/log_modelo.php';
class productos_controller
{
    private $productos;
    private $logmodel;

    public function __construct()
    {
        $this->productos = new producto_modelo();
        $this->logmodel  = new log_modelo();
    }

    public function index()
    {
        $tittle = "hexocoin-productos";
        $data   = $this->productos->get();
        if ($_SESSION["rol"] == 'Administrador') {
            require_once HTML_DIR . 'overall/header.php';
            require_once HTML_DIR . 'overall/topnav.html';
            require_once HTML_DIR . 'productos/productos.php';
            require_once HTML_DIR . 'overall/modal.php';
            require_once HTML_DIR . 'overall/footer.php';
        } else {
            require_once HTML_DIR_BASIC . 'overall/header.php';
            require_once HTML_DIR_BASIC . 'overall/topnav.html';
            require_once HTML_DIR_BASIC . 'productos/productos.php';
            require_once HTML_DIR_BASIC . 'overall/modal.php';
            require_once HTML_DIR_BASIC . 'overall/footer.php';
        }
    }

    public function crear()
    {
        $tittle = "hexocoin-crear productos";
        if ($_SESSION["rol"] == 'Administrador') {
            require_once HTML_DIR . 'overall/header.php';
            require_once HTML_DIR . 'overall/topnav.html';
            require_once HTML_DIR . 'productos/create.php';
            require_once HTML_DIR . 'overall/modal.php';
            require_once HTML_DIR . 'overall/footer.php';
        } else {
            echo "No tiene permiso";
        }
    }

    public function update()
    {
        $tittle = "hexocoin-actualizar datos";
        if ($_SESSION["rol"] == 'Administrador') {
            $data = $this->productos->query($_GET['id']);
            require_once HTML_DIR . 'overall/header.php';
            require_once HTML_DIR . 'overall/topnav.html';
            require_once HTML_DIR . 'productos/update.php';
            require_once HTML_DIR . 'overall/modal.php';
            require_once HTML_DIR . 'overall/footer.php';
        } else {
            echo "No tiene permiso";
        }
    }

    public function nuevo()
    {
        if ($_SESSION["rol"] == 'Administrador') {
            $this->productos->save($_POST['nombreProduct'], $_POST['DescripcionProduc'], $_POST['ObservacionesProduc']);
            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "agrego producto " . $_POST['nombreProduct'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));
            header('Location: index.php?c=productos');
        } else {
            echo "No tiene permiso";
        }
    }

    public function actualizar()
    {
        if ($_SESSION["rol"] == 'Administrador') {
            $this->productos->update($_POST['nombreProduct'], $_POST['DescripcionProduc'], $_POST['ObservacionesProduc'], $_POST['id']);
            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "actualizo producto " . $_POST['nombreProduct'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));
            header('Location: index.php?c=productos');
        } else {
            echo "No tiene permiso";
        }
    }
    public function delete()
    {
        if ($_SESSION["rol"] == 'Administrador') {
            $this->productos->delete($_POST['id']);
            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "borro producto " . $_POST['id'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));
            header('Location: index.php?c=productos');
        } else {
            echo "No tiene permiso";
        }
    }

}
