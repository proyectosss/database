<?php
require_once 'model/usuario_modelo.php';
require_once 'model/log_modelo.php';
class usuario_controller
{
    private $usuario;
    private $logmodel;
    public function __construct()
    {
        $this->usuario  = new usuario_modelo();
        $this->logmodel = new log_modelo();
    }

    public function index()
    {
        $tittle = "hexocoin-usuario";
        if ($_SESSION["rol"] == 'Administrador') {
            $data = $this->usuario->get();
            require_once HTML_DIR . 'overall/header.php';
            require_once HTML_DIR . 'overall/topnav.html';
            require_once HTML_DIR . 'usuario/usuario.php';
            require_once HTML_DIR . 'overall/modal.php';
            require_once HTML_DIR . 'overall/footer.php';
        } else {
            echo "No tiene permiso";
        }

    }

    public function crear()
    {
        $tittle = "hexocoin-nuevo usuario";
        if ($_SESSION["rol"] == 'Administrador') {
            require_once HTML_DIR . 'overall/header.php';
            require_once HTML_DIR . 'overall/topnav.html';
            require_once HTML_DIR . 'usuario/create.php';
            require_once HTML_DIR . 'overall/modal.php';
            require_once HTML_DIR . 'overall/footer.php';
        } else {
            echo "No tiene permiso";
        }
    }

    public function update()
    {
        $tittle = "hexocoin-actualizar datos";
        if ($_SESSION["rol"] == 'Administrador') {
            $data = $this->usuario->query($_GET['cedula']);
            require_once HTML_DIR . 'overall/header.php';
            require_once HTML_DIR . 'overall/topnav.html';
            require_once HTML_DIR . 'usuario/update.php';
            require_once HTML_DIR . 'overall/modal.php';
            require_once HTML_DIR . 'overall/footer.php';
        } else {
            echo "No tiene permiso";
        }
    }

    public function nuevo()
    {
        if ($_SESSION["rol"] == 'Administrador') {
            $passenc = encriptar($_POST['Password']);
            $this->usuario->save($_POST['DocumentoUser'], $_POST['nombreUser'], $_POST['ApellidoUser'], $_POST['CelularUser'], $_POST['emailUser'], $passenc, $_POST['Rol'], $_POST['estado'], $_POST['fechaIngreso'], $_POST['TelefonoUser']);
            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "agrego usuario " . $_POST['DocumentoUser'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));
            header('Location: index.php?c=usuario');
        } else {
            echo "No tiene permiso";
        }
    }

    public function actualizar()
    {
        if ($_SESSION["rol"] == 'Administrador') {
            $this->usuario->update($_POST['cedula'], $_POST['nombreUser'], $_POST['ApellidoUser'], $_POST['CelularUser'], $_POST['emailUser'], $_POST['Rol'], $_POST['estado'], $_POST['TelefonoUser']);

            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "actualizo usuario " . $_POST['cedula'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));
            header('Location: index.php?c=usuario');
        } else {
            echo "No tiene permiso";
        }
    }

    public function delete()
    {
        if ($_SESSION["rol"] == 'Administrador') {
            $this->usuario->delete($_POST['id']);

            $this->logmodel->log($_SESSION["documento"], $_SESSION["name"], $_SESSION["ema"], "borro usuario " . $_POST['id'], getRealIP(), $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], date('Y-m-d H:i:s'));

            header('Location: index.php?c=usuario');
        } else {
            echo "No tiene permiso";
        }
    }

}
