-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 04-10-2017 a las 23:51:47
-- Versión del servidor: 10.1.19-MariaDB
-- Versión de PHP: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_hexocoins`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizar_datos_personales` (IN `nombre` VARCHAR(900), IN `apellido` VARCHAR(900), IN `direcion` VARCHAR(900), IN `telefono1` INT, IN `telefono2` INT, IN `celular` BIGINT, IN `email` VARCHAR(900), IN `pasaporte` VARCHAR(900), IN `referencia` VARCHAR(900), IN `observaciones` TEXT, IN `cedula` INT)  NO SQL
BEGIN
SET @nombre=nombre;
SET @apellido=apellido;
SET @direcion=direcion;
SET @telefono1=telefono1;
SET @telefono2=telefono2;
SET @celular=celular;
SET @email=email;
SET @pasaporte=pasaporte;
SET @referencia=referencia;
SET @observaciones=observaciones;
UPDATE tbl_datos_personales set var_nombre_dat = @nombre, var_apellido_dat=@apellido, var_direccion_dat=@direcion, int_telefono1_dat=@telefono1, int_telefono2_dat=@telefono2, int_celular_dat= @celular, var_email_dat=@email, var_pasaporte_dat=@pasaporte, var_referente_dat=@referencia, var_observaciones_dat=@observaciones
WHERE int_id_dat=cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizar_holding` (IN `valor` DOUBLE, IN `observacione` TEXT, IN `fecha` DATE, IN `id` INT)  NO SQL
BEGIN
UPDATE tbl_holding set dou_valor_hol = valor, text_observacione_hol=observacione, date_fecha_hol=fecha
WHERE int_id_producto_hol=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizar_holding_detail` (IN `descipcion` VARCHAR(900), IN `btc` DOUBLE, IN `PrecioBTC` DOUBLE, IN `usd` DOUBLE, IN `cop` DOUBLE, IN `Soporte` TEXT, IN `fecha` DATETIME, IN `id` INT)  NO SQL
BEGIN
UPDATE tbl_holding_detail set text_descipcion_hdet = descipcion, dou_btc_hdet=btc, dou_PrecioBTC_Dia_hdet=PrecioBTC, dou_usd_hdet=usd, dou_cop_hdet=cop, text_SoportePago_hdet=Soporte, date_fecha_hdet=fecha
WHERE int_id_hdet=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizar_producto` (IN `nombre` VARCHAR(900), IN `descripcion` VARCHAR(900), IN `observaciones` VARCHAR(900), IN `id` INT)  NO SQL
BEGIN
UPDATE tbl_productos set var_nombre_pro = nombre, text_descripcion_pro=descripcion, text_observaciones_pro=observaciones
WHERE int_id_pro=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizar_usuario` (IN `nombre` VARCHAR(900), IN `apellido` VARCHAR(900), IN `telefono` INT, IN `celular` BIGINT, IN `email` VARCHAR(900), IN `estado` VARCHAR(200), IN `role` VARCHAR(900), IN `cedula` INT)  NO SQL
BEGIN
SET @nombre=nombre;
SET @apellido=apellido;
SET @telefono=telefono;
SET @celular=celular;
SET @email=email;
SET @estado=estado;
SET @role=role;
SET @cedula=cedula;
UPDATE tbl_usuario set var_nombre_use = @nombre, var_apellido_use=@apellido, int_telefono_use=@telefono, int_celular_use= @celular, var_email_use=@email, var_estado_use=@estado, var_role_use=@role
WHERE int_documento_use=@cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_consulta_datos_personales` (IN `cedula` INT)  NO SQL
BEGIN
SELECT int_id_dat as cedula, var_nombre_dat as nombre, var_apellido_dat as apellido, var_direccion_dat as direcion, int_telefono1_dat as telefono1, int_telefono2_dat as telefono2, int_celular_dat as celular, var_email_dat as email, var_pasaporte_dat as pasaporte, var_referente_dat as referencia, var_observaciones_dat as observaciones
FROM tbl_datos_personales
WHERE int_id_dat=cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_consulta_holding` (IN `id` INT)  NO SQL
BEGIN
SELECT int_id_producto_hol as id_producto, date_fecha_hol as fecha, dou_valor_hol as valor, text_observacione_hol as observacione, int_id_holding_pro as producto
FROM tbl_holding
WHERE int_id_producto_hol =id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_consulta_producto` (IN `id` INT)  NO SQL
BEGIN
SELECT var_nombre_pro as nombre_producto, text_descripcion_pro as descripcion_producto, text_observaciones_pro as observaciones, int_id_pro as id 
FROM tbl_productos
WHERE int_id_pro=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_consulta_usuario` (IN `cedula` INT)  NO SQL
BEGIN
SET @cedula=cedula;
SELECT int_documento_use as cedula, var_nombre_use as nombre, var_apellido_use as apellido, int_telefono_use as telefono, int_celular_use as celular, var_email_use as email, var_password_use as passwordu, var_estado_use as estado, date_fecha_inicio_use as fecha, var_role_use as role
FROM tbl_usuario
WHERE int_documento_use=@cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_datos_personales_ingreso` (IN `documento` INT, IN `nombre` VARCHAR(900), IN `apellido` VARCHAR(900), IN `direcion` VARCHAR(900), IN `telefono1` INT, IN `telefono2` INT, IN `celular` BIGINT, IN `email` VARCHAR(900), IN `pasaporte` VARCHAR(900), IN `referente` VARCHAR(900), IN `observaciones` TEXT)  NO SQL
BEGIN
INSERT INTO tbl_datos_personales(int_id_dat, var_nombre_dat, var_apellido_dat,  var_direccion_dat, int_telefono1_dat, int_telefono2_dat, int_celular_dat, var_email_dat, var_pasaporte_dat, var_referente_dat, var_observaciones_dat) VALUES (documento, nombre, apellido, direcion, telefono1, telefono2, celular, email, pasaporte, referente, observaciones);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_eliminar_datos_personales` (IN `cedula` INT)  NO SQL
DELETE FROM tbl_datos_personales WHERE int_id_dat=cedula$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_eliminar_holding` (IN `id` INT)  NO SQL
BEGIN
DELETE FROM tbl_holding WHERE int_id_producto_hol=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_eliminar_holding_detail` (IN `id` INT)  NO SQL
BEGIN
DELETE FROM tbl_holding_detail WHERE int_id_hdet=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_eliminar_producto` (IN `id` INT)  NO SQL
DELETE FROM tbl_productos WHERE int_id_pro=id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_eliminar_usuario` (IN `cedula` INT)  NO SQL
BEGIN
set @cedula=cedula;
DELETE FROM tbl_usuario WHERE int_documento_use=@cedula;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_holding_detail_obtener` (IN `id` INT)  NO SQL
BEGIN
SELECT int_id_producto_hol as id_producto, date_fecha_hdet as fecha, text_descipcion_hdet as descipcion, dou_btc_hdet as btc, dou_PrecioBTC_Dia_hdet as btcdia, dou_usd_hdet as usd, dou_cop_hdet as cop, text_SoportePago_hdet as SoportePago, int_id_hdet as id
FROM tbl_holding_detail
WHERE int_id_producto_hol =id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_igreso_usuario` (IN `documento` INT, IN `nombre` VARCHAR(900), IN `apellido` VARCHAR(900), IN `telefono` INT, IN `celular` BIGINT, IN `email` VARCHAR(900), IN `passwordu` VARCHAR(900), IN `estado` VARCHAR(200), IN `fecha` DATETIME, IN `role` VARCHAR(900))  NO SQL
BEGIN
SET @documento=documento; 
SET @nombre=nombre; 
SET @apellido=apellido; 
SET @telefono=telefono; 
SET @celular=celular; 
SET @email=email; 
SET @passwordu=passwordu; 
SET @estado=estado; 
SET @fecha=fecha; 
SET @role=role;
INSERT INTO tbl_usuario(int_documento_use, 
var_nombre_use, var_apellido_use,  int_telefono_use, int_celular_use, var_email_use, var_password_use, var_estado_use, date_fecha_inicio_use, var_role_use) VALUES (@documento, @nombre, @apellido, @telefono, @celular, @email, @passwordu, @estado, @fecha, @role);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ingresar_holding_detail` (IN `id_producto` INT, IN `fecha` DATETIME, IN `descipcion` INT, IN `btc` DOUBLE, IN `Precio` DOUBLE, IN `usd` DOUBLE, IN `cop` DOUBLE, IN `Soporte` TEXT)  NO SQL
BEGIN
INSERT INTO tbl_holding_detail(int_id_hdet, int_id_producto_hol, date_fecha_hdet, text_descipcion_hdet, dou_btc_hdet, dou_PrecioBTC_Dia_hdet, dou_usd_hdet, dou_cop_hdet, text_SoportePago_hdet) VALUES (null, id_producto, fecha, descipcion, btc, Precio, usd, cop, Soporte);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ingreso_holding` (IN `id_producto` INT, IN `cliente` INT, IN `fecha` DATETIME, IN `valor` DOUBLE, IN `id_holding` INT, IN `observacione` TEXT)  NO SQL
BEGIN
INSERT INTO tbl_holding(int_id_producto_hol, int_id_cliente_dat, date_fecha_hol, dou_valor_hol, int_id_holding_pro, text_observacione_hol) VALUES (id_producto, cliente, fecha, valor, id_holding, observacione);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_leer_producto` ()  NO SQL
BEGIN
SELECT var_nombre_pro as nombre_producto, text_descripcion_pro as descripcion_producto, text_observaciones_pro as observacion_producto, int_id_pro as id_producto
FROM tbl_productos;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_leer_todos_datos_personales` ()  NO SQL
BEGIN
SELECT int_id_dat as cedula, var_nombre_dat as nombre, var_apellido_dat as apellido, var_direccion_dat as direcion, int_telefono1_dat as telefono1, int_telefono2_dat as telefono2, int_celular_dat as celular, var_email_dat as email, var_pasaporte_dat as pasaporte, var_referente_dat as referencia, var_observaciones_dat as observaciones
FROM tbl_datos_personales;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_leer_usuario` ()  NO SQL
BEGIN
SELECT int_documento_use as cedula, var_nombre_use as nombre, var_apellido_use as apellido, int_telefono_use as telefono, int_celular_use as celular, 
var_email_use as email, var_estado_use as estado, date_fecha_inicio_use as fecha, var_role_use as role,
var_password_use as pass
FROM tbl_usuario;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_log` (IN `documento` INT, IN `emai` VARCHAR(900), IN `nombre` VARCHAR(900), IN `acion` TEXT, IN `IPreal` VARCHAR(900), IN `ipscript` VARCHAR(900), IN `ipusuario` VARCHAR(900), IN `fecha` DATETIME)  NO SQL
BEGIN
INSERT INTO tbl_log(int_id_log, int_documento_log, var_email_log, var_nombre_log, var_acion_log, var_IPreal_log, var_ipscript_log, var_ipusuario_log, date_fecha_log ) VALUES (null, documento, emai, nombre, acion, IPreal, ipscript, ipusuario, fecha);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_obtener_holding` (IN `id` INT)  NO SQL
BEGIN
SELECT int_id_producto_hol as id_producto, int_id_cliente_dat as cliente, date_fecha_hol as fecha, dou_valor_hol as valor, int_id_holding_pro as id_holding, text_observacione_hol as observacione, tbl_productos.var_nombre_pro as name_producto
FROM tbl_holding INNER JOIN tbl_productos on tbl_holding.int_id_holding_pro=tbl_productos.int_id_pro
WHERE tbl_holding.int_id_cliente_dat=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_obtener_holding_detail` (IN `id` INT)  NO SQL
BEGIN
SELECT int_id_hdet as id_detail, date_fecha_hdet as fecha, text_descipcion_hdet as descipcion, dou_btc_hdet as btc, dou_PrecioBTC_Dia_hdet as PrecioBTC, dou_usd_hdet as usd, dou_cop_hdet as cop, text_SoportePago_hdet as Soporte
FROM tbl_holding_detail
WHERE int_id_hdet=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_producto_ingreso` (IN `nombre` VARCHAR(900), IN `descripcion` VARCHAR(900), IN `observaciones` VARCHAR(900))  NO SQL
BEGIN
INSERT INTO tbl_productos(int_id_pro, var_nombre_pro, text_descripcion_pro, text_observaciones_pro) VALUES (null, nombre, descripcion, observaciones);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_producto_name_obtener` (IN `id` INT)  NO SQL
BEGIN
SELECT var_nombre_pro as name
FROM tbl_productos
WHERE int_id_pro=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_usuario_login` (IN `vemail` VARCHAR(900))  NO SQL
BEGIN
SELECT var_email_use AS email_usuario, var_password_use AS password_usuario, var_nombre_use AS nombre, var_apellido_use AS apellido, int_documento_use as documento, var_role_use as rol
FROM tbl_usuario
WHERE var_email_use = vemail;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_cuentas_cliente`
--

CREATE TABLE `tbl_cuentas_cliente` (
  `int_id_cue` int(11) NOT NULL,
  `int_id_cliente_dat` int(11) NOT NULL,
  `dou_btc_cue` double NOT NULL,
  `var_CryptoDivisa2_cue` varchar(900) NOT NULL,
  `var_CryptoDivisa3_cue` varchar(900) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_datos_personales`
--

CREATE TABLE `tbl_datos_personales` (
  `int_id_dat` int(11) NOT NULL,
  `var_nombre_dat` varchar(900) NOT NULL,
  `var_apellido_dat` varchar(900) NOT NULL,
  `var_direccion_dat` varchar(900) NOT NULL,
  `int_telefono1_dat` int(11) NOT NULL,
  `int_telefono2_dat` int(11) DEFAULT NULL,
  `int_celular_dat` bigint(11) NOT NULL,
  `var_email_dat` varchar(900) NOT NULL,
  `var_pasaporte_dat` varchar(900) NOT NULL,
  `var_referente_dat` varchar(900) DEFAULT NULL,
  `var_observaciones_dat` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tbl_datos_personales`
--

INSERT INTO `tbl_datos_personales` (`int_id_dat`, `var_nombre_dat`, `var_apellido_dat`, `var_direccion_dat`, `int_telefono1_dat`, `int_telefono2_dat`, `int_celular_dat`, `var_email_dat`, `var_pasaporte_dat`, `var_referente_dat`, `var_observaciones_dat`) VALUES
(3123, 'dfsf', 'fdsfsdf', 'sdfsdf', 21321, 32423, 324324, 'dsf@fdsf.sdfds', '432423', '4324', '432434'),
(32432, '12', '12', '12', 12, 12, 12, '12@df.fd', '12', '12', '12'),
(72774495, 'Sami', 'Gallego', 'dfas 39872', 2342, 123, 1234, 'hdfu@com.coo', '12341', '1234', '1234');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_holding`
--

CREATE TABLE `tbl_holding` (
  `int_id_producto_hol` int(11) NOT NULL,
  `int_id_cliente_dat` int(11) NOT NULL,
  `date_fecha_hol` date NOT NULL,
  `dou_valor_hol` double NOT NULL,
  `int_id_holding_pro` int(11) NOT NULL,
  `text_observacione_hol` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tbl_holding`
--

INSERT INTO `tbl_holding` (`int_id_producto_hol`, `int_id_cliente_dat`, `date_fecha_hol`, `dou_valor_hol`, `int_id_holding_pro`, `text_observacione_hol`) VALUES
(24, 72774495, '2017-10-04', 1000000, 3, 'jhfjhfjhfj'),
(2323, 32432, '2016-05-17', 1.1111111111111112, 3, 'dsfjsdjhfhgdhsfgh'),
(11111, 32432, '2017-10-04', 22.2, 3, 'sdd'),
(23232, 32432, '2017-10-04', 2, 3, '2'),
(24324, 32432, '2017-10-25', 2333.33, 3, '43434'),
(324234, 72774495, '2017-10-04', 0, 3, 'sdf');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_holding_detail`
--

CREATE TABLE `tbl_holding_detail` (
  `int_id_hdet` int(11) NOT NULL,
  `int_id_producto_hol` int(11) NOT NULL,
  `date_fecha_hdet` date NOT NULL,
  `text_descipcion_hdet` text NOT NULL,
  `dou_btc_hdet` double NOT NULL,
  `dou_PrecioBTC_Dia_hdet` double NOT NULL,
  `dou_usd_hdet` double NOT NULL,
  `dou_cop_hdet` double NOT NULL,
  `text_SoportePago_hdet` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tbl_holding_detail`
--

INSERT INTO `tbl_holding_detail` (`int_id_hdet`, `int_id_producto_hol`, `date_fecha_hdet`, `text_descipcion_hdet`, `dou_btc_hdet`, `dou_PrecioBTC_Dia_hdet`, `dou_usd_hdet`, `dou_cop_hdet`, `text_SoportePago_hdet`) VALUES
(4, 23232, '2017-10-04', '1', 1, 1, 1, 1, '1'),
(5, 11111, '2016-07-07', '0dfsfsdf', 2.2222, 322.222222, 32323, 42434, 'view/imagenes/Soportes/soporte_2017-10-04_(21_28_31)_14910341_1148902848554184_5963603856674729158_n.png'),
(6, 24324, '2017-10-04', '0', 43.43, 3333.333, 43.43, 45555.5555, 'view/imagenes/Soportes/soporte_2017-10-04_(19_53_47)_14563376_1148902808554188_7292427752301160538_n.png'),
(8, 11111, '2017-10-04', '0', 3.333, 0.33333, 0.333, 0.3333333, 'view/imagenes/Soportes/soporte_2017-10-04_(21_28_59)_14610878_1148902861887516_7196484191429534935_n.png'),
(9, 11111, '2017-10-04', '43545', 34344, 45435, 4, 4354, 'view/imagenes/Soportes/soporte_2017-10-04_(21_29_55)_14915662_1148902891887513_4319572994833901427_n.png'),
(10, 24, '2017-10-04', '0', 0, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-10-04_(23_17_54)_14611157_1148902878554181_478933829470112120_n.png'),
(11, 24, '2017-10-04', '0', 0, 0, 0, 3000, 'view/imagenes/Soportes/soporte_2017-10-04_(23_19_10)_14910341_1148902848554184_5963603856674729158_n.png'),
(12, 24, '2017-10-04', '3434', 0, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-10-04_(23_24_36)_14610878_1148902861887516_7196484191429534935_n.png'),
(13, 324234, '2017-10-04', '0', 0, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-10-04_(23_31_05)_14906970_1148902798554189_8870837068901531359_n.png'),
(14, 24, '2017-10-04', '0', 0, 0, 0, 0, 'view/imagenes/Soportes/soporte_2017-10-04_(23_45_28)_14563376_1148902808554188_7292427752301160538_n.png');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_log`
--

CREATE TABLE `tbl_log` (
  `int_id_log` int(11) NOT NULL,
  `int_documento_log` int(11) NOT NULL,
  `var_email_log` varchar(900) NOT NULL,
  `var_nombre_log` varchar(900) NOT NULL,
  `var_acion_log` text NOT NULL,
  `var_IPreal_log` varchar(900) NOT NULL,
  `var_ipscript_log` varchar(900) NOT NULL,
  `var_ipusuario_log` varchar(900) NOT NULL,
  `date_fecha_log` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tbl_log`
--

INSERT INTO `tbl_log` (`int_id_log`, `int_documento_log`, `var_email_log`, `var_nombre_log`, `var_acion_log`, `var_IPreal_log`, `var_ipscript_log`, `var_ipusuario_log`, `date_fecha_log`) VALUES
(2, 1000898270, 'j.arley111@gmail.com', '', 'inicio de sesion', '', '127.0.0.1', '127.0.0.1', '2017-10-02 11:20:43'),
(3, 1000898270, 'j.arley111@gmail.com', '', 'inicio de sesion', '', '127.0.0.1', '127.0.0.1', '2017-10-02 11:23:01'),
(4, 1000898270, 'j.arley111@gmail.com', 'yeisson sanchez', 'inicio de sesion', '127.0.0.1', '127.0.0.1', '127.0.0.1', '2017-10-02 11:23:56'),
(5, 1000898270, 'j.arley111@gmail.com', 'yeisson sanchez', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 03:15:42'),
(6, 1234, 'j.sdsd@dsfdf.df', 'dfdsf sdffdsf', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 04:20:05'),
(7, 1234, 'j.sdsd@dsfdf.df', 'dfdsf sdffdsf', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 04:20:29'),
(8, 1234, 'j.sdsd@dsfdf.df', 'dfdsf sdffdsf', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 04:54:19'),
(9, 1000898270, 'j.arley111@gmail.com', 'yeisson sanchez', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 04:57:43'),
(10, 1000898270, 'j.arley111@gmail.com', 'yeisson sanchez', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 05:28:03'),
(11, 1000898270, 'j.arley111@gmail.com', 'yeisson sanchez', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 05:28:14'),
(12, 1000898270, 'j.arley111@gmail.com', 'yeisson1 sanchez1', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 08:40:30'),
(13, 1000898270, 'j.arley111@gmail.com', 'yeisson1 sanchez1', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 12:15:16'),
(14, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 21:54:27'),
(15, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego usuario 3243233', '::1', '::1', '::1', '2017-10-04 21:58:45'),
(16, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'actualizo usuario 3243233', '::1', '::1', '::1', '2017-10-04 21:59:41'),
(17, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'borro usuario ', '::1', '::1', '::1', '2017-10-04 21:59:53'),
(18, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego producto 3242', '::1', '::1', '::1', '2017-10-04 22:02:58'),
(19, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'actualizo producto 32423434', '::1', '::1', '::1', '2017-10-04 22:03:37'),
(20, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'borro producto 4', '::1', '::1', '::1', '2017-10-04 22:03:48'),
(21, 1000898270, 'j.arley111@gmail.com', 'yeisson1 sanchez1', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 22:18:20'),
(22, 1000898270, 'j.arley111@gmail.com', 'yeisson1 sanchez1', 'agrego usuario 1000089827', '::1', '::1', '::1', '2017-10-04 22:19:25'),
(23, 1000898270, 'j.arley111@gmail.com', 'yeisson1 sanchez1', 'actualizo usuario ', '::1', '::1', '::1', '2017-10-04 22:19:55'),
(24, 1000898270, 'j.arley111@gmail.com', 'yeisson1 sanchez1', 'actualizo usuario 1000089827', '::1', '::1', '::1', '2017-10-04 22:21:53'),
(25, 1000898270, 'j.arley111@gmail.com', 'yeisson1 sanchez1', 'borro usuario 1000089827', '::1', '::1', '::1', '2017-10-04 22:22:19'),
(26, 1000898270, 'j.arley111@gmail.com', 'yeisson1 sanchez1', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 22:26:30'),
(27, 1000898270, 'j.arley111@gmail.com', 'yeisson1 sanchez1', 'agrego usuario 1', '::1', '::1', '::1', '2017-10-04 22:31:01'),
(28, 1, 'basico@usurio.com', 'BASICO S', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 22:31:17'),
(29, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 23:01:42'),
(30, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'actualizo producto Mineria', '::1', '::1', '::1', '2017-10-04 23:02:56'),
(31, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego cliente 72774495', '::1', '::1', '::1', '2017-10-04 23:03:57'),
(32, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'subio soporte del producto 24 con la ruta: view/imagenes/Soportes/soporte_2017-10-04_(23_17_54)_14611157_1148902878554181_478933829470112120_n.png', '::1', '::1', '::1', '2017-10-04 23:17:54'),
(33, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego holding 24', '::1', '::1', '::1', '2017-10-04 23:17:54'),
(34, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego un holding detail del producto24', '::1', '::1', '::1', '2017-10-04 23:17:54'),
(35, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'subio soporte del producto 24 con la ruta: view/imagenes/Soportes/soporte_2017-10-04_(23_19_10)_14910341_1148902848554184_5963603856674729158_n.png', '::1', '::1', '::1', '2017-10-04 23:19:10'),
(36, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego un holding detail del producto', '::1', '::1', '::1', '2017-10-04 23:19:10'),
(37, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'subio soporte del producto 24 con la ruta: view/imagenes/Soportes/soporte_2017-10-04_(23_24_36)_14610878_1148902861887516_7196484191429534935_n.png', '::1', '::1', '::1', '2017-10-04 23:24:36'),
(38, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego un holding detail del producto', '::1', '::1', '::1', '2017-10-04 23:24:36'),
(39, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'subio soporte del producto 324234 con la ruta: view/imagenes/Soportes/soporte_2017-10-04_(23_31_05)_14906970_1148902798554189_8870837068901531359_n.png', '::1', '::1', '::1', '2017-10-04 23:31:05'),
(40, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego holding 324234', '::1', '::1', '::1', '2017-10-04 23:31:05'),
(41, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego un holding detail del producto324234', '::1', '::1', '::1', '2017-10-04 23:31:05'),
(42, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'subio soporte del producto 24 con la ruta: view/imagenes/Soportes/soporte_2017-10-04_(23_45_28)_14563376_1148902808554188_7292427752301160538_n.png', '::1', '::1', '::1', '2017-10-04 23:45:28'),
(43, 71774495, 'julian.galeano@pascualbravo.edu.co', 'Julian Galeano', 'agrego un holding detail del producto', '::1', '::1', '::1', '2017-10-04 23:45:28'),
(44, 1, 'basico@usurio.com', 'BASICO S', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 23:47:08'),
(45, 1000898270, 'j.arley111@gmail.com', 'yeisson1 sanchez1', 'inicio de sesion', '::1', '::1', '::1', '2017-10-04 23:48:54');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_productos`
--

CREATE TABLE `tbl_productos` (
  `int_id_pro` int(11) NOT NULL,
  `var_nombre_pro` varchar(900) NOT NULL,
  `text_descripcion_pro` text NOT NULL,
  `text_observaciones_pro` varchar(900) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tbl_productos`
--

INSERT INTO `tbl_productos` (`int_id_pro`, `var_nombre_pro`, `text_descripcion_pro`, `text_observaciones_pro`) VALUES
(3, 'Mineria', 'fff', 'dddddd');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_usuario`
--

CREATE TABLE `tbl_usuario` (
  `int_documento_use` int(11) NOT NULL,
  `var_nombre_use` varchar(900) NOT NULL,
  `var_apellido_use` varchar(900) NOT NULL,
  `int_telefono_use` int(11) NOT NULL,
  `int_celular_use` bigint(11) NOT NULL,
  `var_email_use` varchar(900) NOT NULL,
  `var_password_use` varchar(900) NOT NULL,
  `var_estado_use` varchar(200) NOT NULL,
  `date_fecha_inicio_use` date NOT NULL,
  `var_role_use` varchar(900) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tbl_usuario`
--

INSERT INTO `tbl_usuario` (`int_documento_use`, `var_nombre_use`, `var_apellido_use`, `int_telefono_use`, `int_celular_use`, `var_email_use`, `var_password_use`, `var_estado_use`, `date_fecha_inicio_use`, `var_role_use`) VALUES
(1, 'BASICO', 'S', 2, 234, 'basico@usurio.com', '8phxy+annn5gqhb1ub0NrvERYzrJLSZHclqqUQ0+eGU=', 'Activo', '2017-10-04', 'Básico'),
(71774495, 'Julian', 'Galeano', 5454, 543543543, 'julian.galeano@pascualbravo.edu.co', 'Bf6/4MTVO7Qus4xVOXYPz5n3F0cVku1zawAhaUrZXcE=', 'Activo', '2017-10-04', 'Administrador'),
(1000898270, 'yeisson1', 'sanchez1', 42124411, 2147483647, 'j.arley111@gmail.com', 'hqId+2xtk1cyTkyoy1gtnvpxlte02RaSoAUV61onT30=', 'inactivo', '2017-10-04', 'Administrador');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tbl_cuentas_cliente`
--
ALTER TABLE `tbl_cuentas_cliente`
  ADD PRIMARY KEY (`int_id_cue`),
  ADD KEY `FK_TBL_DATOS_PERSONALES` (`int_id_cliente_dat`);

--
-- Indices de la tabla `tbl_datos_personales`
--
ALTER TABLE `tbl_datos_personales`
  ADD PRIMARY KEY (`int_id_dat`);

--
-- Indices de la tabla `tbl_holding`
--
ALTER TABLE `tbl_holding`
  ADD PRIMARY KEY (`int_id_producto_hol`),
  ADD KEY `FK_TBL_HOLDING` (`int_id_cliente_dat`),
  ADD KEY `FK_TBL_HOLDING_2` (`int_id_holding_pro`) USING BTREE;

--
-- Indices de la tabla `tbl_holding_detail`
--
ALTER TABLE `tbl_holding_detail`
  ADD PRIMARY KEY (`int_id_hdet`),
  ADD KEY `FK_TBL_HOLDING_DETAIL` (`int_id_producto_hol`);

--
-- Indices de la tabla `tbl_log`
--
ALTER TABLE `tbl_log`
  ADD PRIMARY KEY (`int_id_log`);

--
-- Indices de la tabla `tbl_productos`
--
ALTER TABLE `tbl_productos`
  ADD PRIMARY KEY (`int_id_pro`);

--
-- Indices de la tabla `tbl_usuario`
--
ALTER TABLE `tbl_usuario`
  ADD PRIMARY KEY (`int_documento_use`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tbl_cuentas_cliente`
--
ALTER TABLE `tbl_cuentas_cliente`
  MODIFY `int_id_cue` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `tbl_holding_detail`
--
ALTER TABLE `tbl_holding_detail`
  MODIFY `int_id_hdet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT de la tabla `tbl_log`
--
ALTER TABLE `tbl_log`
  MODIFY `int_id_log` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT de la tabla `tbl_productos`
--
ALTER TABLE `tbl_productos`
  MODIFY `int_id_pro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `tbl_cuentas_cliente`
--
ALTER TABLE `tbl_cuentas_cliente`
  ADD CONSTRAINT `tbl_cuentas_cliente_ibfk_1` FOREIGN KEY (`int_id_cliente_dat`) REFERENCES `tbl_datos_personales` (`int_id_dat`);

--
-- Filtros para la tabla `tbl_holding`
--
ALTER TABLE `tbl_holding`
  ADD CONSTRAINT `tbl_holding_ibfk_1` FOREIGN KEY (`int_id_cliente_dat`) REFERENCES `tbl_datos_personales` (`int_id_dat`),
  ADD CONSTRAINT `tbl_holding_ibfk_2` FOREIGN KEY (`int_id_holding_pro`) REFERENCES `tbl_productos` (`int_id_pro`);

--
-- Filtros para la tabla `tbl_holding_detail`
--
ALTER TABLE `tbl_holding_detail`
  ADD CONSTRAINT `tbl_holding_detail_ibfk_1` FOREIGN KEY (`int_id_producto_hol`) REFERENCES `tbl_holding` (`int_id_producto_hol`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
