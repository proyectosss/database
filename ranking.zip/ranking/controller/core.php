<?php
//******nucleo*****////
define('HTML_DIR_PUBLIC', 'view/html/html_publico/'); //DIRECION DE LA VISTA
define('HTML_DIR_GERENTE', 'view/html/html_gerente/'); //DIRECION DE LA VISTA gerente
define('HTML_DIR_ADMIN', 'view/html/html_administrador/'); //DIRECION DE LA VISTA administrador
define('HTML_DIR_DIRECTOR', 'view/html/html_director/'); //DIRECION DE LA VISTA administrador 
define('HTML_DIR_VENDEDOR', 'view/html/html_vendedor/');
define('APP_TITTLE', 'hexocoin'); //TITULO
define('APP_HOST', 'localhost');
define('APP_USER', 'root');
define('APP_PASS', '');
define('APP_DB', '');
/**
 *
 */
