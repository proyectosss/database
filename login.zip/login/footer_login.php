<!--Scripts-->
<!-- Archivos necesarios jquery JS -->
<script src="view/assets/jquery/dist/jquery.js"></script>
<!--dataTables-->
<script src="view/assets/datatable/js/jquery.dataTables.min.js"></script>
<script src="view/assets/datatable/js/dataTables.bootstrap.js"></script>
<!-- Archivos necesarios de JS -->
<script type="text/javascript" src=view/js/script.js></script>
<!-- Archivos necesarios para Bootstrap -->
<script type="text/javascript" src="view/assets/bootstrap/dist/js/bootstrap.min.js" ></script>
<!-- Archivos necesarios material design bootstrap JS -->
<script type="text/javascript" src="view/assets/bootstrap-material-design/dist/js/material.js"></script>
<script type="text/javascript" src="view/assets/bootstrap-material-design/dist/js/ripples.min.js"></script>
<script type="text/javascript">
$.material.init();
</script>
</body>
</html>
